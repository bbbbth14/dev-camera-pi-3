﻿/**
 * @file main.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#ifndef _DEFAULT_SOURCE
#define _DEFAULT_SOURCE /* needed for usleep() */
#endif

#include <stdlib.h>
#include <stdio.h>
#ifdef _MSC_VER
#include <Windows.h>
#else
#include <unistd.h>
#include <pthread.h>
#endif
#include "lvgl/lvgl.h"
#include "lvgl/examples/lv_examples.h"
#include "lvgl/demos/lv_demos.h"
#include <SDL.h>

#include "hal/hal.h"

#include "Display.h"
#include "DockManager.h"
#include "GUIEventDispatcher.h"
#include "GUIEngine.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

int main(int argc, char **argv)
{
    (void)argc; /*Unused*/
    (void)argv; /*Unused*/

    /*Initialize LVGL*/
    lv_init();

    /*Initialize the HAL (display, input devices, tick) for LVGL*/
    // sdl_hal_init(320, 480);

    Display display;

    lv_display_t *rightDisplay = display.create_display(L"Right Display", 640, 360);
    if (!rightDisplay)
    {
        return -1;
    }

    GUIEngine::GetInstance().SetRightDisplay(rightDisplay);

    lv_display_set_default(rightDisplay);
    lv_obj_t *rightScr = display.create_right_screen();
    lv_screen_load(rightScr);

    lv_display_t *bottomDisplay = display.create_display(L"Bottom Display", 640, 120);
    if (!bottomDisplay)
    {
        return -1;
    }
    lv_display_set_default(bottomDisplay);
    lv_obj_t *bottomScr = display.create_bottom_screen();
    lv_screen_load(bottomScr);

    lv_display_t *mainDisplay = display.create_display(L"Main Display", 640, 360);
    if (!mainDisplay)
    {
        return -1;
    }
    lv_display_set_default(mainDisplay);
    GUIEventDispatcher::GetInstance();
    // bootup_manager_init();
    // Lấy HWND từng cửa sổ
    // struct SDL_Window * lv_sdl_window_get_window(lv_display_t * disp)
    SDL_Window *hwndLeft = lv_sdl_window_get_window(rightDisplay);    // RIGHT
    SDL_Window *hwndBottom = lv_sdl_window_get_window(bottomDisplay); // BOTTOM
    SDL_Window *hwndMaster = lv_sdl_window_get_window(mainDisplay);   // MAIN

    DockManager dockManager;
    // dockManager.setup(hwndMaster, hwndLeft, hwndBottom);

    /* Run the default demo */
    /* To try a different demo or example, replace this with one of: */
    /* - lv_demo_benchmark(); */
    /* - lv_demo_stress(); */
    /* - lv_example_label_1(); */
    /* - etc. */
    // lv_demo_widgets();

    while (1)
    {
        /* Periodically call the lv_task handler.
         * It could be done in a timer interrupt or an OS task too.*/
        uint32_t sleep_time_ms = lv_timer_handler();
        if (sleep_time_ms == LV_NO_TIMER_READY)
        {
            sleep_time_ms = LV_DEF_REFR_PERIOD;
        }
#ifdef _MSC_VER
        Sleep(sleep_time_ms);
#else
        usleep(sleep_time_ms * 1000);
#endif
    }

    return 0;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/