#include "GUIMenuManager.h"

GUIMenuManager::GUIMenuManager() : state(State::MAIN)
{
    Init();
}

GUIMenuManager::~GUIMenuManager()
{
}

std::string GUIMenuManager::GetStateName() const
{
    switch (state)
    {
    case State::MAIN:
        return "MAIN";
    default:
        return "UNKNOWN";
    }
}

void GUIMenuManager::Init()
{
    SetCurrentWindow(GUIMenuMainWindow::Id);
}

void GUIMenuManager::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    GUIWindowBase *current = GetCurrentWindow();

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case PressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case PressType::Short:
            if (state == State::MAIN)
            {
                GUIMenuMainWindow *current = (GUIMenuMainWindow *)GetCurrentWindow();
                int activeIndex = current->GetActiveIndex();

                switch (activeIndex)
                {
                case 0:
                    break;
                case 1:
                    break;
                default:
                    break;
                }
            }
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case PressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case PressType::Short:
            if (state == State::MAIN)
            {
                ctx.doBackToPreviousManager = true;
            }
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}
