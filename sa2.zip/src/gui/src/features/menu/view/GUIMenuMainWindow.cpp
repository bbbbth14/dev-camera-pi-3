#include "GUIMenuMainWindow.h"

GUIMenuMainWindow::GUIMenuMainWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIMenuMainWindow::~GUIMenuMainWindow()
{
}

void GUIMenuMainWindow::Init()
{
    GUIWindowLayoutBase::Init();

    GUIEngine::GetInstance().SetScreenGradient(scr, 0x024BA0, 0x080A2D);

    SetTitle("車両タイプ");
    SetTitleShadow();
    SetMessage("このエリアには選択している機能の概要が表示されます。");
    SetUpImage(LV_SYMBOL_UP);
    SetMenuOkImage(LV_SYMBOL_OK);
    SetDownImage(LV_SYMBOL_DOWN);
    SetMicOnOffImage(LV_SYMBOL_AUDIO);

    menuList = std::make_unique<List>(scr);
    menuList->Init();
    // menuList->SetActiveStylePath("C:activeListItem.png"); // Image file not found
    menuList->SetLocation(0, 72);
    menuList->SetSize(532, 240);
    menuList->AddItems({"軽自動車",
                        "軽自動車(ハイルーフ)",
                        "乗用車",
                        "乗用車(ハイルーフ)",
                        "大型トラック等",
                        "中型トラック等"});
}

void GUIMenuMainWindow::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    menuList->onKey(key, press, ctx);

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}
int GUIMenuMainWindow::GetActiveIndex()
{
    if (!menuList)
    {
        return -1;
    }

    return menuList->GetActiveIndex();
}