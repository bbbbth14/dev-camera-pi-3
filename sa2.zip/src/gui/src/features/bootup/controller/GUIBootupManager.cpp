#include "GUIBootupManager.h"

GUIBootupManager::GUIBootupManager() : state(State::BOOTUP)
{
    std::cout << "GUIBootupManager constructor called" << std::endl;
    Init();
    std::cout << "GUIBootupManager initialized, windows count: " << windows.size() << std::endl;
}

GUIBootupManager::~GUIBootupManager()
{
}

std::string GUIBootupManager::GetStateName() const
{
    switch (state)
    {
    case State::BOOTUP:
        return "BOOTUP";
    default:
        return "UNKNOWN";
    }
}

void GUIBootupManager::Init()
{
    // Create directly (factory registration may not include Bootup yet).
    windows.push_back(std::make_unique<GUIBootupWindow>());
}

void GUIBootupManager::ShowCurrentWindow()
{
    std::cout << "GUIBootupManager::ShowCurrentWindow() called" << std::endl;

    if (windows.empty())
    {
        Init();
    }

    // IMPORTANT: actually load the window's screen first.
    GUIWindowManagerBase::ShowCurrentWindow();

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    std::cout << "Got current window: " << (current ? "valid" : "null") << std::endl;
    if (current)
    {
        current->StartBootSequence();
    }
}

void GUIBootupManager::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (current)
    {
        current->onKey(key, press, ctx);
    }
}
