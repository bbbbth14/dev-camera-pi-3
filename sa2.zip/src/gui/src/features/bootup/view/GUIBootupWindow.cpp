#include "GUIBootupWindow.h"
#include "GUIEngine.h"
#include "GUIEventDispatcher.h"
#include "TextBox.h"

#include <filesystem>
#include <fstream>

GUIBootupWindow::GUIBootupWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIBootupWindow::~GUIBootupWindow()
{
    // Timers are auto-cleaned by GUIEngine when they fire
}

void GUIBootupWindow::Init()
{
    GUIWindowLayoutBase::Init();

    auto &eng = GUIEngine::GetInstance();

    // Set black background
    eng.SetScreenColor(scr, 0x000000);

    // Hide default buttons during bootup
    if (upButton)
        eng.HideObject(upButton->obj);
    if (menuOkButton)
        eng.HideObject(menuOkButton->obj);
    if (downButton)
        eng.HideObject(downButton->obj);
    if (micOnOffButton)
        eng.HideObject(micOnOffButton->obj);

    // Create logo/company name (centered)
    logoTextBox = std::make_unique<TextBox>(scr);
    logoTextBox->Init();
    logoTextBox->SetLocation(0, 120);
    logoTextBox->SetSize(640, 60);
    logoTextBox->SetText("THE COMPANY", 640, 60, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);

    // Create status text (centered below logo)
    statusTextBox = std::make_unique<TextBox>(scr);
    statusTextBox->Init();
    statusTextBox->SetLocation(0, 200);
    statusTextBox->SetSize(640, 30);
    statusTextBox->SetText("Starting...", 640, 30, GUIEngine::Font::NotoSansJP_Regular_16, 0xCCCCCC);

    // Second bootup screen: Warning (hidden initially)
    warningTextBox = std::make_unique<TextBox>(scr);
    warningTextBox->Init();
    warningTextBox->SetLocation(0, 160);
    warningTextBox->SetSize(640, 60);
    warningTextBox->SetText("Warning", 640, 60, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
    warningTextBox->Hide();

    // FEET/NON-FEET mode check screen (hidden initially)
    feetModeTextBox = std::make_unique<TextBox>(scr);
    feetModeTextBox->Init();
    feetModeTextBox->SetLocation(0, 160);
    feetModeTextBox->SetSize(640, 60);
    feetModeTextBox->SetText("Checking Mode...", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    feetModeTextBox->Hide();

    // Contract validation screen (hidden initially)
    contractTextBox = std::make_unique<TextBox>(scr);
    contractTextBox->Init();
    contractTextBox->SetLocation(0, 160);
    contractTextBox->SetSize(640, 60);
    contractTextBox->SetText("Validating Contract...", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    contractTextBox->Hide();

    warningShown = false;
    feetModeCheckShown = false;
    contractCheckShown = false;
}

void GUIBootupWindow::StartBootSequence()
{
    std::cout << "StartBootSequence() called" << std::endl;

    if (bootupTimer)
    {
        // Already running; avoid spawning multiple timers.
        std::cout << "Bootup timer already active, skipping re-start" << std::endl;
        return;
    }

    isFirstBoot = IsFirstBoot();
    std::cout << "Boot mode: " << (isFirstBoot ? "FIRST" : "SUBSEQUENT") << " boot" << std::endl;

    warningShown = false;
    setupPromptShown = false;
    imageShown = false;

    ShowImageStage();

    // Stage 0: Image display for 3 seconds, then transition to Stage 1 (bootup text)
    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer(
        [this]()
        {
            std::cout << "Stage 0 complete, transitioning to bootup text (Stage 1)" << std::endl;
            HideImageStage();
            imageShown = false;
            if (logoTextBox)
                logoTextBox->Show();
            if (statusTextBox)
                statusTextBox->Show();

            // Stage 1: Bootup text for 4 seconds, then transition to Stage 2 (warning)
            auto &eng = GUIEngine::GetInstance();
            bootupTimer = eng.CreateOneShotTimer(
                [this]()
                {
                    std::cout << "Stage 1 complete, transitioning to warning screen (Stage 2)" << std::endl;
                    ShowWarningScreen();

                    // Stage 2: Warning for 4 seconds, then transition to Stage 3 (FEET mode check)
                    auto &eng = GUIEngine::GetInstance();
                    bootupTimer = eng.CreateOneShotTimer(
                        [this]()
                        {
                            std::cout << "Stage 2 complete, checking FEET/NON-FEET mode (Stage 3)" << std::endl;
                            ShowFeetModeCheckScreen();

                            // Check FEET mode from user.json
                            if (!CheckFeetModeAndRebootIfNeeded())
                            {
                                // Mode changed, system will reboot
                                return;
                            }

                            // Stage 3: FEET mode OK, transition to Stage 4 (contract validation)
                            auto &eng = GUIEngine::GetInstance();
                            bootupTimer = eng.CreateOneShotTimer(
                                [this]()
                                {
                                    std::cout << "Stage 3 complete, validating contract (Stage 4)" << std::endl;
                                    ShowContractCheckScreen();

                                    // Check contract date from server.json
                                    if (!CheckContractDateAndShutdownIfExpired())
                                    {
                                        // Contract expired, system will shutdown
                                        return;
                                    }

                                    // Stage 4: Contract OK, transition to Stage 5 (setup prompt or main)
                                    auto &eng = GUIEngine::GetInstance();
                                    bootupTimer = eng.CreateOneShotTimer(
                                        [this]()
                                        {
                                            std::cout << "Stage 4 complete, proceeding to Stage 5" << std::endl;
                                            if (isFirstBoot)
                                            {
                                                setupPromptShown = true;
                                                if (warningTextBox)
                                                    warningTextBox->SetText("Enter the setup?\nPress MENU/OK on RIGHT", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
                                                if (warningTextBox)
                                                    warningTextBox->Show();

                                                // No automatic timer for Stage 5; waits for user input
                                                bootupTimer = nullptr;
                                            }
                                            else
                                            {
                                                // Subsequent boot: skip Stage 5 confirmation and go straight to main.
                                                setupPromptShown = false;
                                                bootupTimer = nullptr;
                                                CompleteBootup();
                                            }
                                        },
                                        Stage4ContractDurationMs);
                                },
                                Stage3FeetModeDurationMs);
                        },
                        Stage2DurationMs);
                },
                Stage1DurationMs);
        },
        Stage0DurationMs);

    std::cout << "Boot sequence started with stage timers" << std::endl;
}

void GUIBootupWindow::ShowImageStage()
{
    if (imageShown)
        return;

    imageShown = true;

    // Hide text elements
    if (logoTextBox)
        logoTextBox->Hide();
    if (statusTextBox)
        statusTextBox->Hide();
    if (warningTextBox)
        warningTextBox->Hide();

    // Create and display image
    if (!imageObj)
    {
        auto &eng = GUIEngine::GetInstance();
        imageObj = eng.CreateImageCentered(scr, "C:/BienTH/00.Learning/17.LVGL/1.Coding/the-company/src/gui/src/pf/aaa.png");
        std::cout << "Image stage displayed" << std::endl;
    }
}

void GUIBootupWindow::HideImageStage()
{
    if (!imageObj)
        return;

    auto &eng = GUIEngine::GetInstance();
    eng.DeleteObject(imageObj);
    imageObj = nullptr;
    std::cout << "Image stage hidden" << std::endl;
}

void GUIBootupWindow::ShowWarningScreen()
{
    if (warningShown)
        return;

    warningShown = true;

    if (logoTextBox)
        logoTextBox->Hide();
    if (statusTextBox)
        statusTextBox->Hide();

    if (warningTextBox)
        warningTextBox->SetText("Warning", 640, 60, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
    if (warningTextBox)
        warningTextBox->Show();
}

void GUIBootupWindow::ShowSystemUpdatePopupAndExit()
{
    if (systemUpdatePopupShown)
        return;

    systemUpdatePopupShown = true;

    auto &eng = GUIEngine::GetInstance();

    // Full-screen transparent overlay to behave like a popup.
    if (!systemUpdateOverlay)
        systemUpdateOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!systemUpdateCard)
    {
        systemUpdateCard = eng.CreateCardCentered(systemUpdateOverlay, 440, 170, 0xFFFFFF, 8);
        eng.SetShadow(systemUpdateCard, 0, 6, 20, 0.35f, 0x000000);
    }

    systemUpdateTitleTextBox = std::make_unique<TextBox>(systemUpdateCard);
    systemUpdateTitleTextBox->Init();
    systemUpdateTitleTextBox->SetLocation(0, 22);
    systemUpdateTitleTextBox->SetSize(440, 50);
    systemUpdateTitleTextBox->SetText("System Update", 440, 50, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    systemUpdateCountdownTextBox = std::make_unique<TextBox>(systemUpdateCard);
    systemUpdateCountdownTextBox->Init();
    systemUpdateCountdownTextBox->SetLocation(0, 92);
    systemUpdateCountdownTextBox->SetSize(440, 40);
    systemUpdateCountdownTextBox->SetText("Hide in 4s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);

    // Countdown updates (4 -> 1), then hide at 4 seconds and proceed.
    eng.CreateOneShotTimer(
        [this]()
        {
            if (systemUpdateCountdownTextBox)
                systemUpdateCountdownTextBox->SetText("Hide in 3s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        1000);

    eng.CreateOneShotTimer(
        [this]()
        {
            if (systemUpdateCountdownTextBox)
                systemUpdateCountdownTextBox->SetText("Hide in 2s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        2000);

    eng.CreateOneShotTimer(
        [this]()
        {
            if (systemUpdateCountdownTextBox)
                systemUpdateCountdownTextBox->SetText("Hide in 1s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        3000);

    eng.CreateOneShotTimer(
        [this]()
        {
            HideSystemUpdatePopup();
            GUIEventDispatcher::GetInstance().onSetupRequested();
        },
        SystemUpdatePopupDurationMs);
}

void GUIBootupWindow::HideSystemUpdatePopup()
{
    if (!systemUpdatePopupShown)
        return;

    systemUpdatePopupShown = false;

    systemUpdateTitleTextBox.reset();
    systemUpdateCountdownTextBox.reset();

    if (systemUpdateOverlay)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(systemUpdateOverlay);
    }

    systemUpdateOverlay = nullptr;
    systemUpdateCard = nullptr;
}

void GUIBootupWindow::CompleteBootup()
{
    std::cout << "CompleteBootup() called, isFirstBoot=" << (isFirstBoot ? "true" : "false") << std::endl;
    // Timer auto-cleaned by GUIEngine when it fires
    bootupTimer = nullptr;

    if (isFirstBoot)
    {
        std::cout << "First boot detected - marking first boot done" << std::endl;
        // Mark first boot done so next run becomes 'subsequent'.
        MarkFirstBootDone();

        // First boot: keep existing behavior (popup) before leaving bootup.
        ShowSystemUpdatePopupAndExit();
    }
    else
    {
        std::cout << "Subsequent boot - notifying to show driving advice" << std::endl;
        // Subsequent boot: go directly to main and show Driving Advice popup for 4s.
        GUIEventDispatcher::GetInstance().NotifyShowDrivingAdviceOnNextHome();
        GUIEventDispatcher::GetInstance().onSetupRequested();
    }
}

bool GUIBootupWindow::IsFirstBoot() const
{
    try
    {
        // Running from src/build; store marker next to GUI assets in src/gui/src/pf.
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        const auto marker = markerDir / "first_boot_done.json";
        std::cout << "First-boot marker path: " << marker.string() << std::endl;
        return !std::filesystem::exists(marker);
    }
    catch (...)
    {
        // If we can't read/write filesystem, behave as first boot (safer).
        return true;
    }
}

void GUIBootupWindow::MarkFirstBootDone() const
{
    try
    {
        // Running from src/build; store marker next to GUI assets in src/gui/src/pf.
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        std::filesystem::create_directories(markerDir);
        const auto marker = markerDir / "first_boot_done.json";

        std::cout << "Writing first-boot marker to: " << marker.string() << std::endl;

        std::ofstream out(marker.string(), std::ios::out | std::ios::trunc);
        if (!out.is_open())
        {
            std::cout << "ERROR: Failed to open file for writing!" << std::endl;
            return;
        }
        
        out << "{\n  \"first_boot_done\": true\n}\n";
        out.close();
        
        std::cout << "Successfully wrote first_boot_done: true to file" << std::endl;
    }
    catch (const std::exception &e)
    {
        std::cout << "ERROR in MarkFirstBootDone: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "ERROR: Unknown exception in MarkFirstBootDone" << std::endl;
    }
}

void GUIBootupWindow::ShowFeetModeCheckScreen()
{
    if (feetModeCheckShown)
        return;

    feetModeCheckShown = true;

    if (logoTextBox)
        logoTextBox->Hide();
    if (statusTextBox)
        statusTextBox->Hide();
    if (warningTextBox)
        warningTextBox->Hide();

    if (feetModeTextBox)
    {
        feetModeTextBox->SetText("Checking FEET Mode...", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        feetModeTextBox->Show();
    }
}

void GUIBootupWindow::ShowContractCheckScreen()
{
    if (contractCheckShown)
        return;

    contractCheckShown = true;

    if (feetModeTextBox)
        feetModeTextBox->Hide();

    if (contractTextBox)
    {
        contractTextBox->SetText("Validating Contract...", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        contractTextBox->Show();
    }
}

std::string GUIBootupWindow::ReadJsonStringField(const std::string &filePath, const std::string &fieldName) const
{
    try
    {
        std::ifstream file(filePath);
        if (!file.is_open())
        {
            std::cout << "Failed to open JSON file: " << filePath << std::endl;
            return "";
        }

        std::string line;
        while (std::getline(file, line))
        {
            // Simple JSON parsing for "fieldName": "value"
            size_t pos = line.find("\"" + fieldName + "\"");
            if (pos != std::string::npos)
            {
                size_t colonPos = line.find(":", pos);
                if (colonPos != std::string::npos)
                {
                    size_t firstQuote = line.find("\"", colonPos);
                    if (firstQuote != std::string::npos)
                    {
                        size_t secondQuote = line.find("\"", firstQuote + 1);
                        if (secondQuote != std::string::npos)
                        {
                            return line.substr(firstQuote + 1, secondQuote - firstQuote - 1);
                        }
                    }
                }
            }
        }
        return "";
    }
    catch (...)
    {
        std::cout << "Exception reading JSON file: " << filePath << std::endl;
        return "";
    }
}

bool GUIBootupWindow::CheckFeetModeAndRebootIfNeeded()
{
    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto userJsonPath = configDir / "user.json";

    std::cout << "Checking FEET mode from: " << userJsonPath.string() << std::endl;

    std::string newMode = ReadJsonStringField(userJsonPath.string(), "mode");
    if (newMode.empty())
    {
        std::cout << "user.json not found or mode field missing, assuming mode is OK" << std::endl;
        if (feetModeTextBox)
            feetModeTextBox->SetText("Mode: OK (default)", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        return true; // Continue boot
    }

    // Read current mode from persistent storage (for simplicity, we'll use a mode.json file)
    const auto currentModeJsonPath = configDir / "current_mode.json";
    std::string currentMode = ReadJsonStringField(currentModeJsonPath.string(), "mode");

    std::cout << "Current mode: '" << currentMode << "', New mode: '" << newMode << "'" << std::endl;

    if (currentMode.empty())
    {
        // First time, save the mode
        std::cout << "No current mode found, saving new mode: " << newMode << std::endl;
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (feetModeTextBox)
            feetModeTextBox->SetText("Mode: " + newMode, 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        return true; // Continue boot
    }

    if (currentMode != newMode)
    {
        std::cout << "Mode changed from '" << currentMode << "' to '" << newMode << "', saving and restarting boot sequence..." << std::endl;

        // Save new mode
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (feetModeTextBox)
            feetModeTextBox->SetText("Current: " + currentMode + "\nChange to: " + newMode + "\nRestarting...", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFF00);

        RestartBootSequence();
        return false; // Stop current boot sequence
    }

    std::cout << "Mode unchanged: " << currentMode << std::endl;
    if (feetModeTextBox)
        feetModeTextBox->SetText("Mode: " + currentMode + " (OK)", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    return true; // Continue boot
}

bool GUIBootupWindow::CheckContractDateAndShutdownIfExpired()
{
    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto serverJsonPath = configDir / "server.json";

    std::cout << "Checking contract date from: " << serverJsonPath.string() << std::endl;

    std::string contractDate = ReadJsonStringField(serverJsonPath.string(), "contract_date");
    if (contractDate.empty())
    {
        std::cout << "server.json not found or contract_date field missing, assuming contract is OK" << std::endl;
        if (contractTextBox)
            contractTextBox->SetText("Contract: OK (default)", 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        return true; // Continue boot
    }

    std::cout << "Contract date: " << contractDate << std::endl;

    // Update the screen to show the contract date
    if (contractTextBox)
        contractTextBox->SetText("Contract: " + contractDate, 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    // Check if contract_date is literal "expired" or "invalid", or if date is in the past
    if (contractDate == "expired" || contractDate == "invalid" || IsDateExpired(contractDate))
    {
        std::cout << "Contract EXPIRED or INVALID! Shutting down..." << std::endl;

        if (contractTextBox)
            contractTextBox->SetText("Contract: " + contractDate + "\nEXPIRED! Shutting Down...", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFF0000);

        SystemShutdown();
        return false; // Stop boot sequence
    }

    std::cout << "Contract valid until: " << contractDate << std::endl;
    if (contractTextBox)
        contractTextBox->SetText("Contract: " + contractDate, 640, 60, GUIEngine::Font::NotoSansJP_Regular_24, 0x00FF00);

    return true; // Continue boot
}

void GUIBootupWindow::RestartBootSequence()
{
    std::cout << "=== RESTARTING BOOT SEQUENCE ==="<< std::endl;
    // Wait 2 seconds to show the mode change message, then restart from Stage 0
    auto &eng = GUIEngine::GetInstance();
    eng.CreateOneShotTimer(
        [this]()
        {
            std::cout << "Restarting boot sequence from Stage 0..." << std::endl;
            
            // Reset all state flags
            warningShown = false;
            feetModeCheckShown = false;
            contractCheckShown = false;
            setupPromptShown = false;
            imageShown = false;
            systemUpdatePopupShown = false;
            
            // Hide all TextBoxes
            if (logoTextBox)
                logoTextBox->Hide();
            if (statusTextBox)
                statusTextBox->Hide();
            if (warningTextBox)
                warningTextBox->Hide();
            if (feetModeTextBox)
                feetModeTextBox->Hide();
            if (contractTextBox)
                contractTextBox->Hide();
            
            // Clean up any timers
            if (bootupTimer)
                bootupTimer = nullptr;
            
            // Start boot sequence from beginning
            StartBootSequence();
        },
        2000);
}

bool GUIBootupWindow::IsDateExpired(const std::string &dateStr) const
{
    try
    {
        // Parse date in YYYY-MM-DD format
        if (dateStr.length() < 10)
            return false; // Invalid format, treat as not expired

        int year = std::stoi(dateStr.substr(0, 4));
        int month = std::stoi(dateStr.substr(5, 2));
        int day = std::stoi(dateStr.substr(8, 2));

        // Current date: 2026-01-12 (January 12, 2026)
        const int currentYear = 2026;
        const int currentMonth = 1;
        const int currentDay = 12;

        // Compare dates
        if (year < currentYear)
            return true; // Expired
        if (year > currentYear)
            return false; // Future date

        // Same year, compare month
        if (month < currentMonth)
            return true; // Expired
        if (month > currentMonth)
            return false; // Future date

        // Same year and month, compare day
        if (day < currentDay)
            return true; // Expired

        return false; // Today or future
    }
    catch (...)
    {
        std::cout << "Error parsing date: " << dateStr << ", treating as valid" << std::endl;
        return false; // If we can't parse, don't block boot
    }
}

void GUIBootupWindow::SystemReboot()
{
    std::cout << "=== SYSTEM REBOOT REQUESTED ===" << std::endl;
    // In a real system, this would trigger a hardware reboot or restart the application
    // For simulation, we'll just delay and exit (user can restart manually)
    auto &eng = GUIEngine::GetInstance();
    eng.CreateOneShotTimer(
        []()
        {
            std::cout << "Rebooting now... (exiting application)" << std::endl;
            std::exit(0); // Exit with success code (user can restart)
        },
        2000); // 2 second delay to show the message
}

void GUIBootupWindow::SystemShutdown()
{
    std::cout << "=== SYSTEM SHUTDOWN REQUESTED ===" << std::endl;
    // In a real system, this would trigger a hardware shutdown
    // For simulation, we'll exit immediately
    auto &eng = GUIEngine::GetInstance();
    eng.CreateOneShotTimer(
        []()
        {
            std::cout << "Shutting down now... (exiting application)" << std::endl;
            std::exit(1); // Exit with error code to indicate shutdown
        },
        2000); // 2 second delay to show the message
}

void GUIBootupWindow::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    if (!setupPromptShown)
        return;

    // Stage 5 confirmation: accept only if the MENU/OK action came from RIGHT display.
    if (key == Key::MENU_OK && press == PressType::Short)
    {
        if (GUIEventDispatcher::GetInstance().ConsumeRightMenuOkClicked())
        {
            CompleteBootup();
        }
    }
}
