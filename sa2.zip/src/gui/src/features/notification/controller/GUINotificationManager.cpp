#include "GUINotificationManager.h"

GUINotificationManager::GUINotificationManager()
{
}

GUINotificationManager::~GUINotificationManager()
{
}

GUINotificationManager &GUINotificationManager::GetInstance()
{
    static GUINotificationManager instance;
    return instance;
}

GUIPopupBase *GUINotificationManager::GetCurrentPopup()
{
    return popup.get();
}

void GUINotificationManager::SetCurrentPopup(std::string name)
{
    if (popup)
    {
        popup.reset();
    }

    popup = std::move(GUIPopupFactory::GetInstance().Create(name));
}

void GUINotificationManager::OpenCurrentPopup()
{
    if (popup)
    {
        popup->Open();

        // Tạo timer 3 giây, one-shot
        GUIEngine::GetInstance().CreateOneShotTimer([]()
                                                    { GUINotificationManager::GetInstance().CloseCurrentPopup(); }, 3000);
    }
}
void GUINotificationManager::CloseCurrentPopup()
{
    std::cout << "CloseCurrentPopup";
    if (popup)
    {
        popup->Close();
    }
}
void GUINotificationManager::onShockDetected()
{
    SetCurrentPopup(GUIEventPopup::Id);

    GUIEventPopup *local_popup = (GUIEventPopup *)popup.get();
    local_popup->SetAlertType(GUIEventPopup::DrivingAlert::ShockDetected);
    OpenCurrentPopup();
}
void GUINotificationManager::onLongDrivingAttention()
{
    SetCurrentPopup(GUIEventPopup::Id);

    GUIEventPopup *local_popup = (GUIEventPopup *)popup.get();
    local_popup->SetAlertType(GUIEventPopup::DrivingAlert::LongDrivingAttention);
    OpenCurrentPopup();
}