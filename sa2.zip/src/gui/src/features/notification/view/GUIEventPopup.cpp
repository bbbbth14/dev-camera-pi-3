#include "GUIEventPopup.h"

GUIEventPopup::GUIEventPopup(lv_obj_t *scr) : GUIPopupBase(scr)
{
}

GUIEventPopup::~GUIEventPopup()
{
    // Close();
}

void GUIEventPopup::Close()
{
    GUIPopupBase::Close();

    auto &eng = GUIEngine::GetInstance();

    if (rectangle)
    {
        eng.DeleteObject(rectangle);
        rectangle = nullptr;
    }
    if (centerCircle)
    {
        eng.DeleteObject(centerCircle);
        centerCircle = nullptr;
    }
    if (icon)
    {
        eng.DeleteObject(icon);
        icon = nullptr;
    }
    if (text)
    {
        eng.DeleteObject(text);
        text = nullptr;
    }
}
void GUIEventPopup::Init()
{
    auto &eng = GUIEngine::GetInstance();

    if (!dlg)
    {
        dlg = eng.CreateCardCentered(scr, 480, 184, 0xFFFFFF, 10);

        if (dlg == nullptr)
        {
            return;
        }
    }
    if (dlg && !rectangle)
    {
        rectangle = eng.CreateRectangleAbsoluteTransparent(dlg, 100, 100, 190, 20);

        if (rectangle == nullptr)
        {
            return;
        }
    }
    if (rectangle && !centerCircle)
    {
        centerCircle = eng.CreateCircleCentered(rectangle, 100, 0xFF7338);

        if (centerCircle == nullptr)
        {
            return;
        }
    }

    ApplyAlert();
}
void GUIEventPopup::ApplyAlert()
{
    auto &eng = GUIEngine::GetInstance();

    // Cache asset một lần để tránh lặp gọi
    const auto asset = GetAlertAsset(currentType);

    if (centerCircle && !icon)
    {
        icon = eng.CreateImageAbsolute(centerCircle, asset.iconPath.c_str(), 9, 10);
    }
    if (dlg && !text)
    {
        text = eng.CreateLabelAbsoluteTextCentered(dlg, asset.text.c_str(), 448, 34, GUIEngine::Font::NotoSansJP_Regular_28, 16, 134, 0x000000);
    }
}

void GUIEventPopup::SetAlertType(DrivingAlert type)
{
    if (currentType == type)
    {
        // Không đổi -> bỏ qua
        return;
    }

    currentType = type;

    auto &eng = GUIEngine::GetInstance();
    // Khi đổi loại alert, làm mới icon + text
    if (icon)
    {
        eng.DeleteObject(icon);
        icon = nullptr;
    }
    if (text)
    {
        eng.DeleteObject(text);
        text = nullptr;
    }

    ApplyAlert();
}