#include "GUIEventBase.h"

GUIEventBase::GUIEventBase()
{
}

GUIEventBase::~GUIEventBase()
{
}

void GUIEventBase::onKey(Key key, PressType press, KeyActionContext &ctx)
{
}

void GUIEventBase::onShockDetected()
{
}

void GUIEventBase::onMotionDetected()
{
}

void GUIEventBase::onUnauthorizedAccess()
{
}

void GUIEventBase::onLongDrivingAttention()
{
}

void GUIEventBase::onVehicleSpeedChanged(float vehicleSpeed, KeyActionContext &ctx)
{
}

void GUIEventBase::on4GSignalStrengthChanged(int strength)
{
}