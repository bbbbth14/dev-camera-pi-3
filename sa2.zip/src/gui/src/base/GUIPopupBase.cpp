#include "GUIPopupBase.h"
GUIPopupBase::GUIPopupBase(lv_obj_t *scr)
{
    this->scr = scr;
}

GUIPopupBase::~GUIPopupBase()
{
}

void GUIPopupBase::Open()
{
    if (scr)
    {
        Init();
        GUIEngine::GetInstance().ShowObject(dlg);
    }
}
void GUIPopupBase::Close()
{
    if (dlg)
    {
        GUIEngine::GetInstance().DeleteObject(dlg);
        dlg = nullptr;
    }
}
