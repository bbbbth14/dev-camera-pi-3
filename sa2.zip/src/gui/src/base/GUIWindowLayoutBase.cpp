#include "GUIWindowLayoutBase.h"

GUIWindowLayoutBase::GUIWindowLayoutBase()
{
}

GUIWindowLayoutBase::~GUIWindowLayoutBase()
{
}

void GUIWindowLayoutBase::Init()
{
    scr = GUIEngine::GetInstance().CreateScreenCentered(nullptr);

    titleTextBox = std::make_unique<TextBox>(scr);
    titleTextBox->Init();
    titleTextBox->SetLocation(0, 0);
    titleTextBox->SetSize(640, 50);
    // titleTextBox->SetShadow(0, 3, 10, 0.7, 0x000000);

    messageTextBox = std::make_unique<TextBox>(scr);
    messageTextBox->Init();
    messageTextBox->SetLocation(16, 328);
    messageTextBox->SetSize(420, 22);

    upButton = std::make_unique<Button>(scr);
    upButton->Init();
    upButton->SetLocation(592, 64);
    upButton->SetSize(48, 88);

    menuOkButton = std::make_unique<Button>(scr);
    menuOkButton->Init();
    menuOkButton->SetLocation(592, 152);
    menuOkButton->SetSize(48, 88);

    downButton = std::make_unique<Button>(scr);
    downButton->Init();
    downButton->SetLocation(592, 240);
    downButton->SetSize(48, 88);

    micOnOffButton = std::make_unique<Button>(scr);
    micOnOffButton->Init();
    micOnOffButton->SetLocation(452, 312);
    micOnOffButton->SetSize(88, 48);
}

void GUIWindowLayoutBase::SetTitle(const std::string &title)
{
    if (this->title != title)
    {
        this->title = title;
        titleTextBox->SetText(this->title, 640, 50, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
    }
}
void GUIWindowLayoutBase::SetTitleShadow()
{
    if (this->titleTextBox)
    {
        titleTextBox->SetShadow(0, 3, 10, 0.7, 0x000000);
    }
}

void GUIWindowLayoutBase::SetMessage(const std::string &message)
{
    if (this->message != message)
    {
        this->message = message;
        messageTextBox->SetText(this->message, 420, 22, GUIEngine::Font::NotoSansJP_Regular_16, 0x67D1FF);
    }
}

void GUIWindowLayoutBase::SetUpImage(const std::string &path)
{
    if (this->upImagePath != path)
    {
        this->upImagePath = path;
        upButton->SetImage(this->upImagePath);
    }
}

void GUIWindowLayoutBase::SetMenuOkImage(const std::string &path)
{
    if (this->menuOkImagePath != path)
    {
        this->menuOkImagePath = path;
        menuOkButton->SetImage(this->menuOkImagePath);
    }
}

void GUIWindowLayoutBase::SetDownImage(const std::string &path)
{
    if (this->downImagePath != path)
    {
        this->downImagePath = path;
        downButton->SetImage(this->downImagePath);
    }
}

void GUIWindowLayoutBase::SetMicOnOffImage(const std::string &path)
{
    if (this->micOnOffImagePath != path)
    {
        this->micOnOffImagePath = path;
        micOnOffButton->SetImage(this->micOnOffImagePath);
    }
}