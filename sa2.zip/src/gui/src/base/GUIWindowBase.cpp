#include "GUIWindowBase.h"

GUIWindowBase::GUIWindowBase()
{
}

GUIWindowBase::~GUIWindowBase()
{
}

void GUIWindowBase::Show()
{
    if (scr)
    {
        GUIEngine::GetInstance().ShowScreen(scr);
    }
}
