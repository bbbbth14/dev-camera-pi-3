#include "Network4G.h"

Network4G::Network4G(lv_obj_t *parent) : ComponentBase(parent)
{
}
Network4G::~Network4G()
{
}
void Network4G::Init()
{
    ComponentBase::Init();
}

void Network4G::SetSignalStrength(int strength)
{
    if (this->strength != strength)
    {
        this->strength = strength;

        switch (this->strength)
        {
        case -1:
            SetImage(LV_SYMBOL_CLOSE); // No signal
            break;
        case 0:
            SetImage(LV_SYMBOL_WIFI); // 0 bars
            break;
        case 1:
            SetImage(LV_SYMBOL_WIFI); // 1 bar
            break;
        case 2:
            SetImage(LV_SYMBOL_WIFI); // 2 bars
            break;
        case 3:
            SetImage(LV_SYMBOL_WIFI); // 3 bars
            break;
        case 4:
            SetImage(LV_SYMBOL_WIFI); // 4 bars (full)
            break;
        default:
            break;
        }
    }
}