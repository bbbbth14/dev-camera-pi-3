#include "List.h"
List::List(lv_obj_t *parent) : ComponentBase(parent)
{
}
List::~List()
{
    auto &eng = GUIEngine::GetInstance();

    if (list)
    {
        eng.DeleteObject(list);
        list = nullptr;
    }

    items.clear();
}

void List::Init()
{
    ComponentBase::Init();

    auto &eng = GUIEngine::GetInstance();

    list = eng.CreateRawObject(obj);

    eng.SetLocation(list, 30, 0);
    eng.SetSize(list, 502, 240);
    eng.SetFlexFlowCol(list);
}
void List::SetActiveStylePath(const std::string &path)
{
    if (activeStylePath != path)
    {
        activeStylePath = path;

        auto &eng = GUIEngine::GetInstance();

        if (activeStyle)
        {
            eng.DeleteObject(activeStyle);
            activeStyle = nullptr;
        }
        // Tạo tạm thời dưới list, sau đó sẽ reparent sang row active
        activeStyle = eng.CreateImageCentered(list, activeStylePath.c_str());
        eng.HideObject(activeStyle);
    }
}

void List::AddItem(const std::string &text)
{
    if (!list)
        return;

    auto &eng = GUIEngine::GetInstance();

    // Container của row
    lv_obj_t *row = eng.CreateRawObject(list);
    eng.SetSize(row, 502, 40);
    eng.SetAlign(row, LV_ALIGN_RIGHT_MID);

    lv_obj_t *label = eng.CreateLabelCenteredTextLeft(
        row, text.c_str(),
        470, 40,
        GUIEngine::Font::NotoSansJP_Regular_24,
        0xFFFFFF);
    eng.SetAlignRight(label, 24, 0);

    // Thêm vào danh sách items (lưu cả text và row)
    items.push_back({text, row, label});

    // Nếu đây là item đầu tiên, gán active
    if (activeIndex == -1)
    {
        SetActiveIndex(0);
    }
}
void List::AddItems(std::initializer_list<std::string> texts)
{
    if (!list || texts.size() == 0)
        return;

    items.reserve(items.size() + texts.size()); // tối ưu: tránh realloc nhiều lần

    for (const auto &t : texts)
    {
        AddItem(t);
    }
}
void List::RemoveItem(int id)
{
    if (id < 0 || id >= static_cast<int>(items.size()))
        return;

    auto &eng = GUIEngine::GetInstance();

    auto &it = items[id];
    if (it.row)
    {
        eng.DeleteObject(it.row);
    }
    items.erase(items.begin() + id);

    // Điều chỉnh activeIndex sau khi xoá
    if (items.empty())
    {
        activeIndex = -1;
        return;
    }
    if (activeIndex == id)
    {
        // Item active bị xoá → chọn item gần nhất phía trên (hoặc 0)
        int lastId = static_cast<int>(items.size()) - 1;
        int newIndex = ((id) < (lastId)) ? (id) : (lastId);
        SetActiveIndex(newIndex);
    }
    else if (activeIndex > id)
    {
        // Dồn index xuống 1 do đã xoá trước đó
        activeIndex--;
    }
}

void List::RemoveItems()
{
    auto &eng = GUIEngine::GetInstance();

    for (auto &it : items)
    {
        if (it.row)
        {
            eng.DeleteObject(it.row);
        }
    }
    items.clear();

    activeIndex = -1;
}

int List::GetActiveIndex()
{
    return activeIndex;
}

bool List::SetActiveIndex(int newIndex)
{
    if (items.empty())
        return false;
    if (newIndex < 0 || newIndex >= static_cast<int>(items.size()))
        return false;

    int old = activeIndex;
    activeIndex = newIndex;

    // Cập nhật UI
    if (old != newIndex)
    {
        UpdateActiveUI(newIndex);
    }
    return true;
}

bool List::MoveActiveUp()
{
    bool wrap = true;

    if (items.empty())
        return false;
    if (activeIndex == -1)
    {
        return SetActiveIndex(0);
    }

    int newIndex = activeIndex - 1;
    if (newIndex < 0)
    {
        if (wrap)
            newIndex = static_cast<int>(items.size()) - 1;
        else
            newIndex = 0;
    }
    return SetActiveIndex(newIndex);
}

bool List::MoveActiveDown()
{
    bool wrap = true;

    if (items.empty())
        return false;
    if (activeIndex == -1)
    {
        return SetActiveIndex(0);
    }

    int newIndex = activeIndex + 1;
    if (newIndex >= static_cast<int>(items.size()))
    {
        if (wrap)
            newIndex = 0;
        else
            newIndex = static_cast<int>(items.size()) - 1;
    }
    return SetActiveIndex(newIndex);
}

void List::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case PressType::Short:
            MoveActiveUp();
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        break;
    case Key::DOWN:
        switch (press)
        {
        case PressType::Short:
            MoveActiveDown();
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}

void List::UpdateActiveUI(int newIndex)
{
    if (newIndex >= 0)
    {
        auto &it = items[newIndex];
        auto &eng = GUIEngine::GetInstance();
        eng.SetParent(activeStyle, it.row);
        eng.ShowObject(activeStyle);
        eng.SendToBottom(activeStyle);
    }
}
