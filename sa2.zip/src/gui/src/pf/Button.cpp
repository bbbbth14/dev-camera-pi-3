#include "Button.h"

Button::Button(lv_obj_t *parent) : ComponentBase(parent)
{
}
Button::~Button()
{
}
void Button::Init()
{
    ComponentBase::Init();
}
