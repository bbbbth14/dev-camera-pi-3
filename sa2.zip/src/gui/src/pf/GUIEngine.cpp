#include "GUIEngine.h"

GUIEngine::GUIEngine()
{
    Init();
}
GUIEngine::~GUIEngine()
{
    ReleaseFont();
}

bool DoesFileExists(const char *path)
{
    lv_fs_file_t file;
    lv_fs_res_t res = lv_fs_open(&file, path, LV_FS_MODE_RD);
    if (res == LV_FS_RES_OK)
    {
        lv_fs_close(&file);
        return true; // File tồn tại
    }
    return false; // Không tồn tại hoặc lỗi
}

void GUIEngine::Init()
{
    std::wcout << "Check file system\n";
    // File check disabled - using default resources
    // if (DoesFileExists("C:icon_alert_shock.png"))
    // {
    //     std::wcout << "Check file system OK\n";
    // }
    // else
    // {
    //     std::wcout << "Check file system NG\n";
    // }

    std::wcout << "System Current Path\n";
    printf("System Current Path = %s\n", std::filesystem::current_path().string().c_str());
    // visual studio
    // constexpr const char *FONT_PATH = "./gui/src/pf/NotoSansJP-Regular.ttf";

    // vscode
    // Copy font NotoSansJP-Regular.ttf to C:\Users\CanhNN2\Downloads\src\gitlab\gui\bin
    constexpr const char *FONT_PATH = ".bin/NotoSansJP-Regular.ttf";

    auto loadFont = [](const char *path, uint32_t size) -> lv_font_t *
    {
        lv_font_t *font = lv_freetype_font_create(path,
                                                  LV_FREETYPE_FONT_RENDER_MODE_BITMAP,
                                                  size,
                                                  LV_FREETYPE_FONT_STYLE_NORMAL);
        if (!font)
        {
            LV_LOG_ERROR("Failed to load font: %s (size: %u)", path, size);
        }
        return font;
    };

    notoSansJP_Regular_28_font = loadFont(FONT_PATH, 28);
    notoSansJP_Regular_24_font = loadFont(FONT_PATH, 24);
    notoSansJP_Regular_16_font = loadFont(FONT_PATH, 16);
}

GUIEngine &GUIEngine::GetInstance()
{
    static GUIEngine instance;
    return instance;
}

void GUIEngine::SetRightDisplay(lv_display_t *disp)
{
    rightDisplay = disp;
}

lv_display_t *GUIEngine::GetRightDisplay() const
{
    return rightDisplay;
}

lv_font_t *GUIEngine::GetFont(Font font)
{
    switch (font)
    {
    case Font::NotoSansJP_Regular_28:
        return notoSansJP_Regular_28_font;
    case Font::NotoSansJP_Regular_24:
        return notoSansJP_Regular_24_font;
    case Font::NotoSansJP_Regular_16:
        return notoSansJP_Regular_16_font;
    default:
        LV_LOG_WARN("GetFont: Unknown font enum value");
        return nullptr;
    }
}

void GUIEngine::ReleaseFont()
{
    if (notoSansJP_Regular_28_font)
    {
        lv_freetype_font_delete(notoSansJP_Regular_28_font);
        notoSansJP_Regular_28_font = nullptr;
    }

    if (notoSansJP_Regular_24_font)
    {
        lv_freetype_font_delete(notoSansJP_Regular_24_font);
        notoSansJP_Regular_24_font = nullptr;
    }

    if (notoSansJP_Regular_16_font)
    {
        lv_freetype_font_delete(notoSansJP_Regular_16_font);
        notoSansJP_Regular_16_font = nullptr;
    }
}

void GUIEngine::ShowScreen(lv_obj_t *scr)
{
    if (!scr)
    {
        LV_LOG_ERROR("ShowScreen: invalid screen object");
        return;
    }
    lv_scr_load(scr);
}

lv_obj_t *GUIEngine::CreateScreenCentered(lv_obj_t *parent)
{
    // if (!parent) {
    //     LV_LOG_ERROR("CreateScreen: invalid parent");
    //     return nullptr;
    // }

    lv_obj_t *scr = lv_obj_create(parent);
    if (!scr)
    {
        LV_LOG_ERROR("CreateScreen: lv_obj_create failed");
        return nullptr;
    }

    lv_obj_center(scr);
    return scr;
}
void GUIEngine::SetScreenColor(lv_obj_t *scr, uint32_t color)
{
    if (!scr)
    {
        LV_LOG_ERROR("SetScreenGradient: invalid screen object");
        return;
    }

    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    lv_obj_set_style_bg_color(scr, lv_color_hex(color), sel);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, sel);
}
void GUIEngine::SetScreenGradient(lv_obj_t *scr, uint32_t color_top, uint32_t color_bottom)
{
    if (!scr)
    {
        LV_LOG_ERROR("SetScreenGradient: invalid screen object");
        return;
    }

    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    lv_obj_set_style_bg_color(scr, lv_color_hex(color_top), sel);
    lv_obj_set_style_bg_grad_color(scr, lv_color_hex(color_bottom), sel);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, sel);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, sel);
}

lv_obj_t *GUIEngine::CreateRawObject(lv_obj_t *parent)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateRawObject: invalid parent");
        return nullptr;
    }

    lv_obj_t *obj = lv_obj_create(parent);
    if (!obj)
    {
        LV_LOG_ERROR("CreateRawObject: lv_obj_create failed");
        return nullptr;
    }

    // Xoá toàn bộ style mặc định để làm "raw object"
    lv_obj_remove_style_all(obj);

    // static lv_style_t style_card_border;
    // lv_style_init(&style_card_border);
    ////lv_style_set_bg_color(&style_card_border, lv_color_hex(0x000000)); // nền trắng (nếu cần)
    //// viền
    // lv_style_set_border_width(&style_card_border, 2);                  // 2px
    // lv_style_set_border_color(&style_card_border, lv_color_hex(0x000000));
    // lv_obj_add_style(obj, &style_card_border, LV_STATE_DEFAULT);

    return obj;
}

void GUIEngine::SetLocation(lv_obj_t *obj, int x, int y)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetLocation: invalid obj");
        return;
    }
    lv_obj_set_pos(obj, x, y);
}
int GUIEngine::GetLocationX(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("GetLocationX: invalid obj");
        return -1;
    }
    return lv_obj_get_x(obj);
}
int GUIEngine::GetLocationY(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("GetLocationY: invalid obj");
        return -1;
    }
    return lv_obj_get_y(obj);
}
void GUIEngine::SetSize(lv_obj_t *obj, int w, int h)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetSize: invalid obj");
        return;
    }
    lv_obj_set_size(obj, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));
}
int GUIEngine::GetSizeW(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("GetSizeW: invalid obj");
        return -1;
    }
    return lv_obj_get_width(obj);
}
int GUIEngine::GetSizeH(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("GetSizeH: invalid obj");
        return -1;
    }
    return lv_obj_get_height(obj);
}
void GUIEngine::SetAlign(lv_obj_t *obj, lv_align_t align)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetAlign: invalid obj");
        return;
    }
    lv_obj_set_align(obj, align);
}
void GUIEngine::SetAlignRight(lv_obj_t *obj, int x, int y)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetAlign: invalid obj");
        return;
    }
    lv_obj_align(obj, LV_ALIGN_RIGHT_MID, x, y);
}
void GUIEngine::SetAlignCenter(lv_obj_t *obj, int x, int y)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetAlign: invalid obj");
        return;
    }
    lv_obj_align(obj, LV_ALIGN_CENTER, x, y);
}

void GUIEngine::SetShadow(lv_obj_t *obj, int ofs_x, int ofs_y, int w, float opa, uint32_t color)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetSize: invalid obj");
        return;
    }
    lv_obj_set_style_shadow_ofs_x(obj, ofs_x, 0);
    lv_obj_set_style_shadow_ofs_y(obj, ofs_y, 0);
    lv_obj_set_style_shadow_width(obj, w, 0);
    lv_obj_set_style_shadow_spread(obj, 0, 0);
    lv_obj_set_style_shadow_color(obj, lv_color_hex(color), 0);
    lv_obj_set_style_shadow_opa(obj, opa * 255, 0);
}
void GUIEngine::SetFlexFlowCol(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("SetFlexFlowCol: invalid obj");
        return;
    }
    lv_obj_set_flex_flow(obj, LV_FLEX_FLOW_COLUMN);
}
void GUIEngine::SetParent(lv_obj_t *obj, lv_obj_t *parent)
{
    if (!parent || !obj)
    {
        LV_LOG_ERROR("SetParent: invalid obj");
        return;
    }

    lv_obj_set_parent(obj, parent);
}
void GUIEngine::SendToBottom(lv_obj_t *obj)
{
    if (!obj)
    {
        LV_LOG_ERROR("SendToBottom: invalid obj");
        return;
    }
    lv_obj_move_to_index(obj, 0);
}

lv_obj_t *GUIEngine::CreateCardAbsolute(lv_obj_t *parent,
                                        int w, int h,
                                        int x, int y,
                                        uint32_t color,
                                        int r)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateCardAbsolute: invalid parent");
        return nullptr;
    }

    lv_obj_t *card = lv_obj_create(parent);
    if (!card)
    {
        LV_LOG_ERROR("CreateCardAbsolute: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước & vị trí tuyệt đối
    lv_obj_set_size(card, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));
    lv_obj_set_pos(card, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));

    // Style selector
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền màu & độ phủ
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, sel);
    lv_obj_set_style_bg_color(card, lv_color_hex(color), sel);

    // Bo góc
    lv_obj_set_style_radius(card, r, sel);

    // Bỏ border & shadow (tuỳ chọn)
    lv_obj_set_style_border_width(card, 0, sel);
    lv_obj_set_style_shadow_width(card, 0, sel);

    // Padding bên trong
    lv_obj_set_style_pad_all(card, 0, sel);

    return card;
}

lv_obj_t *GUIEngine::CreateCardCentered(lv_obj_t *parent,
                                        int w, int h,
                                        uint32_t color,
                                        int r)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateCardCentered: invalid parent");
        return nullptr;
    }

    lv_obj_t *card = lv_obj_create(parent);
    if (!card)
    {
        LV_LOG_ERROR("CreateCardCentered: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước & căn giữa
    lv_obj_set_size(card, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));
    lv_obj_set_align(card, LV_ALIGN_CENTER);

    // Style selector
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền màu & độ phủ
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, sel);
    lv_obj_set_style_bg_color(card, lv_color_hex(color), sel);

    // Bo góc
    lv_obj_set_style_radius(card, r, sel);

    // Bỏ border & shadow (tuỳ chọn)
    lv_obj_set_style_border_width(card, 0, sel);
    lv_obj_set_style_shadow_width(card, 0, sel);

    // Padding bên trong
    lv_obj_set_style_pad_all(card, 0, sel);

    return card;
}
lv_obj_t *GUIEngine::CreateRectangleAbsoluteTransparent(lv_obj_t *parent,
                                                        int width, int height,
                                                        int x, int y)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateRectangleAbsoluteTransparent: invalid parent");
        return nullptr;
    }

    lv_obj_t *rect = lv_obj_create(parent);
    if (!rect)
    {
        LV_LOG_ERROR("CreateRectangleAbsoluteTransparent: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước & vị trí tuyệt đối
    lv_obj_set_size(rect, static_cast<lv_coord_t>(width), static_cast<lv_coord_t>(height));
    lv_obj_set_pos(rect, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));

    // Selector rõ ràng cho style
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền trong suốt
    lv_obj_set_style_bg_opa(rect, LV_OPA_TRANSP, sel);

    // Bỏ border & shadow
    lv_obj_set_style_border_width(rect, 0, sel);
    lv_obj_set_style_shadow_width(rect, 0, sel);

    // Padding & scrollbar
    lv_obj_set_style_pad_all(rect, 0, sel);
    lv_obj_set_scrollbar_mode(rect, LV_SCROLLBAR_MODE_OFF);

    // Tuỳ chọn: nếu không cần nhận sự kiện click, có thể tắt tương tác
    // lv_obj_clear_flag(rect, LV_OBJ_FLAG_CLICKABLE);

    return rect;
}

lv_obj_t *GUIEngine::CreateRectangleCenteredTransparent(lv_obj_t *parent,
                                                        int width, int height)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateRectangleCenteredTransparent: invalid parent");
        return nullptr;
    }

    lv_obj_t *rect = lv_obj_create(parent);
    if (!rect)
    {
        LV_LOG_ERROR("CreateRectangleCenteredTransparent: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước & căn giữa
    lv_obj_set_size(rect, static_cast<lv_coord_t>(width), static_cast<lv_coord_t>(height));
    lv_obj_set_align(rect, LV_ALIGN_CENTER);

    // Style selector
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền trong suốt
    lv_obj_set_style_bg_opa(rect, LV_OPA_TRANSP, sel);

    // Bỏ border & shadow
    lv_obj_set_style_border_width(rect, 0, sel);
    lv_obj_set_style_shadow_width(rect, 0, sel);

    // Padding & scrollbar
    lv_obj_set_style_pad_all(rect, 0, sel);
    lv_obj_set_scrollbar_mode(rect, LV_SCROLLBAR_MODE_OFF);

    return rect;
}

lv_obj_t *GUIEngine::CreateCircleAbsolute(lv_obj_t *parent, int d, uint32_t color, int x, int y)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateCircleAbsolute: invalid parent");
        return nullptr;
    }

    lv_obj_t *circle = lv_obj_create(parent);
    if (!circle)
    {
        LV_LOG_ERROR("CreateCircleAbsolute: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước hình tròn
    lv_obj_set_size(circle, static_cast<lv_coord_t>(d), static_cast<lv_coord_t>(d));

    // Vị trí tuyệt đối (left/top tương đương)
    lv_obj_set_pos(circle, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));

    // Style selector
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền & độ phủ
    lv_obj_set_style_bg_color(circle, lv_color_hex(color), sel);
    lv_obj_set_style_bg_opa(circle, LV_OPA_COVER, sel);

    // Bo góc thành hình tròn
    lv_obj_set_style_radius(circle, d / 2, sel);

    // Bỏ viền & bóng
    lv_obj_set_style_border_width(circle, 0, sel);
    lv_obj_set_style_shadow_width(circle, 0, sel);

    // Tắt scrollbar, padding = 0
    lv_obj_set_scrollbar_mode(circle, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_style_pad_all(circle, 0, sel);

    return circle;
}
lv_obj_t *GUIEngine::CreateCircleCentered(lv_obj_t *parent, int d, uint32_t color)
{
    if (!parent)
    {
        LV_LOG_ERROR("CreateCircleCentered: invalid parent");
        return nullptr;
    }

    lv_obj_t *circle = lv_obj_create(parent);
    if (!circle)
    {
        LV_LOG_ERROR("CreateCircleCentered: lv_obj_create failed");
        return nullptr;
    }

    // Kích thước hình tròn D x D
    lv_obj_set_size(circle, static_cast<lv_coord_t>(d), static_cast<lv_coord_t>(d));

    // Căn giữa cả X/Y
    lv_obj_set_align(circle, LV_ALIGN_CENTER);

    // Style cho PART_MAIN + STATE_DEFAULT
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    // Nền màu và độ phủ
    lv_obj_set_style_bg_color(circle, lv_color_hex(color), sel);
    lv_obj_set_style_bg_opa(circle, LV_OPA_COVER, sel);

    // Bo góc để thành hình tròn
    lv_obj_set_style_radius(circle, d / 2, sel);

    // Bỏ viền & bóng
    lv_obj_set_style_border_width(circle, 0, sel);
    lv_obj_set_style_shadow_width(circle, 0, sel);

    // Tắt scrollbar, padding = 0
    lv_obj_set_scrollbar_mode(circle, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_style_pad_all(circle, 0, sel);

    return circle;
}

// Tạo image với vị trí tuyệt đối (x, y)
lv_obj_t *GUIEngine::CreateImageAbsolute(lv_obj_t *parent, const char *path, int x, int y)
{
    if (!parent || !path || !*path)
    {
        LV_LOG_ERROR("CreateImageAbsolute: invalid parent or path");
        return nullptr;
    }

    lv_obj_t *image = lv_image_create(parent);
    if (!image)
    {
        LV_LOG_ERROR("CreateImageAbsolute: lv_image_create failed");
        return nullptr;
    }

    // Đường dẫn kiểu LVGL: dùng forward slashes '/', nếu dùng FS Win32 cần driver letter (ví dụ: "C:/...")
    lv_image_set_src(image, path);

    // Vị trí tuyệt đối
    lv_obj_set_pos(image, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));

    return image;
}

// Tạo image căn giữa trong parent
lv_obj_t *GUIEngine::CreateImageCentered(lv_obj_t *parent, const char *path)
{
    if (!parent || !path || !*path)
    {
        LV_LOG_ERROR("CreateImageCentered: invalid parent or path");
        return nullptr;
    }

    lv_obj_t *image = lv_image_create(parent);
    if (!image)
    {
        LV_LOG_ERROR("CreateImageCentered: lv_image_create failed");
        return nullptr;
    }

    // Đường dẫn kiểu LVGL: dùng forward slashes '/', nếu dùng FS Win32 cần driver letter (ví dụ: "C:/...")
    lv_image_set_src(image, path);

    // Căn giữa
    lv_obj_set_align(image, LV_ALIGN_CENTER);

    return image;
}

// Tạo label tiếng Nhật với vị trí tuyệt đối (x, y)
lv_obj_t *GUIEngine::CreateLabelAbsoluteTextCentered(lv_obj_t *parent,
                                                     const char *text,
                                                     int w, int h,
                                                     Font font,
                                                     int x, int y,
                                                     uint32_t color)
{
    if (!parent || !text)
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextCentered: invalid parent or text");
        return nullptr;
    }

    lv_obj_t *label = lv_label_create(parent);
    if (!label)
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextCentered: lv_label_create failed");
        return nullptr;
    }

    lv_label_set_text(label, text);
    lv_obj_set_pos(label, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));
    lv_obj_set_size(label, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));

    lv_font_t *local_font = GetFont(font);
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    if (local_font)
    {
        lv_obj_set_style_text_font(label, local_font, sel);
    }
    else
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextCentered: font not found for enum value");
    }

    lv_obj_set_style_text_color(label, lv_color_hex(color), sel);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, sel);
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP); // xuống dòng nếu quá dài

    return label;
}

// Tạo label tiếng Nhật với vị trí tuyệt đối (x, y)
lv_obj_t *GUIEngine::CreateLabelAbsoluteTextLeft(lv_obj_t *parent,
                                                 const char *text,
                                                 int w, int h,
                                                 Font font,
                                                 int x, int y,
                                                 uint32_t color)
{
    if (!parent || !text)
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextAbsolute: invalid parent or text");
        return nullptr;
    }

    lv_obj_t *label = lv_label_create(parent);
    if (!label)
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextAbsolute: lv_label_create failed");
        return nullptr;
    }

    lv_label_set_text(label, text);
    lv_obj_set_pos(label, static_cast<lv_coord_t>(x), static_cast<lv_coord_t>(y));
    lv_obj_set_size(label, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));

    lv_font_t *local_font = GetFont(font);
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    if (local_font)
    {
        lv_obj_set_style_text_font(label, local_font, sel);
    }
    else
    {
        LV_LOG_ERROR("CreateLabelAbsoluteTextAbsolute: font not found for enum value");
    }

    lv_obj_set_style_text_color(label, lv_color_hex(color), sel);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_LEFT, sel);
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP); // xuống dòng nếu quá dài

    return label;
}

// Tạo label tiếng Nhật căn giữa parent
lv_obj_t *GUIEngine::CreateLabelCenteredTextCentered(lv_obj_t *parent,
                                                     const char *text,
                                                     int w, int h,
                                                     Font font,
                                                     uint32_t color)
{
    if (!parent || !text)
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: invalid parent or text");
        return nullptr;
    }

    lv_obj_t *label = lv_label_create(parent);
    if (!label)
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: lv_label_create failed");
        return nullptr;
    }

    lv_label_set_text(label, text);
    // Ensure the label is positioned even if no layout refresh happens immediately.
    lv_obj_align(label, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_size(label, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));

    lv_font_t *local_font = GetFont(font);
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    if (local_font)
    {
        lv_obj_set_style_text_font(label, local_font, sel);
    }
    else
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: font not found for enum value, using default");
        // Fallback to LVGL default font if custom font not available
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, sel);
    }

    lv_obj_set_style_text_color(label, lv_color_hex(color), sel);
    lv_obj_set_style_text_opa(label, LV_OPA_COVER, sel);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, sel);
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP);

    return label;
}
lv_obj_t *GUIEngine::CreateLabelCenteredTextLeft(lv_obj_t *parent,
                                                 const char *text,
                                                 int w, int h,
                                                 Font font,
                                                 uint32_t color)
{
    if (!parent || !text)
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: invalid parent or text");
        return nullptr;
    }

    lv_obj_t *label = lv_label_create(parent);
    if (!label)
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: lv_label_create failed");
        return nullptr;
    }

    lv_label_set_text(label, text);
    // Ensure the label is positioned even if no layout refresh happens immediately.
    lv_obj_align(label, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_size(label, static_cast<lv_coord_t>(w), static_cast<lv_coord_t>(h));

    lv_font_t *local_font = GetFont(font);
    constexpr uint32_t sel = LV_PART_MAIN | LV_STATE_DEFAULT;

    if (local_font)
    {
        lv_obj_set_style_text_font(label, local_font, sel);
    }
    else
    {
        LV_LOG_ERROR("CreateLabelCenteredTextCentered: font not found for enum value, using default");
        // Fallback to LVGL default font if custom font not available
        lv_obj_set_style_text_font(label, &lv_font_montserrat_14, sel);
    }

    lv_obj_set_style_text_color(label, lv_color_hex(color), sel);
    lv_obj_set_style_text_opa(label, LV_OPA_COVER, sel);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_LEFT, sel);
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP);

    return label;
}
void GUIEngine::ShowObject(lv_obj_t *obj)
{
    if (obj)
    {
        lv_obj_clear_flag(obj, LV_OBJ_FLAG_HIDDEN); // Hiện
    }
}

void GUIEngine::HideObject(lv_obj_t *obj)
{
    if (obj)
    {
        lv_obj_add_flag(obj, LV_OBJ_FLAG_HIDDEN); // Ẩn
    }
}

void GUIEngine::DeleteObject(lv_obj_t *obj)
{
    if (obj && lv_obj_is_valid(obj))
    {
        lv_obj_delete(obj);
        obj = nullptr; // Tránh dangling pointer
    }
}

// Generic: dùng std::function<void()> để gọi bất kỳ logic nào
lv_timer_t *GUIEngine::CreateOneShotTimer(std::function<void()> fn, uint32_t timeout_ms)
{
    // Bọc fn vào heap để sống qua callback
    auto *pfn = new std::function<void()>(std::move(fn));

    return lv_timer_create(
        [](lv_timer_t *timer)
        {
            auto *pfn = static_cast<std::function<void()> *>(lv_timer_get_user_data(timer));
            if (pfn && *pfn)
            {
                (*pfn)();
            }
            lv_timer_del(timer); // one-shot
            delete pfn;          // giải phóng
        },
        timeout_ms,
        pfn);
}

// removed soon
lv_obj_t *GUIEngine::ShowImage(lv_obj_t *scr, const void *img_scr)
{
    lv_obj_t *img = lv_image_create(scr);
    lv_image_set_src(img, img_scr);
    lv_obj_set_align(img, LV_ALIGN_CENTER);
    return img;
}
void GUIEngine::CloseImage(lv_obj_t *img)
{
    if (!img)
        return;

    // SetImageVisible(img, false);
    lv_obj_delete(img);

    img = nullptr;
}

void GUIEngine::Dummy(lv_obj_t *scr)
{

    // Nền gradient dọc 2 màu (xấp xỉ: từ #024BA0 -> #080A2D)
    lv_color_t c_top = lv_color_hex(0x024BA0);
    lv_color_t c_bottom = lv_color_hex(0x080A2D);

    lv_obj_set_style_bg_color(scr, c_top, 0);
    lv_obj_set_style_bg_grad_color(scr, c_bottom, 0);
    lv_obj_set_style_bg_grad_dir(scr, LV_GRAD_DIR_VER, 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);

    //

    // Tạo "Background" header theo thông số Figma
    // 1) Tạo object
    lv_obj_t *header_bg = lv_obj_create(scr);
    lv_obj_set_size(header_bg, 640, 50);
    lv_obj_set_pos(header_bg, 0, 0); // position: absolute; left: 0px; top: 0px;

    // 2) Bo góc: 0px
    lv_obj_set_style_radius(header_bg, 0, 0);

    // 3) Nền gradient: trắng 10% -> 0% theo chiều dọc (180deg ~ dọc)
    //    Figma: linear-gradient(180deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%)
    //
    //    Trong LVGL, opacity của background là tổng thể, không có alpha riêng cho từng màu.
    //    Ta sẽ xấp xỉ: màu đầu là trắng với độ mờ ~10%, màu cuối là trắng với độ mờ ~0%.
    lv_obj_set_style_bg_color(header_bg, lv_color_white(), 0);
    lv_obj_set_style_bg_grad_color(header_bg, lv_color_white(), 0);
    lv_obj_set_style_bg_grad_dir(header_bg, LV_GRAD_DIR_VER, 0);

    // Opa ~ 10% ở điểm bắt đầu. 10% * 255 ≈ 26.
    // Một số bản LVGL hỗ trợ "grad opa" riêng, nếu bản của bạn không có,
    // bạn có thể dùng thủ thuật: đặt bg_opa ≈ 26 và grad_color giống nhau để cảm nhận fade rất nhẹ.
    lv_obj_set_style_bg_opa(header_bg, 26, 0);

    // Nếu bản LVGL của bạn hỗ trợ thiết lập riêng độ mờ điểm cuối (grad stop/opa),
    // có thể thử (tùy phiên bản):
    lv_obj_set_style_bg_grad_stop(header_bg, 255, 0); // điểm cuối (chỉ khi API có)
    lv_obj_set_style_bg_main_stop(header_bg, 0, 0);   // điểm đầu (chỉ khi API có)
    lv_obj_set_style_bg_grad_opa(header_bg, 0, 0);    // độ mờ cuối (chỉ khi API có)

    // 4) Drop shadow: 0px 3px 10px rgba(0,0,0,0.7)
    //    Trong LVGL, shadow có các thông số: width (độ “blur”), ofs_x/y (dịch chuyển),
    //    spread (nở thêm) và color/opa.
    lv_obj_set_style_shadow_ofs_x(header_bg, 0, 0);
    lv_obj_set_style_shadow_ofs_y(header_bg, 3, 0);
    lv_obj_set_style_shadow_width(header_bg, 10, 0); // tương ứng blur ~10px
    lv_obj_set_style_shadow_spread(header_bg, 0, 0);

    lv_obj_set_style_shadow_ofs_x(header_bg, 0, 0);
    lv_obj_set_style_shadow_ofs_y(header_bg, 3, 0);
    lv_obj_set_style_shadow_width(header_bg, 10, 0);
    lv_obj_set_style_shadow_spread(header_bg, 0, 0);
    lv_obj_set_style_shadow_color(header_bg, lv_color_black(), 0);
    lv_obj_set_style_shadow_opa(header_bg, 178, 0);

    // Màu đen, opa ~ 0.7 => 0.7 * 255 ≈ 178
    lv_obj_set_style_shadow_color(header_bg, lv_color_black(), 0);
    lv_obj_set_style_shadow_opa(header_bg, 178, 0);

    // Tuỳ chọn: bỏ border / shadow nếu không cần
    lv_obj_set_style_border_width(header_bg, 0, 0);
    // lv_obj_set_style_shadow_width(header_bg, 0, 0);

    // (Tuỳ chọn) bỏ padding bên trong container
    lv_obj_set_style_pad_all(header_bg, 0, 0);

    //

    // lv_obj_t* tittle = CreateJapaneseTextLabel(header_bg, "MENU", 80, 34, 0xFFFFFF);
}
//
// void SetImageTop(lv_obj_t* img, bool top) {
//    if (top) {
//        // chọn 1 cách
//        lv_obj_move_foreground(img);
//        // hoặc đảm bảo nằm trên bằng z-index lớn
//        //lv_obj_set_style_z_index(img, 100, 0);
//    }
//    else {
//        lv_obj_move_background(img);
//        //lv_obj_set_style_z_index(img, -100, 0);
//    }
//}