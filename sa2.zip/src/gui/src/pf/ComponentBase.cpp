#include "ComponentBase.h"
 
ComponentBase::ComponentBase(lv_obj_t* parent)
{
    this->parent = parent;
}
ComponentBase::~ComponentBase()
{
    Delete();
}
void ComponentBase::Init()
{
    if (parent && !obj)
    {
        obj = GUIEngine::GetInstance().CreateRawObject(parent);
    }
}
void ComponentBase::SetLocation(int x, int y)
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().SetLocation(obj, x, y);
    }
}
int ComponentBase::GetLocationX()
{
    int location = -1;
    if (parent && obj)
    {
        location = GUIEngine::GetInstance().GetLocationX(obj);
    }
    return location;
}
int ComponentBase::GetLocationY()
{
    int location = -1;
    if (parent && obj)
    {
        location = GUIEngine::GetInstance().GetLocationY(obj);
    }
    return location;
}
void ComponentBase::SetSize(int w, int h)
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().SetSize(obj, w, h);
    }
}
int ComponentBase::GetSizeW()
{
    int size = -1;
    if (parent && obj)
    {
        size = GUIEngine::GetInstance().GetSizeW(obj);
    }
    return size;
}
int ComponentBase::GetSizeH()
{
    int size = -1;
    if (parent && obj)
    {
        size = GUIEngine::GetInstance().GetSizeH(obj);
    }
    return size;
}
void ComponentBase::SetImage(std::string path, int x, int y)
{
    if (parent && obj)
    {
        if (image)
        {
            GUIEngine::GetInstance().DeleteObject(image);
            image = nullptr;
        }
 
        image = GUIEngine::GetInstance().CreateImageAbsolute(obj, path.c_str(), x, y);
    }
}
void ComponentBase::SetImage(std::string path)
{
    if (parent && obj)
    {
        if (image)
        {
            GUIEngine::GetInstance().DeleteObject(image);
            image = nullptr;
        }
        image = GUIEngine::GetInstance().CreateImageCentered(obj, path.c_str());
    }
}
void ComponentBase::SetShadow(int ofs_x, int ofs_y, int w, float opa, uint32_t color)
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().SetShadow(obj, ofs_x, ofs_y, w, opa, color);
    }
}
void ComponentBase::SetText(std::string text, int w, int h, GUIEngine::Font font, uint32_t color)
{
    if (parent && obj)
    {
        if (label)
        {
            GUIEngine::GetInstance().DeleteObject(label);
            label = nullptr;
        }
        label = GUIEngine::GetInstance().CreateLabelCenteredTextCentered(obj, text.c_str(), w, h, font, color);
    }
}
 
void ComponentBase::Show()
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().ShowObject(obj);
    }
}
void ComponentBase::Hide()
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().HideObject(obj);
    }
}
void ComponentBase::Delete()
{
    if (parent && obj)
    {
        GUIEngine::GetInstance().DeleteObject(obj);
        obj = nullptr;
    }
}