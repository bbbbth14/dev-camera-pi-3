#include "TextBox.h"
TextBox::TextBox(lv_obj_t *parent) : ComponentBase(parent)
{
}
TextBox::~TextBox()
{
}
void TextBox::Init()
{
    ComponentBase::Init();
}