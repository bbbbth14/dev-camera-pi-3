#include "GUIAdasDmsViewModel.h"

GUIAdasDmsViewModel &GUIAdasDmsViewModel::GetInstance()
{
    static GUIAdasDmsViewModel instance;
    return instance;
}

void GUIAdasDmsViewModel::onVehicleSpeedChanged(float vehicleSpeed)
{
    if (this->VehicleSpeed != vehicleSpeed)
    {
        this->VehicleSpeed = vehicleSpeed;
        GUIEventDispatcher::GetInstance().onVehicleSpeedChanged(this->VehicleSpeed);
    }
}
float GUIAdasDmsViewModel::GetVehicleSpeed()
{
    return this->VehicleSpeed;
}