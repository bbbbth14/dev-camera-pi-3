#include "GUIEventViewModel.h"

GUIEventViewModel &GUIEventViewModel::GetInstance()
{
    static GUIEventViewModel instance;
    return instance;
}

void GUIEventViewModel::onUPKeyShortPressed()
{
    GUIEventDispatcher::GetInstance().onUPKeyShortPressed();
}
void GUIEventViewModel::onMENU_OKKeyShortPressed()
{
    GUIEventDispatcher::GetInstance().onMENU_OKKeyShortPressed();
}
void GUIEventViewModel::onDOWNKeyShortPressed()
{
    GUIEventDispatcher::GetInstance().onDOWNKeyShortPressed();
}
void GUIEventViewModel::onMIC_ON_OFFKeyShortPressed()
{
    GUIEventDispatcher::GetInstance().onMIC_ON_OFFKeyShortPressed();
}
void GUIEventViewModel::onEmergency_CallKeyShortPressed()
{
    GUIEventDispatcher::GetInstance().onEmergency_CallKeyShortPressed();
}
void GUIEventViewModel::onMotionDetected()
{
    GUIEventDispatcher::GetInstance().onMotionDetected();
}
void GUIEventViewModel::onShockDetected()
{
    GUIEventDispatcher::GetInstance().onShockDetected();
}
void GUIEventViewModel::onLongDrivingAttention()
{
    GUIEventDispatcher::GetInstance().onLongDrivingAttention();
}

bool GUIEventViewModel::GetMicOnOff()
{
    return IsMicOn;
}
void GUIEventViewModel::SetMicOnOff(bool on)
{
    IsMicOn = on;
}

int GUIEventViewModel::Get4GSignalStrength()
{
    return _4GSignalStrength;
}
void GUIEventViewModel::on4GSignalStrengthChanged(int strength)
{
    GUIEventDispatcher::GetInstance().on4GSignalStrengthChanged(strength);
}