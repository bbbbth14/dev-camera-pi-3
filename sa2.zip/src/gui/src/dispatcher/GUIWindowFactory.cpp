#include "GUIWindowFactory.h"
GUIWindowFactory::GUIWindowFactory()
{
}

GUIWindowFactory::~GUIWindowFactory()
{
}

GUIWindowFactory &GUIWindowFactory::GetInstance()
{
    static GUIWindowFactory instance;
    return instance;
}

void GUIWindowFactory::Register(const std::string &name, Creator creator)
{
    registry[name] = std::move(creator);
}

std::unique_ptr<GUIWindowBase> GUIWindowFactory::Create(const std::string &name) const
{
    auto it = registry.find(name);
    if (it != registry.end())
    {
        return (it->second)();
    }
    return nullptr;
}

struct WindowRegistrar
{
    WindowRegistrar()
    {
        GUIWindowFactory::GetInstance().Register(GUIHomeWindow::Id, []
                                                 { return std::make_unique<GUIHomeWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIMenuMainWindow::Id, []
                                                 { return std::make_unique<GUIMenuMainWindow>(); });
    }
} windowRegistrar;
