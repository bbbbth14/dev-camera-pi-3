#include "GUIPopupFactory.h"

GUIPopupFactory::GUIPopupFactory()
{
}

GUIPopupFactory::~GUIPopupFactory()
{
}

GUIPopupFactory &GUIPopupFactory::GetInstance()
{
    static GUIPopupFactory instance;
    return instance;
}

void GUIPopupFactory::Register(const std::string &name, Creator creator)
{
    registry[name] = std::move(creator);
}

std::unique_ptr<GUIPopupBase> GUIPopupFactory::Create(const std::string &name) const
{
    auto it = registry.find(name);
    if (it != registry.end())
    {
        return (it->second)();
    }
    return nullptr;
}

struct PopupRegistrar
{
    PopupRegistrar()
    {
        GUIPopupFactory::GetInstance().Register(GUIEventPopup::Id, []
                                                { return std::make_unique<GUIEventPopup>(GUIEventDispatcher::GetInstance().GetCurrentManager()->GetCurrentWindow()->scr); });
    }
} popupRegistrar;
