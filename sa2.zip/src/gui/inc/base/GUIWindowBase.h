#pragma once

#ifndef GUIWINDOWBASE_H
#define GUIWINDOWBASE_H

#include <string>

#include "GUIEventBase.h"
#include "GUIEngine.h"
#include "Button.h"
#include "TextBox.h"
#include "List.h"

class GUIWindowBase : public GUIEventBase
{
public:
    lv_obj_t *scr = nullptr;

public:
    GUIWindowBase();
    ~GUIWindowBase();
    virtual void Init() = 0;
    void Show();
};

#endif // GUIWINDOWBASE_H