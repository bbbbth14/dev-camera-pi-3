#pragma once

#ifndef GUIEVENTBASE_H
#define GUIEVENTBASE_H

#include <string>

class GUIEventBase
{
public:
    struct KeyActionContext
    {
        bool doCreateNewManager = false;
        std::string newManagerName;
        bool doBackToPreviousManager = false;

        // bool doCreateNewWindow = false;
        // std::string newWindowName;
        // bool doBackToPreviousWindow = false;
    };

    enum class Key
    {
        UP,
        MENU_OK,
        DOWN,
        MIC_ON_OFF,
        Emergency_Call
    };

    enum class PressType
    {
        Short,
        Long
    };

public:
    GUIEventBase();
    ~GUIEventBase();

    virtual void onKey(Key key, PressType press, KeyActionContext &ctx);

    virtual void onShockDetected();
    virtual void onMotionDetected();
    virtual void onUnauthorizedAccess();
    virtual void onLongDrivingAttention();

    virtual void onVehicleSpeedChanged(float vehicleSpeed, KeyActionContext &ctx);
    virtual void on4GSignalStrengthChanged(int strength);
};

#endif // GUIEVENTBASE_H