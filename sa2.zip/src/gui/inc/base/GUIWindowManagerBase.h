#pragma once

#ifndef GUIWINDOWMANAGERBASE_H
#define GUIWINDOWMANAGERBASE_H

#include <vector>

#include "GUIEventBase.h"
#include "GUIWindowBase.h"
#include "GUIWindowFactory.h"

class GUIWindowManagerBase : public GUIEventBase
{
public:
    std::vector<std::unique_ptr<GUIWindowBase>> windows;

public:
    GUIWindowManagerBase();
    ~GUIWindowManagerBase();
    virtual std::string GetStateName() const = 0;
    virtual void Init() = 0;

    GUIWindowBase *GetCurrentWindow();
    void SetCurrentWindow(std::string name);
    void BackToPreviousWindow();
    virtual void ShowCurrentWindow();
};

#endif // GUIWINDOWMANAGERBASE_H