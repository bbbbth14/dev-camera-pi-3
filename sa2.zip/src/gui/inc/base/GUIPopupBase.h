#pragma once

#ifndef GUIPOPUPBASE_H
#define GUIPOPUPBASE_H

#include <string>

#include "GUIEventBase.h"
#include "GUIEngine.h"

class GUIPopupBase : public GUIEventBase
{
protected:
    lv_obj_t *scr = nullptr;
    lv_obj_t *dlg = nullptr;

public:
    GUIPopupBase(lv_obj_t *scr);
    ~GUIPopupBase();
    virtual void Init() = 0;
    void Open();
    virtual void Close();
};

#endif // GUIPOPUPBASE_H
