#pragma once
 
#ifndef GUIVIEWMODELBASE_H
#define GUIVIEWMODELBASE_H
 
class GUIViewModelBase {
public:
   
};
 
#endif // GUIVIEWMODELBASE_H