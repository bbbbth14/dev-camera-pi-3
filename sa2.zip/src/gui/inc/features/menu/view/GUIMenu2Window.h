#pragma once

#ifndef GUIMENU2WINDOW_H
#define GUIMENU2WINDOW_H

#include "GUIWindowLayoutBase.h"

class GUIMenu2Window : public GUIWindowLayoutBase
{
public:
    GUIMenu2Window();
    ~GUIMenu2Window();
    inline static const std::string Id = "SCS-01-2000-2";
    void Init() override;
};

#endif // GUIMENU2WINDOW_H