#pragma once

#ifndef GUIMENU1WINDOW_H
#define GUIMENU1WINDOW_H

#include "GUIWindowLayoutBase.h"

class GUIMenu1Window : public GUIWindowLayoutBase
{
public:
    GUIMenu1Window();
    ~GUIMenu1Window();
    inline static const std::string Id = "SCS-01-2000-1";
    void Init() override;
};

#endif // GUIMENU1WINDOW_H