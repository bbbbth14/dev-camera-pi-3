#pragma once

#ifndef GUIMENUMANAGER_H
#define GUIMENUMANAGER_H

#include <string>

#include "GUIWindowManagerBase.h"
#include "GUIMenuMainWindow.h"

class GUIMenuManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        MAIN,
    };
    State state;

public:
    GUIMenuManager();
    ~GUIMenuManager();
    inline static const std::string Id = "GUIMenuManager";
    std::string GetStateName() const override;
    void Init() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;
};

#endif // GUIMENUMANAGER_H