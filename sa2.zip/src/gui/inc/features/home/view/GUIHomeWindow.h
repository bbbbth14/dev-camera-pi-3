#pragma once

#ifndef GUIHOMEWINDOW_H
#define GUIHOMEWINDOW_H

#include "GUIWindowLayoutBase.h"
#include "Network4G.h"

class GUIHomeWindow : public GUIWindowLayoutBase
{
private:
    std::unique_ptr<Network4G> network4G = nullptr;

    // Update Data popup
    lv_obj_t *updateDataOverlay = nullptr;
    lv_obj_t *updateDataCard = nullptr;
    std::unique_ptr<TextBox> updateDataTextBox = nullptr;
    bool updateDataShown = false;

    // Server info popups
    lv_obj_t *serverInfoOverlay = nullptr;
    lv_obj_t *serverInfoCard = nullptr;
    std::unique_ptr<TextBox> serverInfoTitleTextBox = nullptr;
    std::unique_ptr<TextBox> serverInfoMessageTextBox = nullptr;
    std::unique_ptr<TextBox> serverInfoButtonTextBox = nullptr;
    std::unique_ptr<TextBox> serverInfoButton2TextBox = nullptr;
    bool serverInfoShown = false;
    int currentServerInfoStage = 0; // 0=none, 1=pre-driving, 2=monthly, 3=notification
    int notificationButtonSelected = 0; // 0=Detail, 1=Close

    // Accident popups
    lv_obj_t *accidentOverlay = nullptr;
    lv_obj_t *accidentCard = nullptr;
    std::unique_ptr<TextBox> accidentTitleTextBox = nullptr;
    std::unique_ptr<TextBox> accidentMessageTextBox = nullptr;
    std::unique_ptr<TextBox> accidentButtonTextBox = nullptr;
    bool accidentPopupShown = false;

    void ShowUpdateDataPopup();
    void HideUpdateDataPopup();
    void ShowServerInfoPopups();
    void ShowPreDrivingPopup();
    void ShowMonthlyReportPopup();
    void ShowNotificationPopup();
    void HideServerInfoPopup();
    void ShowNotificationDetail();
    std::string ReadJsonStringField(const std::string &filePath, const std::string &fieldName) const;
    void ShowAccidentPopup(const std::string &title, const std::string &message);
    void HideAccidentPopup();

public:
    GUIHomeWindow();
    ~GUIHomeWindow();
    inline static const std::string Id = "SCS-01-1000";
    void Init() override;
    void onKey(Key key, PressType press, KeyActionContext &ctx) override;
    void onShockDetected() override;
    void onMotionDetected() override;
    void onUnauthorizedAccess();
    bool IsServerInfoPopupActive() const { return serverInfoShown || updateDataShown || accidentPopupShown; }

    void SetMicOnOff(bool on);
    void Set4GSignalStrength(int strength);
};

#endif // GUIHOMEWINDOW_H