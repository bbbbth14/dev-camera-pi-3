#pragma once

#ifndef GUIHOMEMANAGER_H
#define GUIHOMEMANAGER_H

#include <string>

#include "GUIEventBase.h"
#include "GUIWindowManagerBase.h"
#include "GUIHomeWindow.h"
#include "GUIMenuManager.h"

#include "GUIEventViewModel.h"

class GUIHomeManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        HOME,
    };
    State state;

public:
    GUIHomeManager();
    ~GUIHomeManager();
    inline static const std::string Id = "SCS-01-1000";

    std::string GetStateName() const override;
    void Init() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;
    void on4GSignalStrengthChanged(int strength) override;
    void onShockDetected() override;
    void onMotionDetected() override;

    void ToggleMicOnOff();
};

#endif // GUIHOMEMANAGER_H