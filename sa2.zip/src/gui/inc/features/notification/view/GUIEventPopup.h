#pragma once

#ifndef GUIEVENTPOPUP_H
#define GUIEVENTPOPUP_H

#include "GUIPopupBase.h"

class GUIEventPopup : public GUIPopupBase
{
public:
    /// 21 loại cảnh báo
    enum class DrivingAlert
    {
        ShockDetected,                // メッセージ1 衝撃を検知しました
        LongDrivingAttention,         // メッセージ2 長時間走行注意
        RapidAccelerationAttention,   // メッセージ3 急加速注意
        SuddenDecelerationAttention,  // メッセージ4 急減速注意
        LeftSharpSteeringDetection,   // メッセージ5 左急ハンドル検知
        RightSharpSteeringDetection,  // メッセージ6 右急ハンドル検知
        WobblyAttention,              // メッセージ7 ふらつき注意
        ReverseDrivingFrequentPoints, // メッセージ8 逆走多発地点接近注意
        OutOfDesignatedArea,          // メッセージ9 指定区域外に出ました
        AccidentProneLocationCaution, // メッセージ10 事故多発地点注意
        MaxSpeed30AreaCaution,        // メッセージ11 最高速度30キロ制限地域注意
        PauseCaution,                 // メッセージ12 一時停止注意
        AnimalAttention,              // メッセージ13 動物注意
        WeatherWarningCaution,        // メッセージ14 気象警報注意
        CollisionAlert,               // メッセージ15 衝突注意
        LeftLaneCaution,              // メッセージ16 左車線注意
        RightLaneCaution,             // メッセージ17 右車線注意
        SpeedExceedsAttention,        // メッセージ18 速度超過注意
        DozingOffAttention,           // メッセージ19 居眠り注意
        MobilePhoneAttention,         // メッセージ20 携帯電話注意
        DistractedAttention,          // メッセージ21 脇見注意
        COUNT                         // giúp kiểm tra số lượng
    };

private:
    struct AlertAsset
    {
        std::string iconPath; // đường dẫn tới icon
        std::string text;     // nội dung
    };

    lv_obj_t *rectangle = nullptr;
    lv_obj_t *centerCircle = nullptr;
    lv_obj_t *icon = nullptr;
    lv_obj_t *text = nullptr;

    DrivingAlert currentType = DrivingAlert::ShockDetected; // default

public:
    GUIEventPopup(lv_obj_t *scr);
    ~GUIEventPopup();
    inline static const std::string Id = "dlg_event";

    void Init() override;
    void Close() override;

    void SetAlertType(DrivingAlert type);

private:
    /// Trả về path và text theo type
    inline const AlertAsset &GetAlertAsset(DrivingAlert type)
    {
        static const AlertAsset table[] = {
            /* ShockDetected               */ {"C:icon_alert_shock.png", "衝撃を検知しました"},
            /* LongDrivingAttention        */ {"C:icon_alert_shock.png", "長時間走行注意"},
            /* RapidAccelerationAttention  */ {"C:icon_alert_shock.png", "急加速注意"},
            /* SuddenDecelerationAttention */ {"C:icon_alert_shock.png", "急減速注意"},
            /* LeftSharpSteeringDetection  */ {"C:icon_alert_shock.png", "左急ハンドル検知"},
            /* RightSharpSteeringDetection */ {"C:icon_alert_shock.png", "右急ハンドル検知"},
            /* WobblyAttention             */ {"C:icon_alert_shock.png", "ふらつき注意"},
            /* ReverseDrivingFrequentPoints*/ {"C:icon_alert_shock.png", "逆走多発地点接近注意"},
            /* OutOfDesignatedArea         */ {"C:icon_alert_shock.png", "指定区域外に出ました"},
            /* AccidentProneLocationCaution*/ {"C:icon_alert_shock.png", "事故多発地点注意"},
            /* MaxSpeed30AreaCaution       */ {"C:icon_alert_shock.png", "最高速度30キロ制限地域注意"},
            /* PauseCaution                */ {"C:icon_alert_shock.png", "一時停止注意"},
            /* AnimalAttention             */ {"C:icon_alert_shock.png", "動物注意"},
            /* WeatherWarningCaution       */ {"C:icon_alert_shock.png", "気象警報注意"},
            /* CollisionAlert              */ {"C:icon_alert_shock.png", "衝突注意"},
            /* LeftLaneCaution             */ {"C:icon_alert_shock.png", "左車線注意"},
            /* RightLaneCaution            */ {"C:icon_alert_shock.png", "右車線注意"},
            /* SpeedExceedsAttention       */ {"C:icon_alert_shock.png", "速度超過注意"},
            /* DozingOffAttention          */ {"C:icon_alert_shock.png", "居眠り注意"},
            /* MobilePhoneAttention        */ {"C:icon_alert_shock.png", "携帯電話注意"},
            /* DistractedAttention         */ {"C:icon_alert_shock.png", "脇見注意"},
        };
        return table[static_cast<int>(type)];
    }
    void ApplyAlert(); // set icon + text theo currentType
};

#endif // GUIEVENTPOPUP_H