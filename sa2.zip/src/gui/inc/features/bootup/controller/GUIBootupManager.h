#pragma once

#ifndef GUIBOOTUPMANAGER_H
#define GUIBOOTUPMANAGER_H

#include "GUIWindowManagerBase.h"
#include "GUIBootupWindow.h"

class GUIBootupManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        BOOTUP,
    };
    State state;

public:
    inline static const std::string Id = "GUIBootupManager";

    GUIBootupManager();
    ~GUIBootupManager();

    std::string GetStateName() const override;
    void Init() override;
    void ShowCurrentWindow() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;
};

#endif // GUIBOOTUPMANAGER_H
