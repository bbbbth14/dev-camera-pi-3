#pragma once

#ifndef GUIBOOTUPWINDOW_H
#define GUIBOOTUPWINDOW_H

#include <lvgl.h>
#include "GUIWindowLayoutBase.h"

class TextBox;

class GUIBootupWindow : public GUIWindowLayoutBase
{
private:
    lv_obj_t *imageObj = nullptr;
    std::unique_ptr<TextBox> logoTextBox = nullptr;
    std::unique_ptr<TextBox> versionTextBox = nullptr;
    std::unique_ptr<TextBox> statusTextBox = nullptr;
    std::unique_ptr<TextBox> warningTextBox = nullptr;
    std::unique_ptr<TextBox> feetModeTextBox = nullptr;
    std::unique_ptr<TextBox> contractTextBox = nullptr;

    lv_obj_t *systemUpdateOverlay = nullptr;
    lv_obj_t *systemUpdateCard = nullptr;
    std::unique_ptr<TextBox> systemUpdateTitleTextBox = nullptr;
    std::unique_ptr<TextBox> systemUpdateCountdownTextBox = nullptr;
    bool systemUpdatePopupShown = false;

    bool isFirstBoot = true;

    bool warningShown = false;
    bool feetModeCheckShown = false;
    bool contractCheckShown = false;
    bool setupPromptShown = false;
    lv_obj_t *loadingBar = nullptr;
    lv_timer_t *bootupTimer = nullptr;
    bool imageShown = false;

    static constexpr int Stage0DurationMs = 3000;
    static constexpr int Stage1DurationMs = 4000;
    static constexpr int Stage2DurationMs = 4000;
    static constexpr int Stage3FeetModeDurationMs = 3000;
    static constexpr int Stage4ContractDurationMs = 3000;
    static constexpr int SystemUpdatePopupDurationMs = 4000;

    void ShowImageStage();
    void HideImageStage();
    void ShowWarningScreen();
    void ShowFeetModeCheckScreen();
    void ShowContractCheckScreen();
    void ShowSystemUpdatePopupAndExit();
    void HideSystemUpdatePopup();

    bool IsFirstBoot() const;
    void MarkFirstBootDone() const;
    std::string ReadJsonStringField(const std::string &filePath, const std::string &fieldName) const;
    bool CheckFeetModeAndRebootIfNeeded();
    bool CheckContractDateAndShutdownIfExpired();
    void SystemReboot();
    void SystemShutdown();
    void RestartBootSequence();
    bool IsDateExpired(const std::string &dateStr) const;

public:
    GUIBootupWindow();
    ~GUIBootupWindow();
    inline static const std::string Id = "SCS-00-1000";
    void Init() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;
    void StartBootSequence();
    void CompleteBootup();
};

#endif // GUIBOOTUPWINDOW_H
