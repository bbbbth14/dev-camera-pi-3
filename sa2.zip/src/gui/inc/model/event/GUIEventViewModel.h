#pragma once

#ifndef GUIEVENTVIEWMODEL_H
#define GUIEVENTVIEWMODEL_H

#include "GUIViewModelBase.h"
#include "GUIEventDispatcher.h"

class GUIEventViewModel : public GUIViewModelBase
{
private:
    bool IsMicOn = true;
    int _4GSignalStrength = -1;

public:
    static GUIEventViewModel &GetInstance();

    void onUPKeyShortPressed();
    void onMENU_OKKeyShortPressed();
    void onDOWNKeyShortPressed();
    void onMIC_ON_OFFKeyShortPressed();
    void onEmergency_CallKeyShortPressed();
    void onMotionDetected();
    void onShockDetected();
    void onLongDrivingAttention();
    void on4GSignalStrengthChanged(int strength);

    bool GetMicOnOff();
    void SetMicOnOff(bool on);

    int Get4GSignalStrength();
};

#endif // GUIEVENTVIEWMODEL_H