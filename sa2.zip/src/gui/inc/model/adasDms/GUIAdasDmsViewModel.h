#pragma once

#ifndef GUIADASDMSVIEWMODEL_H
#define GUIADASDMSVIEWMODEL_H

#include "GUIViewModelBase.h"
#include "GUIEventDispatcher.h"

class GUIAdasDmsViewModel : public GUIViewModelBase
{
private:
    float VehicleSpeed = 0;

public:
    static GUIAdasDmsViewModel &GetInstance();

    void onVehicleSpeedChanged(float vehicleSpeed);
    float GetVehicleSpeed();
};

#endif // GUIADASDMSVIEWMODEL_H