#pragma once

#ifndef NETWORK4G_H
#define NETWORK4G_H

#include "ComponentBase.h"

class Network4G : public ComponentBase
{
private:
    int strength = -2;

public:
    Network4G(lv_obj_t *parent);
    ~Network4G();
    void Init();

    void SetSignalStrength(int strength);
};

#endif // NETWORK4G_H