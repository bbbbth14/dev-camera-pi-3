#pragma once

#ifndef COMPONENTBASE_H
#define COMPONENTBASE_H

#include <vector>

#include "GUIEventBase.h"
#include "GUIEngine.h"

class ComponentBase : public GUIEventBase
{
public:
    lv_obj_t *parent = nullptr;
    lv_obj_t *obj = nullptr;

    lv_obj_t *image = nullptr;
    lv_obj_t *label = nullptr;

public:
    ComponentBase(lv_obj_t *parent);
    ~ComponentBase();
    virtual void Init() = 0;

    void SetLocation(int x, int y);
    int GetLocationX();
    int GetLocationY();

    void SetSize(int w, int h);
    int GetSizeW();
    int GetSizeH();

    void SetImage(std::string path, int x, int y);
    void SetImage(std::string path);

    void SetShadow(int ofs_x, int ofs_y, int w, float opa, uint32_t color);
    void SetText(std::string text, int w, int h, GUIEngine::Font font, uint32_t color);

    void Show();
    void Hide();
    void Delete();
};

#endif // COMPONENTBASE_H