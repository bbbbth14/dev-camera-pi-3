#pragma once

#ifndef GUICONTEXT_H
#define GUICONTEXT_H

#include <lvgl.h>
#include <lvgl/src/libs/freetype/lv_freetype.h>
#include <filesystem>
#include <iostream>
#include <functional>

class GUIEngine
{
private:
    lv_font_t *notoSansJP_Regular_28_font = nullptr;
    lv_font_t *notoSansJP_Regular_24_font = nullptr;
    lv_font_t *notoSansJP_Regular_16_font = nullptr;

    lv_display_t *rightDisplay = nullptr;

public:
    enum class Font
    {
        NotoSansJP_Regular_28,
        NotoSansJP_Regular_24,
        NotoSansJP_Regular_16
    };

public:
    GUIEngine();
    ~GUIEngine();
    void Init();
    static GUIEngine &GetInstance();

    void SetRightDisplay(lv_display_t *disp);
    lv_display_t *GetRightDisplay() const;

    lv_font_t *GetFont(Font font);
    void ReleaseFont();

    void ShowScreen(lv_obj_t *scr);
    lv_obj_t *CreateScreenCentered(lv_obj_t *parent);
    void SetScreenGradient(lv_obj_t *scr, uint32_t color_top, uint32_t color_bottom);
    void SetScreenColor(lv_obj_t *scr, uint32_t color);

    lv_obj_t *CreateRawObject(lv_obj_t *parent);
    void SetLocation(lv_obj_t *obj, int x, int y);
    int GetLocationX(lv_obj_t *obj);
    int GetLocationY(lv_obj_t *obj);
    void SetSize(lv_obj_t *obj, int w, int d);
    int GetSizeW(lv_obj_t *obj);
    int GetSizeH(lv_obj_t *obj);
    void SetAlign(lv_obj_t *obj, lv_align_t align);
    void SetAlignCenter(lv_obj_t *obj, int x, int y);
    void SetAlignRight(lv_obj_t *obj, int x, int y);
    void SetShadow(lv_obj_t *obj, int ofs_x, int ofs_y, int w, float opa, uint32_t color);
    void SetFlexFlowCol(lv_obj_t *obj);

    void SetParent(lv_obj_t *obj, lv_obj_t *parent);

    void SendToBottom(lv_obj_t *obj);

    lv_obj_t *CreateCardAbsolute(lv_obj_t *parent,
                                 int w, int h,
                                 int x, int y,
                                 uint32_t color,
                                 int r);
    lv_obj_t *CreateCardCentered(lv_obj_t *parent,
                                 int w, int h,
                                 uint32_t color,
                                 int r);

    lv_obj_t *CreateRectangleAbsoluteTransparent(lv_obj_t *parent,
                                                 int width, int height,
                                                 int x, int y);
    lv_obj_t *CreateRectangleCenteredTransparent(lv_obj_t *parent,
                                                 int width, int height);

    lv_obj_t *CreateCircleAbsolute(lv_obj_t *parent, int d, uint32_t color, int x, int y);
    lv_obj_t *CreateCircleCentered(lv_obj_t *parent, int d, uint32_t color);

    lv_obj_t *CreateImageAbsolute(lv_obj_t *parent, const char *path, int x, int y);
    lv_obj_t *CreateImageCentered(lv_obj_t *parent, const char *path);

    lv_obj_t *CreateLabelAbsoluteTextCentered(lv_obj_t *parent,
                                              const char *text,
                                              int w, int h,
                                              Font font,
                                              int x, int y,
                                              uint32_t color);
    lv_obj_t *CreateLabelAbsoluteTextLeft(lv_obj_t *parent,
                                          const char *text,
                                          int w, int h,
                                          Font font,
                                          int x, int y,
                                          uint32_t color);
    lv_obj_t *CreateLabelCenteredTextCentered(lv_obj_t *parent,
                                              const char *text,
                                              int w, int h,
                                              Font font,
                                              uint32_t color);
    lv_obj_t *CreateLabelCenteredTextLeft(lv_obj_t *parent,
                                          const char *text,
                                          int w, int h,
                                          Font font,
                                          uint32_t color);

    void ShowObject(lv_obj_t *obj);
    void HideObject(lv_obj_t *obj);
    void DeleteObject(lv_obj_t *obj);

    lv_timer_t *CreateOneShotTimer(std::function<void()> fn, uint32_t timeout_ms);

    // removed soon
    lv_obj_t *ShowImage(lv_obj_t *scr, const void *img);
    void CloseImage(lv_obj_t *img);
    void Dummy(lv_obj_t *scr);
};

#endif // GUICONTEXT_H
