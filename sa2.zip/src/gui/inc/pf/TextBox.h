#pragma once

#ifndef TEXTBOX_H
#define TEXTBOX_H

#include "ComponentBase.h"

class TextBox : public ComponentBase
{

public:
    TextBox(lv_obj_t *parent);
    ~TextBox();
    void Init();
};

#endif // TEXTBOX_H