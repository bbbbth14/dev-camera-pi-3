#pragma once

#ifndef BUTTON_H
#define BUTTON_H

#include "ComponentBase.h"

class Button : public ComponentBase
{

public:
    Button(lv_obj_t *parent);
    ~Button();
    void Init();
};

#endif // BUTTON_H