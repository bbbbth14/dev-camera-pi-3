#pragma once

#ifndef GUIEVENTDISPATCHER_H
#define GUIEVENTDISPATCHER_H

#include <vector>
#include <string>
#include <iostream>

#include "GUIEventBase.h"
#include "GUIWindowManagerBase.h"
#include "GUIBootupManager.h"
#include "GUIHomeManager.h"
#include "GUINotificationManager.h"

class GUIEventDispatcher
{
private:
    std::vector<std::unique_ptr<GUIWindowManagerBase>> managers;
    bool rightMenuOkClicked = false;
    bool showDrivingAdviceOnNextHome = false;

public:
    GUIEventDispatcher();
    ~GUIEventDispatcher();
    static GUIEventDispatcher &GetInstance();
    void Init();

    void AddManager(std::string name);
    GUIWindowManagerBase *GetCurrentManager();
    void BackToPreviousManager();

    void onKey(GUIWindowManagerBase::Key key, GUIWindowManagerBase::PressType press);
    void onUPKeyShortPressed();
    void onMENU_OKKeyShortPressed();
    void onDOWNKeyShortPressed();
    void onMIC_ON_OFFKeyShortPressed();
    void onEmergency_CallKeyShortPressed();
    void onMotionDetected();
    void onShockDetected();
    void onLongDrivingAttention();

    void onVehicleSpeedChanged(float VehicleSpeed);
    void on4GSignalStrengthChanged(int strength);
    void onBootupComplete();

    // Setup flow entry point. Setup is not implemented yet; falls back to main/home.
    void onSetupRequested();

    // Marks that the MENU/OK action originated from the RIGHT display on-screen button.
    void NotifyRightMenuOkClicked();

    // Returns true once per click (consumes the flag).
    bool ConsumeRightMenuOkClicked();

    // Ask Home screen to show a one-time Driving Advice popup.
    void NotifyShowDrivingAdviceOnNextHome();

    // Returns true once (consumes the flag).
    bool ConsumeShowDrivingAdviceOnNextHome();
};

#endif // GUIEVENTDISPATCHER_H