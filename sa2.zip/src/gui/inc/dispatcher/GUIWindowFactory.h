#pragma once

#ifndef GUIWINDOWFACTORY_H
#define GUIWINDOWFACTORY_H

#include <unordered_map>
#include <functional>
#include <string>
#include <memory>

#include "GUIWindowBase.h"

#include "GUIHomeWindow.h"
#include "GUIMenuMainWindow.h"
#include "GUIMenu1Window.h"
#include "GUIMenu2Window.h"

class GUIWindowFactory
{

public:
    GUIWindowFactory();
    ~GUIWindowFactory();
    static GUIWindowFactory &GetInstance();
    using Creator = std::function<std::unique_ptr<GUIWindowBase>()>;

    void Register(const std::string &name, Creator creator);
    std::unique_ptr<GUIWindowBase> Create(const std::string &name) const;

private:
    std::unordered_map<std::string, Creator> registry;
};

#endif // GUIWINDOWFACTORY_H