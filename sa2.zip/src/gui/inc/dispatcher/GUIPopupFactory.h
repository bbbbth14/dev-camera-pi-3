#pragma once

#ifndef GUIPOPUPFACTORY_H
#define GUIPOPUPFACTORY_H

#include <unordered_map>
#include <functional>
#include <string>
#include <memory>

#include "GUIEventDispatcher.h"

#include "GUIPopupBase.h"
#include "GUIEventPopup.h"

class GUIPopupFactory
{

public:
    GUIPopupFactory();
    ~GUIPopupFactory();
    static GUIPopupFactory &GetInstance();
    using Creator = std::function<std::unique_ptr<GUIPopupBase>()>;

    void Register(const std::string &name, Creator creator);
    std::unique_ptr<GUIPopupBase> Create(const std::string &name) const;

private:
    std::unordered_map<std::string, Creator> registry;
};

#endif // GUIPOPUPFACTORY_H