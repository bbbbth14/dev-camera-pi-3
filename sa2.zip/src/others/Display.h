#ifndef DISPLAY_H
#define DISPLAY_H

#include "lvgl/lvgl.h"
#include <string>

class Display
{
public:
    lv_display_t *create_display(std::wstring name, int width, int height);
    lv_obj_t *create_right_screen();
    lv_obj_t *create_bottom_screen();
    
private:
    lv_obj_t *create_button(lv_obj_t *cont, lv_style_t *style_btn, int btn_w, int btn_h, int col, int row, const char *text);
    lv_obj_t *create_stack_with_controls(lv_obj_t *parent, int btn_w, int btn_h, int col, int row, const char *text);
};

#endif // DISPLAY_H
