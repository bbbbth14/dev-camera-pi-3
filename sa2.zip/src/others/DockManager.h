#pragma once

#ifndef DOCKMANAGER_H
#define DOCKMANAGER_H

#include <Windows.h>

class DockManager
{
public:
    DockManager();
    ~DockManager();

    // Thiết lập 3 cửa sổ: Main (kéo), right (dock phải), bottom (dock dưới)
    void setup(HWND hwndMain, HWND hwndRight, HWND hwndBottom);

    // Thay đổi từng cửa sổ nếu cần
    void setMain(HWND hwndMain);
    void setRight(HWND hwndRight);
    void setBottom(HWND hwndBottom);

    // Gọi lại sắp xếp theo hiện trạng (ví dụ sau khi bạn đổi kích thước right/bottom)
    void realign();

private:
    // Cửa sổ
    HWND m_hwndMain = NULL;
    HWND m_hwndRight = NULL;
    HWND m_hwndBottom = NULL;

    // WndProc gốc để trả lại khi subclass
    WNDPROC m_prevMainProc = NULL;
    WNDPROC m_prevRightProc = NULL;
    WNDPROC m_prevBottomProc = NULL;

    // Subclass/unsubclass
    void subclassMain();
    void subclassRight();
    void subclassBottom();
    void unsubclassMain();
    void unsubclassRight();
    void unsubclassBottom();

    // Docking logic
    void dockRightOfMain();
    void dockBelowMain();
    static LRESULT CALLBACK MainWndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK DockedWndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

    // Borderless cho cửa sổ dock
    static void makeBorderless(HWND hwnd);

    // Trợ giúp: lấy instance từ HWND (lưu vào GWLP_USERDATA)
    static DockManager *getInstance(HWND hWnd);
    static void setInstance(HWND hWnd, DockManager *instance);
};

#endif // DOCKMANAGER_H