#include "DockManager.h"

DockManager::DockManager()
{
}
DockManager::~DockManager()
{
    // Trả lại WndProc gốc khi hủy
    unsubclassMain();
    unsubclassRight();
    unsubclassBottom();
}

void DockManager::setup(HWND hwndMain, HWND hwndRight, HWND hwndBottom)
{
    // Lưu và unsubclass cũ (nếu có)
    if (m_hwndMain)
        unsubclassMain();
    if (m_hwndRight)
        unsubclassRight();
    if (m_hwndBottom)
        unsubclassBottom();

    m_hwndMain = hwndMain;
    m_hwndRight = hwndRight;
    m_hwndBottom = hwndBottom;

    // Subclass cửa sổ
    subclassMain();
    subclassRight();
    subclassBottom();

    // Làm borderless cho hai cửa sổ dock
    // makeBorderless(m_hwndRight);
    // makeBorderless(m_hwndBottom);

    // Căn lần đầu
    realign();
}

void DockManager::setMain(HWND hwndMain)
{
    if (m_hwndMain == hwndMain)
        return;
    unsubclassMain();
    m_hwndMain = hwndMain;
    subclassMain();
    realign();
}

void DockManager::setRight(HWND hwndRight)
{
    if (m_hwndRight == hwndRight)
        return;
    unsubclassRight();
    m_hwndRight = hwndRight;
    subclassRight();
    makeBorderless(m_hwndRight);
    realign();
}

void DockManager::setBottom(HWND hwndBottom)
{
    if (m_hwndBottom == hwndBottom)
        return;
    unsubclassBottom();
    m_hwndBottom = hwndBottom;
    subclassBottom();
    makeBorderless(m_hwndBottom);
    realign();
}

void DockManager::realign()
{
    dockRightOfMain();
    dockBelowMain();
}

// ===== Subclass helpers =====
void DockManager::subclassMain()
{
    if (!m_hwndMain)
        return;
    // Lưu instance để dùng trong WndProc
    setInstance(m_hwndMain, this);
    m_prevMainProc = (WNDPROC)SetWindowLongPtr(m_hwndMain, GWLP_WNDPROC, (LONG_PTR)MainWndProcThunk);
}

void DockManager::subclassRight()
{
    if (!m_hwndRight)
        return;
    setInstance(m_hwndRight, this);
    m_prevRightProc = (WNDPROC)SetWindowLongPtr(m_hwndRight, GWLP_WNDPROC, (LONG_PTR)DockedWndProcThunk);
}

void DockManager::subclassBottom()
{
    if (!m_hwndBottom)
        return;
    setInstance(m_hwndBottom, this);
    m_prevBottomProc = (WNDPROC)SetWindowLongPtr(m_hwndBottom, GWLP_WNDPROC, (LONG_PTR)DockedWndProcThunk);
}

void DockManager::unsubclassMain()
{
    if (m_hwndMain && m_prevMainProc)
    {
        SetWindowLongPtr(m_hwndMain, GWLP_WNDPROC, (LONG_PTR)m_prevMainProc);
        m_prevMainProc = NULL;
    }
}

void DockManager::unsubclassRight()
{
    if (m_hwndRight && m_prevRightProc)
    {
        SetWindowLongPtr(m_hwndRight, GWLP_WNDPROC, (LONG_PTR)m_prevRightProc);
        m_prevRightProc = NULL;
    }
}

void DockManager::unsubclassBottom()
{
    if (m_hwndBottom && m_prevBottomProc)
    {
        SetWindowLongPtr(m_hwndBottom, GWLP_WNDPROC, (LONG_PTR)m_prevBottomProc);
        m_prevBottomProc = NULL;
    }
}

// ===== Dock logic =====
void DockManager::dockRightOfMain()
{
    if (!m_hwndMain || !m_hwndRight)
        return;

    RECT rm;
    GetWindowRect(m_hwndMain, &rm);
    int MainH = rm.bottom - rm.top;

    RECT rr;
    GetWindowRect(m_hwndRight, &rr);
    int rightW = rr.right - rr.left;

    int x = rm.right; // sát cạnh phải Main
    int y = rm.top;

    SetWindowPos(m_hwndRight, NULL, x, y, rightW, MainH,
                 SWP_NOZORDER | SWP_NOACTIVATE);
}

void DockManager::dockBelowMain()
{
    if (!m_hwndMain || !m_hwndBottom)
        return;

    RECT rm;
    GetWindowRect(m_hwndMain, &rm);
    int MainW = rm.right - rm.left;

    RECT rb;
    GetWindowRect(m_hwndBottom, &rb);
    int bottomH = rb.bottom - rb.top;

    int x = rm.left;   // thẳng hàng trái với Main
    int y = rm.bottom; // ngay dưới Main

    SetWindowPos(m_hwndBottom, NULL, x, y, MainW, bottomH,
                 SWP_NOZORDER | SWP_NOACTIVATE);
}

// ===== WndProc thunks =====
LRESULT CALLBACK DockManager::MainWndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    DockManager *self = getInstance(hWnd);
    if (!self)
    {
        // Không có instance → dùng DefWindowProc
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }

    switch (msg)
    {
    case WM_MOVE:
    case WM_MOVING:
    case WM_SIZE:
        self->dockRightOfMain();
        self->dockBelowMain();
        break;
    default:
        break;
    }

    if (self->m_prevMainProc)
        return CallWindowProc(self->m_prevMainProc, hWnd, msg, wParam, lParam);
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

LRESULT CALLBACK DockManager::DockedWndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    DockManager *self = getInstance(hWnd);
    if (!self)
    {
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }

    // Chặn kéo caption để không thể kéo rời
    if (msg == WM_NCLBUTTONDOWN && wParam == HTCAPTION)
        return 0;

    // Quyết định gọi WndProc gốc tương ứng
    if (hWnd == self->m_hwndRight && self->m_prevRightProc)
        return CallWindowProc(self->m_prevRightProc, hWnd, msg, wParam, lParam);

    if (hWnd == self->m_hwndBottom && self->m_prevBottomProc)
        return CallWindowProc(self->m_prevBottomProc, hWnd, msg, wParam, lParam);

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// ===== Borderless helper =====
void DockManager::makeBorderless(HWND hwnd)
{
    if (!hwnd)
        return;
    LONG style = GetWindowLong(hwnd, GWL_STYLE);
    // style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
    style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
    SetWindowLong(hwnd, GWL_STYLE, style);
    SetWindowPos(hwnd, NULL, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
}

// ===== Instance helpers via GWLP_USERDATA =====
DockManager *DockManager::getInstance(HWND hWnd)
{
    return reinterpret_cast<DockManager *>(GetWindowLongPtr(hWnd, GWLP_USERDATA));
}

void DockManager::setInstance(HWND hWnd, DockManager *instance)
{
    SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)instance);
}
