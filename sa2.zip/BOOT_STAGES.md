# Boot Sequence - FEET Mode & Contract Validation

## New Boot Stages

The boot sequence now includes validation stages after the warning screen:

### Stage 3: FEET/NON-FEET Mode Check
- **Purpose**: Validates device operating mode from user configuration
- **Config File**: `src/gui/src/pf/user.json`
- **Format**:
  ```json
  {
    "mode": "FEET"
  }
  ```
  or
  ```json
  {
    "mode": "NON-FEET"
  }
  ```

**Behavior**:
- First run: Saves the mode from `user.json` to `current_mode.json`
- Subsequent runs: Compares `user.json` mode with saved `current_mode.json`
- If **mode changed**: Display "Mode Changed! Rebooting..." and reboot system after 2s
- If **mode same**: Display "Mode: [mode] (OK)" and continue to next stage
- If **user.json missing**: Assumes mode is OK and continues

### Stage 4: Contract Date Validation
- **Purpose**: Validates device contract/license expiration
- **Config File**: `src/gui/src/pf/server.json`
- **Format**:
  ```json
  {
    "contract_date": "2026-12-31"
  }
  ```
  or
  ```json
  {
    "contract_date": "expired"
  }
  ```

**Behavior**:
- Reads `contract_date` from `server.json`
- If **contract_date is "expired" or "invalid"**: Display "Contract Expired! Shutting Down..." and shutdown after 2s
- If **contract_date is valid date**: Display "Contract: Valid" and continue to next stage
- If **server.json missing**: Assumes contract is OK and continues

## Complete Boot Sequence

### First Boot
1. **Stage 0**: Image display (3s)
2. **Stage 1**: Boot text "THE COMPANY" (4s)
3. **Stage 2**: Warning screen (4s)
4. **Stage 3**: FEET mode check (3s) → reboot if changed
5. **Stage 4**: Contract validation (3s) → shutdown if expired
6. **Stage 5**: "Enter the setup?" prompt (wait for RIGHT MENU/OK)
7. **System Update popup** with 4s countdown
8. Navigate to Home screen

### Subsequent Boot
1. **Stage 0**: Image display (3s)
2. **Stage 1**: Boot text "THE COMPANY" (4s)
3. **Stage 2**: Warning screen (4s)
4. **Stage 3**: FEET mode check (3s) → reboot if changed
5. **Stage 4**: Contract validation (3s) → shutdown if expired
6. Navigate directly to Home screen (skip setup prompt)
7. **Driving Advice popup** on Home screen (4s)

## Testing Scenarios

### Test Mode Change (triggers reboot)
1. Edit `src/gui/src/pf/user.json`:
   ```json
   {
     "mode": "NON-FEET"
   }
   ```
2. Run app → boots normally, saves "NON-FEET"
3. Edit `user.json` again:
   ```json
   {
     "mode": "FEET"
   }
   ```
4. Run app → Stage 3 detects change, shows "Mode Changed! Rebooting...", exits after 2s

### Test Contract Expiration (triggers shutdown)
1. Edit `src/gui/src/pf/server.json`:
   ```json
   {
     "contract_date": "expired"
   }
   ```
2. Run app → Stage 4 detects expiration, shows "Contract Expired! Shutting Down...", exits after 2s

### Test Normal Boot
1. Ensure `user.json` has consistent mode
2. Ensure `server.json` has valid date (not "expired")
3. Run app → all stages pass, proceeds to home screen

## Files
- **user.json**: User/app configuration (mode setting)
- **current_mode.json**: Auto-generated to track current mode
- **server.json**: Server-provided contract/license data
- **first_boot_done.json**: Marks first boot completion

All config files are located in: `src/gui/src/pf/`
