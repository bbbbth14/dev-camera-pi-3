﻿# Inquiries Feature - How It Works

## Overview

The Inquiries feature provides access to two types of information:
- **Notifications**: Messages from the server (via GUIActionHandler)
- **Contacts**: Static list of 3 contact entries

The feature uses a **unified manager architecture** with a single `GUIInquiriesManager` controlling 4 different windows, eliminating the complexity of nested manager creation.

---

## Architecture Components

### 1. Manager (1 Manager)
**`GUIInquiriesManager`**
- Single point of control for the entire Inquiries feature
- Manages screen state and navigation flow
- Handles all button events through `onKey()` method
- Creates and switches between 4 windows based on user navigation

**Key State Variables:**
```cpp
enum ScreenType { 
    SCREEN_GROUP = 0,    // Folder selection screen
    SCREEN_INDEX = 1,    // Item list screen
    SCREEN_DETAIL = 2    // Detail view screen
};

enum FolderType { 
    FOLDER_NOTIFICATION = 0, 
    FOLDER_CONTACT = 1 
};

ScreenType currentScreen;      // Tracks which screen is active
FolderType selectedFolder;     // Notification or Contact
int selectedItemIndex;         // Which item user selected in list
```

### 2. Windows (4 Windows)

#### Window 1: **`GUIInquiriesGroupWindow`**
- **Purpose**: Folder selection screen (first level)
- **Displays**: 2 folders - "Notification" and "Contact"
- **User Actions**: 
  - UP/DOWN: Navigate between folders
  - MENU_OK: Open selected folder → transitions to Index screen

#### Window 2: **`GUIInquiriesIndexWindow`**
- **Purpose**: Item list screen (second level)
- **Displays**: List of items from selected folder
  - Notification folder: Server-provided notification list
  - Contact folder: Static contact list (3 items)
- **User Actions**:
  - UP/DOWN: Navigate between items
  - MENU_OK: View item detail → transitions to Detail screen
  - MIC_ON_OFF: Back to folder selection → returns to Group screen

#### Window 3: **`GUINotificationDetailWindow`**
- **Purpose**: Notification detail view (third level)
- **Displays**: Full details of selected notification
- **Data Source**: `GUIActionHandler::GetNotificationDetail(index)`
- **User Actions**:
  - MIC_ON_OFF: Back to notification list → returns to Index screen

#### Window 4: **`GUIContactDetailWindow`**
- **Purpose**: Contact detail view (third level)
- **Displays**: Full details of selected contact
- **Data Source**: Static contact data
- **User Actions**:
  - MIC_ON_OFF: Back to contact list → returns to Index screen

---

## Step-by-Step User Flow

### Step 1: Enter Inquiries Feature
1. User navigates to Inquiries from main menu
2. `GUIEventDispatcher` creates `GUIInquiriesManager`
3. Manager initializes:
   - Sets `currentScreen = SCREEN_GROUP`
   - Creates and shows `GUIInquiriesGroupWindow`
4. **User sees**: Folder selection screen with 2 options

```
┌─────────────────────┐
│   INQUIRIES         │
├─────────────────────┤
│ ► Notification      │
│   Contact           │
└─────────────────────┘
```

### Step 2: Navigate Folders
1. User presses **DOWN** key
2. GroupWindow updates highlighted folder
3. **User sees**: Contact folder highlighted

```
┌─────────────────────┐
│   INQUIRIES         │
├─────────────────────┤
│   Notification      │
│ ► Contact           │
└─────────────────────┘
```

### Step 3: Open Folder (e.g., Notification)
1. User selects Notification and presses **MENU_OK**
2. GroupWindow forwards event to Manager via `onKey(MENU_OK)`
3. Manager executes:
   ```cpp
   selectedFolder = FOLDER_NOTIFICATION;
   currentScreen = SCREEN_INDEX;
   ShowIndexWindow(selectedFolder);
   ```
4. `ShowIndexWindow()` performs:
   - Fetches notification list from `GUIActionHandler`
   - Creates `GUIInquiriesIndexWindow` if not exists
   - Calls `SetIndexTitle("Notification")`
   - Calls `SetIndexItemsList(notificationItems)`
   - Shows IndexWindow
5. **User sees**: List of notifications

```
┌─────────────────────┐
│   NOTIFICATION      │
├─────────────────────┤
│ ► Server Update     │
│   New Message       │
│   System Alert      │
└─────────────────────┘
```

### Step 4: Navigate Item List
1. User presses **DOWN** to navigate between items
2. IndexWindow updates highlighted item via `SetActiveIndex()`
3. **User sees**: Different items highlighted as they navigate

### Step 5: View Item Detail
1. User selects an item and presses **MENU_OK**
2. IndexWindow forwards to Manager via `onKey(MENU_OK)`
3. Manager executes:
   ```cpp
   selectedItemIndex = indexWindow->GetActiveIndex();
   currentScreen = SCREEN_DETAIL;
   ShowDetailWindow(selectedFolder, selectedItemIndex);
   ```
4. `ShowDetailWindow()` performs:
   - Determines which detail window to create based on `selectedFolder`
   - If FOLDER_NOTIFICATION: Creates `GUINotificationDetailWindow`
   - If FOLDER_CONTACT: Creates `GUIContactDetailWindow`
   - Fetches detail data from appropriate source
   - Populates detail window with data
   - Shows detail window
5. **User sees**: Full detail view of selected notification

```
┌─────────────────────┐
│   SERVER UPDATE     │
├─────────────────────┤
│ Time: 10:30 AM      │
│ From: System Admin  │
│                     │
│ The server will be  │
│ updated tonight at  │
│ 2:00 AM. Please    │
│ save your work.    │
└─────────────────────┘
```

### Step 6: Navigate Back to List
1. User presses **MIC_ON_OFF** (back button)
2. DetailWindow forwards to Manager
3. Manager executes:
   ```cpp
   currentScreen = SCREEN_INDEX;
   ShowIndexWindow(selectedFolder); // Returns to same list
   ```
4. **User sees**: Notification list again, with same item highlighted

### Step 7: Navigate Back to Folders
1. User presses **MIC_ON_OFF** again
2. IndexWindow forwards to Manager
3. Manager executes:
   ```cpp
   currentScreen = SCREEN_GROUP;
   ShowGroupWindow();
   ```
4. **User sees**: Folder selection screen again

### Step 8: View Contact (Alternative Path)
1. User selects **Contact** folder and presses **MENU_OK**
2. Manager shows IndexWindow with contact list (3 static contacts)
3. User navigates and selects a contact
4. Manager shows `GUIContactDetailWindow` with contact details
5. Back navigation works the same way via **MIC_ON_OFF**

---

## Navigation Map

```
                    ┌──────────────────┐
                    │  Group Window    │
                    │  (Folder Select) │
                    └────────┬─────────┘
                             │ MENU_OK
                ┌────────────┴────────────┐
                │                         │
         ┌──────▼──────┐           ┌─────▼──────┐
         │ Notification│           │  Contact   │
         │    List     │           │    List    │
         └──────┬──────┘           └─────┬──────┘
                │ MENU_OK                │ MENU_OK
         ┌──────▼──────┐           ┌─────▼──────┐
         │ Notification│           │  Contact   │
         │   Detail    │           │   Detail   │
         └─────────────┘           └────────────┘
         
         MIC_ON_OFF = Back to previous screen
```

---

## Button Mapping

| Button       | Screen        | Action                                    |
|--------------|---------------|-------------------------------------------|
| **UP**       | Group         | Navigate to previous folder               |
| **DOWN**     | Group         | Navigate to next folder                   |
| **MENU_OK**  | Group         | Open selected folder → Index screen       |
| **UP**       | Index         | Navigate to previous item                 |
| **DOWN**     | Index         | Navigate to next item                     |
| **MENU_OK**  | Index         | Open item detail → Detail screen          |
| **MIC_ON_OFF**| Index        | Back to folders → Group screen            |
| **MIC_ON_OFF**| Detail       | Back to list → Index screen               |

---

## SetActiveIndex / GetActiveIndex Function Manual

### Overview
These functions are the core interface between the Manager and Windows for tracking which item is currently selected/highlighted in a list.

### `SetActiveIndex(int index)` - Window Method

**Purpose**: Updates which item is visually highlighted in a list window (Group or Index windows)

**Called by**: 
- Window itself (when user presses UP/DOWN keys)
- Manager (when restoring window state)

**Parameters**:
- `index` (int): Zero-based index of item to highlight
  - GroupWindow: 0 = Notification, 1 = Contact
  - IndexWindow: 0 to (itemCount - 1)

**Behavior**:
1. Validates index is within valid range [0, itemCount-1]
2. Updates internal `activeIndex` member variable
3. Updates LVGL visual state to highlight the item at `index`
4. May trigger scrolling if item is not visible

**Example Usage**:
```cpp
// User presses DOWN key in GroupWindow
void GUIInquiriesGroupWindow::onDOWNKeyShortPressed() {
    int currentIndex = GetActiveIndex();
    if (currentIndex < 1) {  // Max 2 folders (0, 1)
        SetActiveIndex(currentIndex + 1);
    }
}

// User presses UP key in IndexWindow
void GUIInquiriesIndexWindow::onUPKeyShortPressed() {
    int currentIndex = GetActiveIndex();
    if (currentIndex > 0) {
        SetActiveIndex(currentIndex - 1);
    }
}

// Manager restoring window state
void GUIInquiriesManager::ShowIndexWindow(FolderType folder) {
    indexWindow->SetIndexItemsList(items);
    indexWindow->SetActiveIndex(selectedItemIndex);  // Restore position
    indexWindow->Show();
}
```

**Important Notes**:
- ⚠️ Window handles visual updates only - does NOT call Manager
- ⚠️ Does NOT trigger navigation to detail screen
- ⚠️ Index wrapping (0 → max, max → 0) is handled by caller, not SetActiveIndex

### `GetActiveIndex()` - Window Method

**Purpose**: Returns the index of currently highlighted item

**Called by**: 
- Manager (when user presses MENU_OK to get selected item)
- Window itself (when calculating next UP/DOWN position)

**Returns**: 
- `int`: Zero-based index of currently highlighted item
- Returns 0 if no item selected or window empty

**Example Usage**:
```cpp
// Manager getting selected item when user presses MENU_OK
void GUIInquiriesManager::onKey(GUIKeyEvent event) {
    if (currentScreen == SCREEN_INDEX && event == MENU_OK) {
        selectedItemIndex = indexWindow->GetActiveIndex();
        currentScreen = SCREEN_DETAIL;
        ShowDetailWindow(selectedFolder, selectedItemIndex);
    }
}

// Manager getting selected folder
void GUIInquiriesManager::onKey(GUIKeyEvent event) {
    if (currentScreen == SCREEN_GROUP && event == MENU_OK) {
        int folderIndex = groupWindow->GetActiveIndex();
        selectedFolder = static_cast<FolderType>(folderIndex);
        currentScreen = SCREEN_INDEX;
        ShowIndexWindow(selectedFolder);
    }
}
```

**Important Notes**:
- ✅ Always returns valid index (never -1 or out of bounds)
- ✅ Returns 0 for empty lists
- ✅ Lightweight operation - can be called frequently

### Typical Usage Pattern

**Pattern 1: User Navigation (Window handles)**
```cpp
// In Window class (e.g., GUIInquiriesIndexWindow)
void onDOWNKeyShortPressed() {
    int current = GetActiveIndex();        // Get current position
    int maxIndex = itemList.size() - 1;
    if (current < maxIndex) {
        SetActiveIndex(current + 1);       // Move highlight down
    }
    // Visual update handled by SetActiveIndex
}
```

**Pattern 2: User Selection (Manager handles)**
```cpp
// In Manager class (GUIInquiriesManager)
void onKey(GUIKeyEvent event) {
    if (event == MENU_OK) {
        int selected = indexWindow->GetActiveIndex();  // Get selected item
        ShowDetailWindow(selectedFolder, selected);     // Navigate to detail
    }
}
```

**Pattern 3: State Restoration (Manager sets)**
```cpp
// In Manager class - when returning to a window
void ShowIndexWindow(FolderType folder) {
    // ... populate data ...
    indexWindow->SetActiveIndex(selectedItemIndex);  // Restore cursor position
    indexWindow->Show();
    // User sees list with same item highlighted as before
}
```

### Window Internal Implementation

**GroupWindow (2 folders):**
```cpp
private:
    int activeIndex = 0;  // 0 = Notification, 1 = Contact

public:
    void SetActiveIndex(int index) {
        if (index >= 0 && index < 2) {  // Validate: 2 folders only
            activeIndex = index;
            UpdateVisualHighlight();     // Update LVGL list visual
        }
    }
    
    int GetActiveIndex() const {
        return activeIndex;
    }
```

**IndexWindow (variable size list):**
```cpp
private:
    int activeIndex = 0;
    vector<Item> itemList;

public:
    void SetActiveIndex(int index) {
        if (index >= 0 && index < itemList.size()) {
            activeIndex = index;
            UpdateVisualHighlight();     // Update LVGL list visual
            ScrollToVisibleIfNeeded();   // Auto-scroll if needed
        }
    }
    
    int GetActiveIndex() const {
        return activeIndex;
    }
```

### Common Pitfalls

❌ **DON'T: Set index without validation**
```cpp
// BAD: No bounds checking
void SetActiveIndex(int index) {
    activeIndex = index;  // May cause crash if index invalid!
}
```

✅ **DO: Always validate**
```cpp
// GOOD: Validate before setting
void SetActiveIndex(int index) {
    if (index >= 0 && index < itemList.size()) {
        activeIndex = index;
    }
}
```

❌ **DON'T: Call Manager from SetActiveIndex**
```cpp
// BAD: Creates circular dependency
void SetActiveIndex(int index) {
    activeIndex = index;
    manager->OnItemSelected(index);  // NO! This is wrong
}
```

✅ **DO: Keep it as view update only**
```cpp
// GOOD: Only updates visual state
void SetActiveIndex(int index) {
    activeIndex = index;
    UpdateVisualHighlight();  // Pure visual update
}
```

❌ **DON'T: Implement wrapping in SetActiveIndex**
```cpp
// BAD: Wrapping logic in wrong place
void SetActiveIndex(int index) {
    if (index >= itemList.size()) index = 0;  // Wrapping in setter
    if (index < 0) index = itemList.size() - 1;
    activeIndex = index;
}
```

✅ **DO: Let caller handle wrapping**
```cpp
// GOOD: Caller controls wrapping behavior
void onDOWNKeyShortPressed() {
    int next = GetActiveIndex() + 1;
    if (next >= itemList.size()) {
        next = 0;  // Wrap to top (if desired)
    }
    SetActiveIndex(next);
}
```

### State Flow Diagram

```
User Action (UP/DOWN)
        ↓
Window: GetActiveIndex()  ──→  Calculate new index
        ↓
Window: SetActiveIndex(newIndex)
        ↓
Update LVGL visual highlight
        ↓
User sees updated selection
        ↓
User presses MENU_OK
        ↓
Manager: GetActiveIndex()  ──→  Get selected item
        ↓
Manager: Navigate to detail screen
```

### Summary

| Function          | Who Calls      | Purpose                           | When Used                    |
|-------------------|----------------|-----------------------------------|------------------------------|
| `SetActiveIndex`  | Window or Manager | Update visual highlight       | UP/DOWN keys, state restore  |
| `GetActiveIndex`  | Manager or Window | Read current selection        | MENU_OK pressed, navigation  |

**Key Principles:**
- Windows manage their own visual state via SetActiveIndex
- Manager queries state via GetActiveIndex when making decisions
- SetActiveIndex is pure visual update - no business logic
- GetActiveIndex is simple state query - no side effects

---

## Data Flow

### Notification Data Flow
```
Server → GUIActionHandler → GUIInquiriesManager → IndexWindow
                                                    ↓
                                            DetailWindow (display)
```

**Implementation:**
1. Manager calls `GUIActionHandler::GetNotificationList()`
2. ActionHandler fetches from server (TODO: currently returns mock data)
3. Manager passes list to `IndexWindow::SetIndexItemsList()`
4. For details: Manager calls `GetNotificationDetail(index)` and passes to DetailWindow

### Contact Data Flow
```
Static Data → GUIInquiriesManager → IndexWindow
                                      ↓
                                DetailWindow (display)
```

**Implementation:**
1. Manager has static contact array (3 contacts)
2. Manager passes contact list to IndexWindow
3. For details: Manager passes selected contact data to ContactDetailWindow

---

## Key Design Decisions

### 1. **Unified Manager Pattern**
- **Why**: Eliminates complexity of nested manager creation
- **Before**: GroupManager created IndexManager, IndexManager created DetailWindows
- **After**: Single manager owns all 4 windows, switches between them
- **Benefit**: Simpler state management, easier debugging, cleaner code

### 2. **Screen State Enum**
- **Why**: Clear tracking of current navigation level
- **How**: `ScreenType currentScreen` determines which window is active
- **Benefit**: Easy to understand navigation flow, simple back button logic

### 3. **Folder Type Tracking**
- **Why**: Manager needs to know which data source to use
- **How**: `FolderType selectedFolder` remembered when folder selected
- **Benefit**: Same IndexWindow can show both notification and contact lists

### 4. **Window Reuse**
- **Why**: Avoid repeatedly creating/destroying windows
- **How**: Manager keeps window pointers, shows/hides as needed
- **Benefit**: Better performance, maintains window state between navigations

### 5. **Event Delegation**
- **Why**: Centralized control in Manager
- **How**: All windows call `manager->onKey(event)` to delegate
- **Benefit**: Manager has complete control over navigation logic

---

## Implementation Checklist

### Manager Responsibilities
- ✅ Create all 4 windows on demand
- ✅ Track current screen state (GROUP/INDEX/DETAIL)
- ✅ Track selected folder (NOTIFICATION/CONTACT)
- ✅ Track selected item index
- ✅ Handle all navigation via `onKey()`
- ✅ Fetch data from appropriate sources
- ✅ Pass data to windows before showing them
- ✅ Switch between windows using `SetCurrentWindow()`

### Window Responsibilities
- ✅ Display data provided by Manager
- ✅ Handle visual updates (highlighting, scrolling)
- ✅ Provide getter methods (GetActiveIndex, etc.)
- ✅ Delegate all navigation events to Manager
- ❌ DO NOT handle navigation logic directly
- ❌ DO NOT create other windows
- ❌ DO NOT fetch data from external sources

---

## Future Enhancements

1. **Server Integration**
   - Complete GUIActionHandler notification fetching
   - Handle async data loading
   - Add loading indicators

2. **Dynamic Contact List**
   - Load contacts from server instead of static data
   - Add search/filter functionality

3. **Detail Actions**
   - Add "Mark as Read" for notifications
   - Add "Call" or "Message" for contacts
   - Add delete/archive actions

4. **Pagination**
   - Handle large notification lists
   - Load more items on demand

5. **Refresh Capability**
   - Pull-to-refresh for notification list
   - Auto-refresh with new notification count

---

## Troubleshooting

### Issue: Windows not switching correctly
- **Check**: `currentScreen` value in Manager
- **Check**: `SetCurrentWindow()` called after screen state change
- **Check**: Window pointers not null before showing

### Issue: Wrong data displayed
- **Check**: `selectedFolder` matches expected folder type
- **Check**: Data fetched before passing to window
- **Check**: `SetIndexItemsList()` or `SetData()` called before `Show()`

### Issue: Back button not working
- **Check**: Window calls `manager->onKey(MIC_ON_OFF)`
- **Check**: Manager handles MIC_ON_OFF for current screen type
- **Check**: Previous screen state restored correctly

---

## Summary

The Inquiries feature uses a **simple, unified architecture**:
- **1 Manager** controls everything
- **4 Windows** display different views
- **3 Screen Levels**: Group → Index → Detail
- **2 Data Sources**: Server (notifications) + Static (contacts)
- **Simple Navigation**: Screen state enum + window switching

This design replaces the old complex nested manager pattern with a straightforward state machine that's easy to understand, maintain, and extend.
