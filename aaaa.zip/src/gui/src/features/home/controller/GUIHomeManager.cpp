#include "GUIHomeManager.h"

GUIHomeManager::GUIHomeManager() : state(State::HOME)
{
    Init();
}

GUIHomeManager::~GUIHomeManager()
{
}

std::string GUIHomeManager::GetStateName() const
{
    switch (state)
    {
    case State::HOME:
        return "HOME";
    default:
        return "UNKNOWN";
    }
}

void GUIHomeManager::Init()
{
    SetCurrentWindow(GUIHomeWindow::Id);

    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();

    bool isMicOn = GUIEventViewModel::GetInstance().GetMicOnOff();
    current->SetMicOnOff(isMicOn);

    int _4gSignalStrength = GUIEventViewModel::GetInstance().Get4GSignalStrength();
    current->Set4GSignalStrength(_4gSignalStrength);
}

void GUIHomeManager::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    std::cout << "GUIHomeManager::onKey - key=" << (int)key << ", press=" << (int)press << std::endl;

    // Call window's onKey first to allow it to handle popup interactions
    GUIHomeWindow *homeWin = (GUIHomeWindow *)GetCurrentWindow();
    if (homeWin)
    {
        std::cout << "Calling homeWin->onKey()" << std::endl;
        homeWin->onKey(key, press, ctx);

        std::cout << "IsServerInfoPopupActive=" << homeWin->IsServerInfoPopupActive() << std::endl;

        // If popup is active, don't process manager-level actions
        if (homeWin->IsServerInfoPopupActive())
        {
            std::cout << "Popup is active, returning early" << std::endl;
            return;
        }
    }

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case PressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case PressType::Short:
            if (state == State::HOME)
            {
                ctx.doCreateNewManager = true;
                ctx.newManagerName = GUIMenuManager::Id;
            }
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case PressType::Short:
            ToggleMicOnOff();
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}
void GUIHomeManager::on4GSignalStrengthChanged(int strength)
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    current->Set4GSignalStrength(strength);
}
void GUIHomeManager::ToggleMicOnOff()
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();

    bool isMicOn = GUIEventViewModel::GetInstance().GetMicOnOff();
    current->SetMicOnOff(!isMicOn);

    GUIEventViewModel::GetInstance().SetMicOnOff(!isMicOn);
}

void GUIHomeManager::onShockDetected()
{
    std::cout << "GUIHomeManager::onShockDetected() called" << std::endl;
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    if (current)
    {
        std::cout << "Forwarding to GUIHomeWindow::onShockDetected()" << std::endl;
        current->onShockDetected();
    }
    else
    {
        std::cout << "Warning: current window is null" << std::endl;
    }
}

void GUIHomeManager::onMotionDetected()
{
    std::cout << "GUIHomeManager::onMotionDetected() called" << std::endl;
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    if (current)
    {
        std::cout << "Forwarding to GUIHomeWindow::onMotionDetected()" << std::endl;
        current->onMotionDetected();
    }
    else
    {
        std::cout << "Warning: current window is null" << std::endl;
    }
}
