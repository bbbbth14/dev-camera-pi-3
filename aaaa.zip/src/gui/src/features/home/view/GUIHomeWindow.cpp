#include "GUIHomeWindow.h"

#include "GUIEventDispatcher.h"
#include "TextBox.h"
#include <filesystem>
#include <fstream>

GUIHomeWindow::GUIHomeWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIHomeWindow::~GUIHomeWindow()
{
}

void GUIHomeWindow::Init()
{
    GUIWindowLayoutBase::Init();

    auto &eng = GUIEngine::GetInstance();
    // eng.SetScreenColor(scr, 0x67D1FF);
    eng.SetScreenColor(scr, 0x000000);

    SetUpImage(LV_SYMBOL_UP);
    SetMenuOkImage(LV_SYMBOL_OK);
    SetDownImage(LV_SYMBOL_DOWN);

    network4G = std::make_unique<Network4G>(titleTextBox->parent);
    network4G->Init();
    network4G->SetLocation(528, 8);
    network4G->SetSize(60, 32);

    // Check if this is subsequent boot and if update is available
    if (GUIEventDispatcher::GetInstance().ConsumeShowDrivingAdviceOnNextHome())
    {
        const auto serverJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "server.json";
        std::string updateAvailable = ReadJsonStringField(serverJsonPath.string(), "update_available");

        if (updateAvailable == "yes")
        {
            std::cout << "Update Data: available, showing popup" << std::endl;
            ShowUpdateDataPopup();
        }
        else
        {
            std::cout << "Update Data: not available, showing server info popups" << std::endl;
            ShowServerInfoPopups();
        }
    }
}

std::string GUIHomeWindow::ReadJsonStringField(const std::string &filePath, const std::string &fieldName) const
{
    try
    {
        std::ifstream file(filePath);
        if (!file.is_open())
            return "";

        std::string line;
        while (std::getline(file, line))
        {
            size_t pos = line.find("\"" + fieldName + "\"");
            if (pos != std::string::npos)
            {
                size_t colonPos = line.find(":", pos);
                if (colonPos != std::string::npos)
                {
                    size_t firstQuote = line.find("\"", colonPos);
                    if (firstQuote != std::string::npos)
                    {
                        size_t secondQuote = line.find("\"", firstQuote + 1);
                        if (secondQuote != std::string::npos)
                        {
                            return line.substr(firstQuote + 1, secondQuote - firstQuote - 1);
                        }
                    }
                }
            }
        }
        return "";
    }
    catch (...)
    {
        return "";
    }
}

void GUIHomeWindow::ShowUpdateDataPopup()
{
    if (updateDataShown)
        return;

    updateDataShown = true;

    auto &eng = GUIEngine::GetInstance();
    if (!updateDataOverlay)
        updateDataOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!updateDataCard)
    {
        updateDataCard = eng.CreateCardCentered(updateDataOverlay, 440, 140, 0xFFFFFF, 8);
        eng.SetShadow(updateDataCard, 0, 6, 20, 0.35f, 0x000000);
    }

    updateDataTextBox = std::make_unique<TextBox>(updateDataCard);
    updateDataTextBox->Init();
    updateDataTextBox->SetLocation(0, 45);
    updateDataTextBox->SetSize(440, 50);
    updateDataTextBox->SetText("Update Data", 440, 50, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    eng.CreateOneShotTimer(
        [this]()
        {
            HideUpdateDataPopup();
            ShowServerInfoPopups();
        },
        4000);
}

void GUIHomeWindow::HideUpdateDataPopup()
{
    if (!updateDataShown)
        return;

    std::cout << "Update Data: hiding popup" << std::endl;

    updateDataShown = false;
    updateDataTextBox.reset();

    if (updateDataOverlay)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(updateDataOverlay);
    }

    updateDataOverlay = nullptr;
    updateDataCard = nullptr;
}

void GUIHomeWindow::ShowServerInfoPopups()
{
    ShowPreDrivingPopup();
}

void GUIHomeWindow::ShowPreDrivingPopup()
{
    currentServerInfoStage = 1;
    auto &eng = GUIEngine::GetInstance();

    if (!serverInfoOverlay)
        serverInfoOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!serverInfoCard)
    {
        serverInfoCard = eng.CreateCardCentered(serverInfoOverlay, 440, 180, 0xFFFFFF, 8);
        eng.SetShadow(serverInfoCard, 0, 6, 20, 0.35f, 0x000000);
    }

    serverInfoTitleTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoTitleTextBox->Init();
    serverInfoTitleTextBox->SetLocation(0, 20);
    serverInfoTitleTextBox->SetSize(440, 40);
    serverInfoTitleTextBox->SetText("Pre-Driving", 440, 40, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    const auto serverJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "server.json";
    std::string preDriving = ReadJsonStringField(serverJsonPath.string(), "pre_driving");
    if (preDriving.empty())
        preDriving = "Safe driving reminder";

    serverInfoMessageTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoMessageTextBox->Init();
    serverInfoMessageTextBox->SetLocation(0, 80);
    serverInfoMessageTextBox->SetSize(440, 60);
    serverInfoMessageTextBox->SetText(preDriving, 440, 60, GUIEngine::Font::NotoSansJP_Regular_16, 0x000000);

    serverInfoShown = true;

    eng.CreateOneShotTimer(
        [this]()
        {
            HideServerInfoPopup();
            ShowMonthlyReportPopup();
        },
        4000);
}

void GUIHomeWindow::ShowMonthlyReportPopup()
{
    currentServerInfoStage = 2;
    auto &eng = GUIEngine::GetInstance();

    if (!serverInfoOverlay)
        serverInfoOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!serverInfoCard)
    {
        serverInfoCard = eng.CreateCardCentered(serverInfoOverlay, 440, 200, 0xFFFFFF, 8);
        eng.SetShadow(serverInfoCard, 0, 6, 20, 0.35f, 0x000000);
    }

    serverInfoTitleTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoTitleTextBox->Init();
    serverInfoTitleTextBox->SetLocation(0, 20);
    serverInfoTitleTextBox->SetSize(440, 40);
    serverInfoTitleTextBox->SetText("Monthly Report", 440, 40, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    const auto serverJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "server.json";
    std::string monthlyReport = ReadJsonStringField(serverJsonPath.string(), "monthly_report");
    if (monthlyReport.empty())
        monthlyReport = "Your monthly report is ready";

    serverInfoMessageTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoMessageTextBox->Init();
    serverInfoMessageTextBox->SetLocation(0, 80);
    serverInfoMessageTextBox->SetSize(440, 60);
    serverInfoMessageTextBox->SetText(monthlyReport, 440, 60, GUIEngine::Font::NotoSansJP_Regular_16, 0x000000);

    serverInfoButtonTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoButtonTextBox->Init();
    serverInfoButtonTextBox->SetLocation(140, 145);
    serverInfoButtonTextBox->SetSize(160, 35);
    serverInfoButtonTextBox->SetText("Confirm", 160, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    // Add button background
    auto btnBg = eng.CreateCardAbsolute(serverInfoCard, 160, 35, 140, 145, 0x0066CC, 4);
    eng.SendToBottom(btnBg);

    serverInfoShown = true;
}

void GUIHomeWindow::ShowNotificationPopup()
{
    currentServerInfoStage = 3;
    notificationButtonSelected = 0;
    auto &eng = GUIEngine::GetInstance();

    if (!serverInfoOverlay)
        serverInfoOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!serverInfoCard)
    {
        serverInfoCard = eng.CreateCardCentered(serverInfoOverlay, 440, 220, 0xFFFFFF, 8);
        eng.SetShadow(serverInfoCard, 0, 6, 20, 0.35f, 0x000000);
    }

    serverInfoTitleTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoTitleTextBox->Init();
    serverInfoTitleTextBox->SetLocation(0, 20);
    serverInfoTitleTextBox->SetSize(440, 40);
    serverInfoTitleTextBox->SetText("Notification", 440, 40, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    const auto serverJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "server.json";
    std::string notification = ReadJsonStringField(serverJsonPath.string(), "notification");
    if (notification.empty())
        notification = "You have new notifications";

    serverInfoMessageTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoMessageTextBox->Init();
    serverInfoMessageTextBox->SetLocation(0, 80);
    serverInfoMessageTextBox->SetSize(440, 60);
    serverInfoMessageTextBox->SetText(notification, 440, 60, GUIEngine::Font::NotoSansJP_Regular_16, 0x000000);

    // Detail button (selected)
    serverInfoButtonTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoButtonTextBox->Init();
    serverInfoButtonTextBox->SetLocation(90, 150);
    serverInfoButtonTextBox->SetSize(120, 35);
    serverInfoButtonTextBox->SetText("Detail", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    auto btnBg1 = eng.CreateCardAbsolute(serverInfoCard, 120, 35, 90, 150, 0x0066CC, 4);
    eng.SendToBottom(btnBg1);

    // Close button
    serverInfoButton2TextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoButton2TextBox->Init();
    serverInfoButton2TextBox->SetLocation(230, 150);
    serverInfoButton2TextBox->SetSize(120, 35);
    serverInfoButton2TextBox->SetText("Close", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0x666666);

    auto btnBg2 = eng.CreateCardAbsolute(serverInfoCard, 120, 35, 230, 150, 0xCCCCCC, 4);
    eng.SendToBottom(btnBg2);

    serverInfoShown = true;
}

void GUIHomeWindow::HideServerInfoPopup()
{
    if (!serverInfoShown)
        return;

    serverInfoShown = false;
    currentServerInfoStage = 0;

    serverInfoTitleTextBox.reset();
    serverInfoMessageTextBox.reset();
    serverInfoButtonTextBox.reset();
    serverInfoButton2TextBox.reset();

    if (serverInfoOverlay)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(serverInfoOverlay);
    }

    serverInfoOverlay = nullptr;
    serverInfoCard = nullptr;
}

void GUIHomeWindow::ShowNotificationDetail()
{
    const auto serverJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "server.json";
    std::string detailAvailable = ReadJsonStringField(serverJsonPath.string(), "notification_detail_available");

    HideServerInfoPopup();

    auto &eng = GUIEngine::GetInstance();
    serverInfoOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);
    serverInfoCard = eng.CreateCardCentered(serverInfoOverlay, 440, 200, 0xFFFFFF, 8);
    eng.SetShadow(serverInfoCard, 0, 6, 20, 0.35f, 0x000000);

    serverInfoTitleTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoTitleTextBox->Init();
    serverInfoTitleTextBox->SetLocation(0, 20);
    serverInfoTitleTextBox->SetSize(440, 40);

    if (detailAvailable == "yes")
    {
        serverInfoTitleTextBox->SetText("Detail Information", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
    }
    else
    {
        serverInfoTitleTextBox->SetText("Notification Acquisition Fail", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0xFF0000);
    }

    serverInfoMessageTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoMessageTextBox->Init();
    serverInfoMessageTextBox->SetLocation(0, 80);
    serverInfoMessageTextBox->SetSize(440, 60);
    serverInfoMessageTextBox->SetText(detailAvailable == "yes" ? "Your notification details..." : "Failed to retrieve details", 440, 60, GUIEngine::Font::NotoSansJP_Regular_16, 0x000000);

    serverInfoButtonTextBox = std::make_unique<TextBox>(serverInfoCard);
    serverInfoButtonTextBox->Init();
    serverInfoButtonTextBox->SetLocation(140, 145);
    serverInfoButtonTextBox->SetSize(160, 35);
    serverInfoButtonTextBox->SetText("Confirm", 160, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    // Add button background
    auto btnBg = eng.CreateCardAbsolute(serverInfoCard, 160, 35, 140, 145, 0x0066CC, 4);
    eng.SendToBottom(btnBg);

    serverInfoShown = true;
    currentServerInfoStage = 4;
}

void GUIHomeWindow::ShowAccidentPopup(const std::string &title, const std::string &message)
{
    std::cout << "ShowAccidentPopup called - title: '" << title << "', message: '" << message << "'" << std::endl;

    if (accidentPopupShown)
    {
        std::cout << "Accident popup already shown, skipping" << std::endl;
        return;
    }

    accidentPopupShown = true;
    std::cout << "Creating accident popup overlay and card" << std::endl;

    auto &eng = GUIEngine::GetInstance();
    if (!accidentOverlay)
        accidentOverlay = eng.CreateRectangleAbsoluteTransparent(scr, 640, 360, 0, 0);

    if (!accidentCard)
    {
        accidentCard = eng.CreateCardCentered(accidentOverlay, 440, 200, 0xFFFFFF, 8);
        eng.SetShadow(accidentCard, 0, 6, 20, 0.35f, 0x000000);
    }

    std::cout << "Creating accident popup text elements" << std::endl;

    accidentTitleTextBox = std::make_unique<TextBox>(accidentCard);
    accidentTitleTextBox->Init();
    accidentTitleTextBox->SetLocation(0, 20);
    accidentTitleTextBox->SetSize(440, 40);
    accidentTitleTextBox->SetText(title, 440, 40, GUIEngine::Font::NotoSansJP_Regular_28, 0xFF0000);

    accidentMessageTextBox = std::make_unique<TextBox>(accidentCard);
    accidentMessageTextBox->Init();
    accidentMessageTextBox->SetLocation(0, 80);
    accidentMessageTextBox->SetSize(440, 60);
    accidentMessageTextBox->SetText(message, 440, 60, GUIEngine::Font::NotoSansJP_Regular_16, 0x000000);

    accidentButtonTextBox = std::make_unique<TextBox>(accidentCard);
    accidentButtonTextBox->Init();
    accidentButtonTextBox->SetLocation(140, 145);
    accidentButtonTextBox->SetSize(160, 35);
    accidentButtonTextBox->SetText("Confirm", 160, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    // Add button background
    auto btnBg = eng.CreateCardAbsolute(accidentCard, 160, 35, 140, 145, 0x0066CC, 4);
    eng.SendToBottom(btnBg);

    std::cout << "Accident popup created successfully" << std::endl;
}

void GUIHomeWindow::HideAccidentPopup()
{
    if (!accidentPopupShown)
        return;

    std::cout << "Accident popup: hiding" << std::endl;

    accidentPopupShown = false;
    accidentTitleTextBox.reset();
    accidentMessageTextBox.reset();
    accidentButtonTextBox.reset();

    if (accidentOverlay)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(accidentOverlay);
    }

    accidentOverlay = nullptr;
    accidentCard = nullptr;
}

void GUIHomeWindow::onShockDetected()
{
    std::cout << "GUIHomeWindow::onShockDetected() called" << std::endl;

    const auto accidentJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "accident.json";
    std::cout << "Reading accident.json from: " << accidentJsonPath.string() << std::endl;

    std::string shouldShow = ReadJsonStringField(accidentJsonPath.string(), "shock_detected");
    std::cout << "shock_detected value: '" << shouldShow << "'" << std::endl;

    if (shouldShow == "yes")
    {
        std::cout << "Showing shock detection popup" << std::endl;
        ShowAccidentPopup("Shock Detection", "Shock detected! Please check vehicle status.");
    }
    else
    {
        std::cout << "Shock detection popup disabled (value is not 'yes')" << std::endl;
    }
}

void GUIHomeWindow::onMotionDetected()
{
    std::cout << "GUIHomeWindow::onMotionDetected() called" << std::endl;

    const auto accidentJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "accident.json";
    std::cout << "Reading accident.json from: " << accidentJsonPath.string() << std::endl;

    std::string shouldShow = ReadJsonStringField(accidentJsonPath.string(), "motion_detected");
    std::cout << "motion_detected value: '" << shouldShow << "'" << std::endl;

    if (shouldShow == "yes")
    {
        std::cout << "Showing motion detection popup" << std::endl;
        ShowAccidentPopup("Motion Detection", "Motion detected while parked!");
    }
    else
    {
        std::cout << "Motion detection popup disabled (value is not 'yes')" << std::endl;
    }
}

void GUIHomeWindow::onUnauthorizedAccess()
{
    std::cout << "GUIHomeWindow::onUnauthorizedAccess() called" << std::endl;

    const auto accidentJsonPath = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf" / "accident.json";
    std::cout << "Reading accident.json from: " << accidentJsonPath.string() << std::endl;

    std::string shouldShow = ReadJsonStringField(accidentJsonPath.string(), "unauthorized_access");
    std::cout << "unauthorized_access value: '" << shouldShow << "'" << std::endl;

    if (shouldShow == "yes")
    {
        std::cout << "Showing unauthorized access popup" << std::endl;
        ShowAccidentPopup("Unauthorized Access", "Unauthorized access detected!");
    }
    else
    {
        std::cout << "Unauthorized access popup disabled (value is not 'yes')" << std::endl;
    }
}

void GUIHomeWindow::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    std::cout << "GUIHomeWindow::onKey - currentServerInfoStage=" << currentServerInfoStage
              << ", key=" << (int)key << ", press=" << (int)press << std::endl;

    if (currentServerInfoStage == 2 && key == Key::MENU_OK && press == PressType::Short)
    {
        // Monthly Report - Confirm button
        std::cout << "Monthly Report: MENU_OK clicked, hiding and showing notification" << std::endl;
        auto &eng = GUIEngine::GetInstance();
        eng.CreateOneShotTimer(
            [this]()
            {
                HideServerInfoPopup();
                ShowNotificationPopup();
            },
            0);
    }
    else if (currentServerInfoStage == 3)
    {
        // Notification popup with Detail/Close buttons
        if (key == Key::UP && press == PressType::Short)
        {
            notificationButtonSelected = 0; // Select Detail
            if (serverInfoButtonTextBox)
                serverInfoButtonTextBox->SetText("Detail", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
            if (serverInfoButton2TextBox)
                serverInfoButton2TextBox->SetText("Close", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0x666666);
        }
        else if (key == Key::DOWN && press == PressType::Short)
        {
            notificationButtonSelected = 1; // Select Close
            if (serverInfoButtonTextBox)
                serverInfoButtonTextBox->SetText("Detail", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0x666666);
            if (serverInfoButton2TextBox)
                serverInfoButton2TextBox->SetText("Close", 120, 35, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        }
        else if (key == Key::MENU_OK && press == PressType::Short)
        {
            auto &eng = GUIEngine::GetInstance();
            if (notificationButtonSelected == 0)
            {
                // Detail button
                eng.CreateOneShotTimer(
                    [this]()
                    {
                        ShowNotificationDetail();
                    },
                    0);
            }
            else
            {
                // Close button
                eng.CreateOneShotTimer(
                    [this]()
                    {
                        HideServerInfoPopup();
                    },
                    0);
            }
        }
    }
    else if (currentServerInfoStage == 4 && key == Key::MENU_OK && press == PressType::Short)
    {
        // Notification detail - Confirm button to close and return to main screen
        auto &eng = GUIEngine::GetInstance();
        eng.CreateOneShotTimer(
            [this]()
            {
                HideServerInfoPopup();
            },
            0);
    }
    else if (accidentPopupShown && key == Key::MENU_OK && press == PressType::Short)
    {
        // Accident popup - Confirm button to close
        auto &eng = GUIEngine::GetInstance();
        eng.CreateOneShotTimer(
            [this]()
            {
                HideAccidentPopup();
            },
            0);
    }
}

void GUIHomeWindow::SetMicOnOff(bool on)
{
    if (on)
    {
        SetMicOnOffImage(LV_SYMBOL_AUDIO);
    }
    else
    {
        SetMicOnOffImage(LV_SYMBOL_MUTE);
    }
}
void GUIHomeWindow::Set4GSignalStrength(int strength)
{
    if (network4G)
    {
        network4G->SetSignalStrength(strength);
    }
}