#include "GUIBootupWindow.h"
#include "GUIEngine.h"
#include "GUIEventDispatcher.h"
#include "TextBox.h"

GUIBootupWindow::GUIBootupWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIBootupWindow::~GUIBootupWindow()
{
}

void GUIBootupWindow::Init()
{
    GUIWindowLayoutBase::Init();

    auto &eng = GUIEngine::GetInstance();

    // Set black background
    eng.SetScreenColor(scr, 0x000000);

    // Hide default buttons during bootup
    if (upButton)
        eng.HideObject(upButton->obj);
    if (menuOkButton)
        eng.HideObject(menuOkButton->obj);
    if (downButton)
        eng.HideObject(downButton->obj);
    if (micOnOffButton)
        eng.HideObject(micOnOffButton->obj);

    // Main text (centered) - reused for all stages
    mainTextBox = std::make_unique<TextBox>(scr);
    mainTextBox->Init();
    mainTextBox->SetLocation(0, 120);
    mainTextBox->SetSize(640, 80);
    mainTextBox->SetText("THE COMPANY", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
    mainTextBox->Hide();

    // Sub text (centered below main) - optional for stages that need it
    subTextBox = std::make_unique<TextBox>(scr);
    subTextBox->Init();
    subTextBox->SetLocation(0, 200);
    subTextBox->SetSize(640, 40);
    subTextBox->SetText("Starting...", 640, 40, GUIEngine::Font::NotoSansJP_Regular_16, 0xCCCCCC);
    subTextBox->Hide();
}

// ============= EVENT HANDLERS =============

void GUIBootupWindow::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    // Only handle MENU/OK on RIGHT display for setup prompt
    if (key == Key::MENU_OK && press == PressType::Short)
    {
        if (GUIEventDispatcher::GetInstance().ConsumeRightMenuOkClicked())
        {
            // User confirmed setup prompt - Manager will handle this through CompleteBootup
            std::cout << "Setup prompt confirmed via RIGHT MENU/OK" << std::endl;
        }
    }
}
