#include "GUIBootupManager.h"
#include "GUIEngine.h"
#include "GUIEventDispatcher.h"
#include "TextBox.h"
#include <filesystem>
#include <fstream>

GUIBootupManager::GUIBootupManager() : state(State::BOOTUP)
{
    std::cout << "GUIBootupManager constructor called" << std::endl;
    Init();
    std::cout << "GUIBootupManager initialized, windows count: " << windows.size() << std::endl;
}

GUIBootupManager::~GUIBootupManager()
{
}

std::string GUIBootupManager::GetStateName() const
{
    switch (state)
    {
    case State::BOOTUP:
        return "BOOTUP";
    default:
        return "UNKNOWN";
    }
}

void GUIBootupManager::Init()
{
    // Create directly (factory registration may not include Bootup yet).
    windows.push_back(std::make_unique<GUIBootupWindow>());
}

void GUIBootupManager::ShowCurrentWindow()
{
    std::cout << "GUIBootupManager::ShowCurrentWindow() called" << std::endl;

    if (windows.empty())
    {
        Init();
    }

    // IMPORTANT: actually load the window's screen first.
    GUIWindowManagerBase::ShowCurrentWindow();

    StartBootSequence();
}

void GUIBootupManager::StartBootSequence()
{
    std::cout << "GUIBootupManager::StartBootSequence() called" << std::endl;

    if (bootupTimer)
    {
        std::cout << "Bootup timer already active, skipping re-start" << std::endl;
        return;
    }

    isFirstBoot = IsFirstBoot();
    std::cout << "Boot mode: " << (isFirstBoot ? "FIRST" : "SUBSEQUENT") << " boot" << std::endl;

    Stage0_ShowImage();
}

void GUIBootupManager::Stage0_ShowImage()
{
    std::cout << "Stage 0: Showing image" << std::endl;
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Hide text elements
    if (current->mainTextBox)
        current->mainTextBox->Hide();
    if (current->subTextBox)
        current->subTextBox->Hide();

    // Create and display image
    if (!current->imageObj)
    {
        auto &eng = GUIEngine::GetInstance();
        current->imageObj = eng.CreateImageCentered(current->scr, "C:/BienTH/00.Learning/17.LVGL/1.Coding/the-company/src/gui/src/pf/aaa.png");
    }

    current->imageShown = true;

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]() { Stage1_ShowCompanyName(); }, 3000);
}

void GUIBootupManager::Stage1_ShowCompanyName()
{
    std::cout << "Stage 1: Showing company name" << std::endl;
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Hide image
    if (current->imageObj)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(current->imageObj);
        current->imageObj = nullptr;
    }

    // Show company name and status
    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("THE COMPANY", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
        current->mainTextBox->Show();
    }
    if (current->subTextBox)
    {
        current->subTextBox->SetText("Starting...", 640, 40, GUIEngine::Font::NotoSansJP_Regular_16, 0xCCCCCC);
        current->subTextBox->Show();
    }

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]() { Stage2_ShowWarning(); }, 4000);
}

void GUIBootupManager::Stage2_ShowWarning()
{
    std::cout << "Stage 2: Showing warning" << std::endl;
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Hide sub text
    if (current->subTextBox)
        current->subTextBox->Hide();

    // Update main text to Warning
    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("Warning", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
        current->mainTextBox->Show();
    }

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]() { Stage3_CheckFeetMode(); }, 4000);
}

void GUIBootupManager::Stage3_CheckFeetMode()
{
    std::cout << "Stage 3: Checking FEET mode" << std::endl;

    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto userJsonPath = configDir / "user.json";

    std::string newMode = ReadJsonStringField(userJsonPath.string(), "mode");
    if (newMode.empty())
    {
        std::cout << "user.json not found or mode field missing, skipping FEET check, going to home" << std::endl;
        Stage4_CheckContract();
        return;
    }

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Show FEET mode check screen
    if (current->subTextBox)
        current->subTextBox->Hide();

    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("Checking FEET Mode...", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        current->mainTextBox->Show();
    }

    const auto currentModeJsonPath = configDir / "current_mode.json";
    std::string currentMode = ReadJsonStringField(currentModeJsonPath.string(), "mode");

    if (currentMode.empty())
    {
        std::cout << "No current mode found, saving new mode: " << newMode << std::endl;
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (current->mainTextBox)
            current->mainTextBox->SetText(("Mode: " + newMode).c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    }
    else if (currentMode != newMode)
    {
        std::cout << "Mode changed from '" << currentMode << "' to '" << newMode << "', restarting..." << std::endl;
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (current->mainTextBox)
            current->mainTextBox->SetText(("Changing to: " + newMode + "\nRestarting...").c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFF00);

        RestartBootSequence(current);
        return;
    }
    else
    {
        std::cout << "Mode unchanged: " << currentMode << std::endl;
        if (current->mainTextBox)
            current->mainTextBox->SetText(("Mode: " + currentMode + " (OK)").c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    }

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]() { Stage4_CheckContract(); }, 3000);
}

void GUIBootupManager::Stage4_CheckContract()
{
    std::cout << "Stage 4: Checking contract" << std::endl;

    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto serverJsonPath = configDir / "server.json";

    std::string contractDate = ReadJsonStringField(serverJsonPath.string(), "contract_date");
    if (contractDate.empty())
    {
        std::cout << "server.json not found or contract_date field missing, skipping contract check, going to home" << std::endl;
        Stage5_SetupOrHome();
        return;
    }

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Show contract check screen
    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("Validating Contract...", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
        current->mainTextBox->Show();
    }

    // Update with contract date
    if (current->mainTextBox)
        current->mainTextBox->SetText(("Contract: " + contractDate).c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]() { Stage5_SetupOrHome(); }, 3000);
}

void GUIBootupManager::Stage5_SetupOrHome()
{
    std::cout << "Stage 5: Setup or Home" << std::endl;

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    if (isFirstBoot)
    {
        std::cout << "First boot: showing setup prompt" << std::endl;
        if (current->mainTextBox)
        {
            current->mainTextBox->SetText("Enter the setup?\nPress MENU/OK on RIGHT", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
            current->mainTextBox->Show();
        }
        bootupTimer = nullptr;
    }
    else
    {
        std::cout << "Subsequent boot: going to home" << std::endl;
        bootupTimer = nullptr;
        CompleteBootup();
    }
}

void GUIBootupManager::CompleteBootup()
{
    std::cout << "CompleteBootup() called" << std::endl;

    MarkFirstBootDone();

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Show system update popup
    if (current->systemUpdatePopupShown)
        return;

    current->systemUpdatePopupShown = true;

    auto &eng = GUIEngine::GetInstance();

    if (!current->systemUpdateOverlay)
        current->systemUpdateOverlay = eng.CreateRectangleAbsoluteTransparent(current->scr, 640, 360, 0, 0);

    if (!current->systemUpdateCard)
    {
        current->systemUpdateCard = eng.CreateCardCentered(current->systemUpdateOverlay, 440, 170, 0xFFFFFF, 8);
        eng.SetShadow(current->systemUpdateCard, 0, 6, 20, 0.35f, 0x000000);
    }

    current->systemUpdateTitleTextBox = std::make_unique<TextBox>(current->systemUpdateCard);
    current->systemUpdateTitleTextBox->Init();
    current->systemUpdateTitleTextBox->SetLocation(0, 22);
    current->systemUpdateTitleTextBox->SetSize(440, 50);
    current->systemUpdateTitleTextBox->SetText("System Update", 440, 50, GUIEngine::Font::NotoSansJP_Regular_28, 0x000000);

    current->systemUpdateCountdownTextBox = std::make_unique<TextBox>(current->systemUpdateCard);
    current->systemUpdateCountdownTextBox->Init();
    current->systemUpdateCountdownTextBox->SetLocation(0, 92);
    current->systemUpdateCountdownTextBox->SetSize(440, 40);
    current->systemUpdateCountdownTextBox->SetText("Hide in 4s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);

    // Countdown updates
    eng.CreateOneShotTimer(
        [current]()
        {
            if (current->systemUpdateCountdownTextBox)
                current->systemUpdateCountdownTextBox->SetText("Hide in 3s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        1000);

    eng.CreateOneShotTimer(
        [current]()
        {
            if (current->systemUpdateCountdownTextBox)
                current->systemUpdateCountdownTextBox->SetText("Hide in 2s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        2000);

    eng.CreateOneShotTimer(
        [current]()
        {
            if (current->systemUpdateCountdownTextBox)
                current->systemUpdateCountdownTextBox->SetText("Hide in 1s", 440, 40, GUIEngine::Font::NotoSansJP_Regular_24, 0x000000);
        },
        3000);

    eng.CreateOneShotTimer(
        [this, current]()
        {
            HideSystemUpdatePopup(current);
            GUIEventDispatcher::GetInstance().onSetupRequested();
        },
        4000);
}

void GUIBootupManager::HideSystemUpdatePopup(GUIBootupWindow *current)
{
    if (!current || !current->systemUpdatePopupShown)
        return;

    current->systemUpdatePopupShown = false;

    current->systemUpdateTitleTextBox.reset();
    current->systemUpdateCountdownTextBox.reset();

    if (current->systemUpdateOverlay)
    {
        auto &eng = GUIEngine::GetInstance();
        eng.DeleteObject(current->systemUpdateOverlay);
    }

    current->systemUpdateOverlay = nullptr;
    current->systemUpdateCard = nullptr;
}

void GUIBootupManager::RestartBootSequence(GUIBootupWindow *current)
{
    std::cout << "=== RESTARTING BOOT SEQUENCE ===" << std::endl;
    auto &eng = GUIEngine::GetInstance();
    eng.CreateOneShotTimer(
        [this, current]()
        {
            if (current)
            {
                // Reset all stages
                current->imageShown = false;
                current->systemUpdatePopupShown = false;

                if (current->imageObj)
                {
                    auto &eng = GUIEngine::GetInstance();
                    eng.DeleteObject(current->imageObj);
                    current->imageObj = nullptr;
                }

                if (current->mainTextBox)
                    current->mainTextBox->Hide();
                if (current->subTextBox)
                    current->subTextBox->Hide();
            }

            bootupTimer = nullptr;
            StartBootSequence();
        },
        2000);
}

bool GUIBootupManager::IsFirstBoot() const
{
    try
    {
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        const auto marker = markerDir / "first_boot_done.json";
        return !std::filesystem::exists(marker);
    }
    catch (...)
    {
        return true;
    }
}

void GUIBootupManager::MarkFirstBootDone()
{
    try
    {
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        std::filesystem::create_directories(markerDir);
        const auto marker = markerDir / "first_boot_done.json";

        std::cout << "Writing first-boot marker to: " << marker.string() << std::endl;

        std::ofstream out(marker.string(), std::ios::out | std::ios::trunc);
        if (out.is_open())
        {
            out << "{\n  \"first_boot_done\": true\n}\n";
            out.close();
            std::cout << "Successfully wrote first_boot_done: true" << std::endl;
        }
    }
    catch (const std::exception &e)
    {
        std::cout << "ERROR in MarkFirstBootDone: " << e.what() << std::endl;
    }
}

std::string GUIBootupManager::ReadJsonStringField(const std::string &filePath, const std::string &fieldName)
{
    try
    {
        std::ifstream file(filePath);
        if (!file.is_open())
            return "";

        std::string line;
        while (std::getline(file, line))
        {
            size_t pos = line.find("\"" + fieldName + "\"");
            if (pos != std::string::npos)
            {
                size_t colonPos = line.find(":", pos);
                if (colonPos != std::string::npos)
                {
                    size_t firstQuote = line.find("\"", colonPos);
                    if (firstQuote != std::string::npos)
                    {
                        size_t secondQuote = line.find("\"", firstQuote + 1);
                        if (secondQuote != std::string::npos)
                        {
                            return line.substr(firstQuote + 1, secondQuote - firstQuote - 1);
                        }
                    }
                }
            }
        }
        return "";
    }
    catch (...)
    {
        return "";
    }
}

void GUIBootupManager::onKey(Key key, PressType press, KeyActionContext &ctx)
{
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (current)
    {
        current->onKey(key, press, ctx);
    }
}
