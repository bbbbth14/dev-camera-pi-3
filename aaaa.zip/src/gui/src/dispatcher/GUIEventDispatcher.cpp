#include "GUIEventDispatcher.h"

GUIEventDispatcher::GUIEventDispatcher()
{
    std::wcout << "GUIEventDispatcher created.\n";

    Init();
}

GUIEventDispatcher::~GUIEventDispatcher()
{
}
GUIEventDispatcher &GUIEventDispatcher::GetInstance()
{
    static GUIEventDispatcher instance;
    return instance;
}

void GUIEventDispatcher::Init()
{
    std::cout << "GUIEventDispatcher::Init() - Adding GUIBootupManager" << std::endl;
    AddManager(GUIBootupManager::Id);
    std::cout << "GUIEventDispatcher::Init() completed, manager count: " << managers.size() << std::endl;
}

void GUIEventDispatcher::AddManager(std::string name)
{
    std::cout << "AddManager called with: '" << name << "'" << std::endl;
    std::unique_ptr<GUIWindowManagerBase> manager = nullptr;

    if (name == GUIBootupManager::Id)
    {
        std::cout << "Creating GUIBootupManager (Id: '" << GUIBootupManager::Id << "')" << std::endl;
        manager = std::make_unique<GUIBootupManager>();
    }
    else if (name == GUIHomeManager::Id)
    {
        std::cout << "Creating GUIHomeManager" << std::endl;
        // Tạo MenuManager
        manager = std::make_unique<GUIHomeManager>();
    }
    else if (name == GUIMenuManager::Id)
    {
        // Tạo MenuManager
        manager = std::make_unique<GUIMenuManager>();
    }
    else
    {
        std::cout << "Unknown manager name: '" << name << "'" << std::endl;
    }

    if (manager)
    {
        std::cout << "Manager created, adding to managers vector" << std::endl;
        managers.push_back(std::move(manager));
        std::cout << "Calling GetCurrentManager()->ShowCurrentWindow()" << std::endl;
        GetCurrentManager()->ShowCurrentWindow();
        std::cout << "ShowCurrentWindow() completed" << std::endl;
    }
    else
    {
        std::cout << "Failed to create manager!" << std::endl;
    }
}

GUIWindowManagerBase *GUIEventDispatcher::GetCurrentManager()
{
    return managers.back().get();
}

void GUIEventDispatcher::BackToPreviousManager()
{
    if (managers.size() > 1)
    {
        // Xóa controller hiện tại
        managers.pop_back();

        // Lấy controller trước đó
        GUIWindowManagerBase *current = GetCurrentManager();

        // Hiển thị màn hình của controller trước đó
        current->ShowCurrentWindow();
    }
    else
    {
    }
}

void GUIEventDispatcher::onKey(GUIWindowManagerBase::Key key, GUIWindowManagerBase::PressType press)
{
    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        GUIWindowManagerBase::KeyActionContext ctx;
        // Gọi hàm để lấy thông tin
        current->onKey(key, press, ctx);

        // Kiểm tra điều kiện
        if (ctx.doCreateNewManager && !ctx.newManagerName.empty())
        {
            AddManager(ctx.newManagerName);
        }
        else if (ctx.doBackToPreviousManager)
        {
            BackToPreviousManager();
        }
    }
}

void GUIEventDispatcher::onUPKeyShortPressed()
{
    onKey(GUIWindowManagerBase::Key::UP, GUIWindowManagerBase::PressType::Short);
}

void GUIEventDispatcher::onMENU_OKKeyShortPressed()
{
    onKey(GUIWindowManagerBase::Key::MENU_OK, GUIWindowManagerBase::PressType::Short);
}

void GUIEventDispatcher::onDOWNKeyShortPressed()
{
    onKey(GUIWindowManagerBase::Key::DOWN, GUIWindowManagerBase::PressType::Short);
}
void GUIEventDispatcher::onMIC_ON_OFFKeyShortPressed()
{
    onKey(GUIWindowManagerBase::Key::MIC_ON_OFF, GUIWindowManagerBase::PressType::Short);
}
void GUIEventDispatcher::onEmergency_CallKeyShortPressed()
{
    onKey(GUIWindowManagerBase::Key::Emergency_Call, GUIWindowManagerBase::PressType::Short);
}

void GUIEventDispatcher::onMotionDetected()
{
    std::cout << "GUIEventDispatcher::onMotionDetected() called" << std::endl;

    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        std::cout << "Calling current manager's onMotionDetected()" << std::endl;
        current->onMotionDetected();
    }
    else
    {
        std::cout << "Warning: current manager is null" << std::endl;
    }
}
void GUIEventDispatcher::onShockDetected()
{
    std::cout << "GUIEventDispatcher::onShockDetected() called" << std::endl;

    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        std::cout << "Calling current manager's onShockDetected()" << std::endl;
        current->onShockDetected();
    }
    else
    {
        std::cout << "Warning: current manager is null" << std::endl;
    }

    GUINotificationManager &noti = GUINotificationManager::GetInstance();
    noti.onShockDetected();
}
void GUIEventDispatcher::onLongDrivingAttention()
{
    onMotionDetected();

    GUINotificationManager &noti = GUINotificationManager::GetInstance();
    noti.onLongDrivingAttention();
}

void GUIEventDispatcher::onVehicleSpeedChanged(float vehicleSpeed)
{
    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        GUIWindowManagerBase::KeyActionContext ctx;
        // Gọi hàm để lấy thông tin
        current->onVehicleSpeedChanged(vehicleSpeed, ctx);

        // Kiểm tra điều kiện
        if (ctx.doCreateNewManager && !ctx.newManagerName.empty())
        {
            AddManager(ctx.newManagerName);
        }
        else if (ctx.doBackToPreviousManager)
        {
            BackToPreviousManager();
        }
    }
}
void GUIEventDispatcher::on4GSignalStrengthChanged(int strength)
{
    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        // Gọi hàm để lấy thông tin
        current->on4GSignalStrengthChanged(strength);
    }
}
void GUIEventDispatcher::onBootupComplete()
{
    // Navigate to home screen after bootup
    std::cout << "Bootup complete, navigating to home screen" << std::endl;
    AddManager(GUIHomeManager::Id);
}

void GUIEventDispatcher::onSetupRequested()
{
    // Setup is not implemented yet. For now, route to main/home.
    std::cout << "Setup requested (not implemented), navigating to home/main" << std::endl;
    AddManager(GUIHomeManager::Id);
}

void GUIEventDispatcher::NotifyRightMenuOkClicked()
{
    rightMenuOkClicked = true;
}

bool GUIEventDispatcher::ConsumeRightMenuOkClicked()
{
    const bool wasClicked = rightMenuOkClicked;
    rightMenuOkClicked = false;
    return wasClicked;
}

void GUIEventDispatcher::NotifyShowDrivingAdviceOnNextHome()
{
    showDrivingAdviceOnNextHome = true;
}

bool GUIEventDispatcher::ConsumeShowDrivingAdviceOnNextHome()
{
    const bool shouldShow = showDrivingAdviceOnNextHome;
    showDrivingAdviceOnNextHome = false;
    return shouldShow;
}
