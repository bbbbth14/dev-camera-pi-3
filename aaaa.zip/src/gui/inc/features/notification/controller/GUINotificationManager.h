#pragma once

#ifndef GUINOTIFICATIONMANAGER_H
#define GUINOTIFICATIONMANAGER_H

#include <string>
#include <future>

#include "GUIEngine.h"

#include "GUIEventBase.h"
#include "GUIPopupBase.h"
#include "GUIPopupFactory.h"

#include "GUIEventPopup.h"

class GUINotificationManager : GUIEventBase
{
private:
    std::unique_ptr<GUIPopupBase> popup;

public:
    GUINotificationManager();
    ~GUINotificationManager();
    static GUINotificationManager &GetInstance();

    GUIPopupBase *GetCurrentPopup();
    void SetCurrentPopup(std::string name);

    void ShowPopupWithAutoClose(GUIEventPopup::DrivingAlert alertType);
    void CloseCurrentPopup();

    void onShockDetected() override;
    void onLongDrivingAttention() override;
};

#endif // GUINOTIFICATIONMANAGER_H