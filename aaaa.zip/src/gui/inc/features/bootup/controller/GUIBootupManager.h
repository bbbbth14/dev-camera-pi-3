#pragma once

#ifndef GUIBOOTUPMANAGER_H
#define GUIBOOTUPMANAGER_H

#include "GUIWindowManagerBase.h"
#include "GUIBootupWindow.h"

class GUIBootupManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        BOOTUP,
    };
    State state;

public:
    inline static const std::string Id = "GUIBootupManager";

    GUIBootupManager();
    ~GUIBootupManager();

    std::string GetStateName() const override;
    void Init() override;
    void ShowCurrentWindow() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;

    // Boot sequence logic
    void StartBootSequence();
    void CompleteBootup();

private:
    bool isFirstBoot = true;
    lv_timer_t *bootupTimer = nullptr;

    void Stage0_ShowImage();
    void Stage1_ShowCompanyName();
    void Stage2_ShowWarning();
    void Stage3_CheckFeetMode();
    void Stage4_CheckContract();
    void Stage5_SetupOrHome();

    void HideSystemUpdatePopup(GUIBootupWindow *current);
    void RestartBootSequence(GUIBootupWindow *current);

    // Helper methods
    bool IsFirstBoot() const;
    void MarkFirstBootDone();
    std::string ReadJsonStringField(const std::string &filename, const std::string &field);
};

#endif
