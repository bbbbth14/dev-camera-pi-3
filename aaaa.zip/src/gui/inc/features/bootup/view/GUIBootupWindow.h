#pragma once

#ifndef GUIBOOTUPWINDOW_H
#define GUIBOOTUPWINDOW_H

#include <lvgl.h>
#include "GUIWindowLayoutBase.h"

class TextBox;

class GUIBootupWindow : public GUIWindowLayoutBase
{
public:
    // UI elements - accessible by Manager
    lv_obj_t *imageObj = nullptr;
    std::unique_ptr<TextBox> mainTextBox = nullptr;
    std::unique_ptr<TextBox> subTextBox = nullptr;

    lv_obj_t *systemUpdateOverlay = nullptr;
    lv_obj_t *systemUpdateCard = nullptr;
    std::unique_ptr<TextBox> systemUpdateTitleTextBox = nullptr;
    std::unique_ptr<TextBox> systemUpdateCountdownTextBox = nullptr;
    bool systemUpdatePopupShown = false;

    bool isFirstBoot = true;
    bool imageShown = false;

public:
    GUIBootupWindow();
    ~GUIBootupWindow();
    inline static const std::string Id = "SCS-00-1000";
    void Init() override;

    void onKey(Key key, PressType press, KeyActionContext &ctx) override;

    friend class GUIBootupManager;
};

#endif // GUIBOOTUPWINDOW_H
