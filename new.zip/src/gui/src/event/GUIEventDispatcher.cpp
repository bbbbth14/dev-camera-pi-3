#include "GUIEventDispatcher.h"

GUIEventDispatcher::GUIEventDispatcher()
{
    std::wcout << "GUIEventDispatcher created.\n";

    Init();
}

GUIEventDispatcher::~GUIEventDispatcher()
{
}
GUIEventDispatcher &GUIEventDispatcher::GetInstance()
{
    static GUIEventDispatcher instance;
    return instance;
}

void GUIEventDispatcher::Init()
{
    // Start with Home for debugging (skip bootup)
    // AddManager(GUIHomeManager::Id);
    AddManager(GUIBootupManager::Id); // Bootup disabled for debugging
}

void GUIEventDispatcher::AddManager(std::string name)
{
    std::cout << "AddManager called with name: " << name << std::endl;
    std::unique_ptr<GUIWindowManagerBase> manager = nullptr;

    if (name == GUIBootupManager::Id)
    {
        std::cout << "  Creating GUIBootupManager" << std::endl;
        // Tạo BootupManager
        manager = std::make_unique<GUIBootupManager>();
    }
    else if (name == GUIHomeManager::Id)
    {
        std::cout << "  Creating GUIHomeManager" << std::endl;
        // Tạo HomeManager
        manager = std::make_unique<GUIHomeManager>();
    }
    else if (name == GUIMenuManager::Id)
    {
        std::cout << "  Creating GUIMenuManager" << std::endl;
        // Tạo MenuManager
        manager = std::make_unique<GUIMenuManager>();
    }
    else if (name == GUIMenuInquiriesGroupManager::Id)
    {
        manager = std::make_unique<GUIMenuInquiriesGroupManager>();
    }
    else if (name == GUIMenuInquiriesIndexManager::IdConstNoti)
    {
        manager = std::make_unique<GUIMenuInquiriesIndexManager>(GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_NOTIFICATION);
    }
    else if (name == GUIMenuInquiriesIndexManager::IdConstContact)
    {
        manager = std::make_unique<GUIMenuInquiriesIndexManager>(GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_CONTACT);
    }
    else if (name == GUIMenuInquiriesIndexManager::IdNotificationDetail)
    {
        GUIMenuInquiriesIndexWindow *current = (GUIMenuInquiriesIndexWindow *)GetCurrentManager()->GetCurrentWindow();
        int activeIndex = current->GetActiveIndex();
        std::cout << "  Creating notification detail view with index: " << activeIndex << std::endl;
        // Notification details fetched from server via GUIActionHandler
        manager = std::make_unique<GUIMenuInquiriesIndexManager>(
            GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_NOTIFICATION, activeIndex);
    }
    else if (name == GUIMenuInquiriesIndexManager::IdContactDetail)
    {
        std::cout << "  Creating contact detail view" << std::endl;
        // Contact info just displayed (static data)
        manager = std::make_unique<GUIMenuInquiriesIndexManager>(
            GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_CONTACT, 0);
    }
    // else if (name == GUIMenuInquiriesIndexManager::IdEventImg)
    // {
    //     manager = std::make_unique<GUIMenuInquiriesIndexManager>(GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_EVENT_IMAGE);
    // }
    else
    {
    }

    if (manager)
    {
        managers.push_back(std::move(manager));

        GetCurrentManager()->ShowCurrentWindow();
    }
}

GUIWindowManagerBase *GUIEventDispatcher::GetCurrentManager()
{
    if (managers.empty())
    {
        std::cout << "GetCurrentManager: No managers exist!" << std::endl;
        return nullptr;
    }

    std::cout << "GetCurrentManager: Returning manager at index " << (managers.size() - 1)
              << " (ID: " << managers.back()->GetId() << ")" << std::endl;
    return managers.back().get();
}

void GUIEventDispatcher::BackToManager(int id)
{
    if (managers.empty())
    {
        // Không có manager nào
        return;
    }

    const int currentIdx = managers.size() - 1;

    if (id == currentIdx)
    {
        // Đang ở đúng manager cần về; chỉ cần refresh (nếu muốn)
        if (auto *current = GetCurrentManager())
        {
            current->ShowCurrentWindow();

            ProcessPendingEvent();
        }
        return;
    }

    if (id > currentIdx)
    {
        // target lớn hơn index hiện tại là không hợp lệ
        // (do managers là "stack", không thể tiến tới tương lai bằng back)
        return;
    }

    // Pop các manager phía trên cho tới khi đạt targetIdx
    const int numToPop = currentIdx - id;
    for (int i = 0; i < numToPop; ++i)
    {
        managers.pop_back();
    }

    // Hiển thị window của manager hiện tại sau khi back
    if (auto *current = GetCurrentManager())
    {
        current->ShowCurrentWindow();

        ProcessPendingEvent();
    }
}

void GUIEventDispatcher::BackToPreviousManager()
{
    if (managers.size() > 1)
    {
        // Xóa controller hiện tại
        managers.pop_back();

        // Lấy controller trước đó
        GUIWindowManagerBase *current = GetCurrentManager();

        // Hiển thị màn hình của controller trước đó
        current->ShowCurrentWindow();

        ProcessPendingEvent();
    }
    else
    {
    }
}

void GUIEventDispatcher::PushEvent(GUIEventBase::GUIEvent event)
{
    std::lock_guard<std::mutex> lock(queueMutex);
    eventQueue.push(std::move(event));
}

void GUIEventDispatcher::PollEvent(int maxEventsToProcess)
{
    for (int i = 0; i < maxEventsToProcess; ++i)
    {
        GUIEventBase::GUIEvent evt{};
        {
            std::lock_guard<std::mutex> lock(queueMutex);
            if (eventQueue.empty())
            {
                break;
            }
            evt = std::move(eventQueue.front());
            eventQueue.pop();
        }
        ProcessEvent(evt);
    }
}

void GUIEventDispatcher::ProcessEvent(GUIEventBase::GUIEvent event)
{
    std::cout << "ProcessEvent called - Event type: " << static_cast<int>(event.type) << std::endl;
    try
    {
        GUIEventType type = event.type;
        GUIEventPayload payload = event.payload;

        GUIWindowManagerBase::Context thisctx;
        this->onEvent(event, thisctx);

        GUIWindowManagerBase *current = GetCurrentManager();

        if (current->GetId() == GUIHomeManager::Id)
        {
            GUIWindowManagerBase::Context notictx;
            GUINotificationManager::GetInstance().onEvent(event, notictx);
            if (notictx.keyEventHandled)
            {
                return;
            }
        }

        if (current)
        {
            GUIWindowManagerBase::Context ctx;
            // Gọi hàm để lấy thông tin
            current->onEvent(event, ctx);

            // Kiểm tra điều kiện
            if (ctx.doCreateNewManager && !ctx.newManagerName.empty())
            {
                std::cout << "ProcessEvent: Creating new manager: " << ctx.newManagerName << std::endl;
                AddManager(ctx.newManagerName);
            }
            else if (ctx.doBackToPreviousManager)
            {
                BackToPreviousManager();
            }
        }
    }
    catch (const std::exception &ex)
    {
        std::cerr << "[GUIEventDispatcher] ProcessEvent exception: " << ex.what() << "\n";
    }
    catch (...)
    {
        std::cerr << "[GUIEventDispatcher] ProcessEvent unknown exception.\n";
    }
}
void GUIEventDispatcher::ProcessPendingEvent()
{
    // Pending events feature removed
    GUIWindowManagerBase *current = GetCurrentManager();
    if (!current)
        return;
}

void GUIEventDispatcher::onMotionDetected(Context &ctx)
{
    std::cout << "GUIEventDispatcher::onMotionDetected called" << std::endl;
    if (GetCurrentManager()->AllowToBackToHome())
    {
        BackToManager(0);
    }
}

void GUIEventDispatcher::onKey(Key key, KeyPressType press, Context &ctx)
{
    std::cout << "GUIEventDispatcher::onKey - Key: " << static_cast<int>(key)
              << ", Press: " << static_cast<int>(press) << std::endl;

    GUIWindowManagerBase *current = GetCurrentManager();
    if (current)
    {
        std::cout << "  Routing to manager: " << current->GetId() << std::endl;
        current->onKey(key, press, ctx);

        // Check if manager wants to create new manager or go back
        if (ctx.doCreateNewManager && !ctx.newManagerName.empty())
        {
            std::cout << "  Manager requested new manager: " << ctx.newManagerName << std::endl;
            AddManager(ctx.newManagerName);
        }
        else if (ctx.doBackToPreviousManager)
        {
            std::cout << "  Manager requested back to previous" << std::endl;
            BackToPreviousManager();
        }
    }
    else
    {
        std::cout << "  No current manager!" << std::endl;
    }
}