#include "GUIEventBase.h"

void GUIEventBase::onEvent(GUIEvent event, Context &ctx)
{
    try
    {
        GUIEventType type = event.type;
        GUIEventPayload payload = event.payload;

        switch (type)
        {
        case GUIEventType::Key:
            if (std::holds_alternative<KeyPayload>(payload))
            {
                const auto &key = std::get<KeyPayload>(payload);
                onKey(key.key, key.pressType, ctx);
                SplitKey(key.key, key.pressType, ctx);
            }
            break;
        case GUIEventType::MotionDetected:
            onMotionDetected(ctx);
            break;
        case GUIEventType::ShockDetected:
            onShockDetected(ctx);
            break;
        case GUIEventType::LongDrivingAttention:
            onLongDrivingAttention(ctx);
            break;
        case GUIEventType::VehicleSpeedChanged:
            if (std::holds_alternative<float>(payload))
            {
                const auto &value = std::get<float>(payload);
                onVehicleSpeedChanged(value, ctx);
            }
            break;
        case GUIEventType::Network4GSignalStrengthChanged:
            if (std::holds_alternative<int>(payload))
            {
                const auto &value = std::get<int>(payload);
                onNetwork4GSignalStrengthChanged(value, ctx);
            }
            break;
        case GUIEventType::PowerOnWithoutSdCard:
            onPowerOnWithoutSdCard(ctx);
            break;
        case GUIEventType::SdCardRemoved:
            onSdCardRemoved(ctx);
            break;
        case GUIEventType::SdCardInserted:
            onSdCardInserted(ctx);
            break;
        case GUIEventType::PlaybackStoppedAbnormallyDuringFilePlayback:
            onPlaybackStoppedAbnormallyDuringFilePlayback(ctx);
            break;
        case GUIEventType::PlaySoundDone:
            onPlaySoundDone(ctx);
            break;
        default:
            break;
        }
    }
    catch (const std::exception &ex)
    {
        std::cerr << "[GUIEventBase] onEvent exception: " << ex.what() << "\n";
    }
    catch (...)
    {
        std::cerr << "[GUIEventBase] onEvent unknown exception.\n";
    }
}
void GUIEventBase::SplitKey(Key key, KeyPressType press, Context &ctx)
{
    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case KeyPressType::Short:
            onUPKeyShortPressed(ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case KeyPressType::Short:
            onMENU_OKKeyShortPressed(ctx);
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case KeyPressType::Short:
            onDOWNKeyShortPressed(ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case KeyPressType::Short:
            onMIC_ON_OFFKeyShortPressed(ctx);
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        switch (press)
        {
        case KeyPressType::Short:
            onEmergency_CallKeyShortPressed(ctx);
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}