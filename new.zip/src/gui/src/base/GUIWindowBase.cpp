#include "GUIWindowBase.h"

GUIWindowBase::GUIWindowBase()
{
    Init();
}

GUIWindowBase::~GUIWindowBase()
{
}

void GUIWindowBase::Show()
{
    if (scr)
    {
        GUIEngine::GetInstance().ShowScreen(scr);
    }
}

lv_obj_t *GUIWindowBase::GetScreen()
{
    return scr;
}