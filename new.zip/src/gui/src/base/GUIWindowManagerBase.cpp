#include "GUIWindowManagerBase.h"

GUIWindowManagerBase::GUIWindowManagerBase()
{
}

GUIWindowManagerBase::~GUIWindowManagerBase()
{
    windows.clear();
}

GUIWindowBase *GUIWindowManagerBase::GetCurrentWindow()
{
    GUIWindowBase *window = windows.back().get();
    if (window == nullptr)
    {
        // std::wcerr << "[Warning] Active screen is nullptr.\n";
    }

    return window;
}

void GUIWindowManagerBase::SetCurrentWindow(std::string name)
{
    std::unique_ptr<GUIWindowBase> window = GUIWindowFactory::GetInstance().Create(name);
    if (!window)
    {
        // TODO: xử lý tên không hợp lệ (log, fallback, thông báo)
        return;
    }

    windows.push_back(std::move(window));
}
void GUIWindowManagerBase::RefreshCurrentWindow()
{
    GUIWindowBase *current = GetCurrentWindow();
    if (current)
    {
        current->Refresh();
    }
}
void GUIWindowManagerBase::BackToPreviousWindow()
{
    if (windows.size() > 1)
    {
        // Xóa màn hình hiện tại
        windows.pop_back();

        ShowCurrentWindow();
    }
    else
    {
        // std::wcout << "No previous screen to return to.\n";
    }
}

void GUIWindowManagerBase::ShowCurrentWindow()
{
    GUIWindowBase *current = GetCurrentWindow();
    if (current)
    {
        current->Show();
    }
    RefreshCurrentWindow();
}