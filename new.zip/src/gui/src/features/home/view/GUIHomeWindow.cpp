#include "GUIHomeWindow.h"

GUIHomeWindow::GUIHomeWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIHomeWindow::~GUIHomeWindow()
{
}

void GUIHomeWindow::Init()
{
    auto &eng = GUIEngine::GetInstance();
    // eng.SetScreenColor(scr, 0x67D1FF);
    eng.SetScreenColor(scr, 0x000000);

    SetUpImage("C:btn_guide_VolUp.png");
    SetMenuOkImage("C:btn_guide_Menu.png");
    SetDownImage("C:btn_guide_VolDown.png");

    network4G = new Network4G(scr);
    network4G->Init();
    network4G->SetLocation(528, 8);
    network4G->SetSize(60, 32);

    // Initialize state
    bool isMicOn = GUIActionHandler::GetInstance().GetMicOnOff();
    this->SetMicOnOff(isMicOn);

    int network4GSignalStrength = GUIActionHandler::GetInstance().GetNetwork4GSignalStrength();
    this->Set4GSignalStrength(network4GSignalStrength);
}

void GUIHomeWindow::SetMicOnOff(bool on)
{
    if (on)
    {
        SetMicOnOffImage("C:btn_guide_MicOn.png");
    }
    else
    {
        SetMicOnOffImage("C:btn_guide_MicOff.png");
    }
}

void GUIHomeWindow::Set4GSignalStrength(int strength)
{
    if (network4G)
    {
        network4G->SetSignalStrength(strength);
    }
}

void GUIHomeWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Handle key events if needed
}

void GUIHomeWindow::onShockDetected(Context &ctx)
{
    // Handle shock detection if needed
}

void GUIHomeWindow::onMotionDetected(Context &ctx)
{
    // Handle motion detection if needed
}