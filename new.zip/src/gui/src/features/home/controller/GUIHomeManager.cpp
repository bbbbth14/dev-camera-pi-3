#include "GUIHomeManager.h"

GUIHomeManager::GUIHomeManager() : state(State::HOME)
{
    Init();
}

GUIHomeManager::~GUIHomeManager()
{
}

std::string GUIHomeManager::GetStateName() const
{
    switch (state)
    {
    case State::HOME:
        return "HOME";
    default:
        return "UNKNOWN";
    }
}
std::string GUIHomeManager::GetId() const
{
    return Id;
}
void GUIHomeManager::Init()
{
    SetCurrentWindow(GUIHomeWindow::Id);
}

void GUIHomeManager::onKey(Key key, KeyPressType press, Context &ctx)
{
    std::cout << "GUIHomeManager::onKey - Key: " << static_cast<int>(key) << ", Press: " << static_cast<int>(press) << std::endl;

    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    if (current)
    {
        current->onKey(key, press, ctx);
    }

    switch (key)
    {
    case Key::MENU_OK:
        switch (press)
        {
        case KeyPressType::Short:
            std::cout << "MENU_OK Short pressed in HOME state" << std::endl;
            if (state == State::HOME)
            {
                std::cout << "Setting flag to create GUIMenuManager" << std::endl;
                ctx.doCreateNewManager = true;
                ctx.newManagerName = GUIMenuManager::Id;
            }
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case KeyPressType::Short:
            ToggleMicOnOff();
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}

void GUIHomeManager::onNetwork4GSignalStrengthChanged(int value, Context &ctx)
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    current->Set4GSignalStrength(value);
}
void GUIHomeManager::ToggleMicOnOff()
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();

    bool isMicOn = GUIActionHandler::GetInstance().GetMicOnOff();
    current->SetMicOnOff(!isMicOn);

    GUIActionHandler::GetInstance().SetMicOnOff(!isMicOn);
}

void GUIHomeManager::onShockDetected(Context &ctx)
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    if (current)
    {
        current->onShockDetected(ctx);
    }
}

void GUIHomeManager::onMotionDetected(Context &ctx)
{
    GUIHomeWindow *current = (GUIHomeWindow *)GetCurrentWindow();
    if (current)
    {
        current->onMotionDetected(ctx);
    }
}