#include "GUIMenuManager.h"
#include "GUIMenuInquiriesGroupManager.h"

GUIMenuManager::GUIMenuManager() : state(State::MAIN)
{
    std::cout << "GUIMenuManager constructor called" << std::endl;
    Init();
}

GUIMenuManager::~GUIMenuManager()
{
}

std::string GUIMenuManager::GetStateName() const
{
    switch (state)
    {
    case State::MAIN:
        return "MAIN";
    default:
        return "UNKNOWN";
    }
}

std::string GUIMenuManager::GetId() const
{
    return Id;
}

void GUIMenuManager::Init()
{
    std::cout << "GUIMenuManager::Init() - Setting window to: " << GUIMenuMainWindow::Id << std::endl;
    SetCurrentWindow(GUIMenuMainWindow::Id);
}

void GUIMenuManager::onKey(Key key, KeyPressType press, Context &ctx)
{
    GUIWindowBase *current = GetCurrentWindow();

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case KeyPressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case KeyPressType::Short:
            if (state == State::MAIN)
            {
                GUIMenuMainWindow *current = (GUIMenuMainWindow *)GetCurrentWindow();
                int activeIndex = current->GetActiveIndex();

                switch (activeIndex)
                {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    // Inquiries item selected
                    ctx.doCreateNewManager = true;
                    ctx.newManagerName = GUIMenuInquiriesGroupManager::Id;
                    break;
                default:
                    break;
                }
            }
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case KeyPressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case KeyPressType::Short:
            if (state == State::MAIN)
            {
                ctx.doBackToPreviousManager = true;
            }
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}
