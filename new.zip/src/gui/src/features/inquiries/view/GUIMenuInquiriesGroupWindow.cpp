#include "GUIMenuInquiriesGroupWindow.h"

GUIMenuInquiriesGroupWindow::GUIMenuInquiriesGroupWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIMenuInquiriesGroupWindow::~GUIMenuInquiriesGroupWindow()
{
}

void GUIMenuInquiriesGroupWindow::Init()
{
    GUIWindowLayoutBase::Init();

    GUIEngine::GetInstance().SetScreenGradient(scr, 0x024BA0, 0x080A2D);

    SetTitle("Inquiries フォルダ選択");
    SetTitleShadow();
    // SetMessage("このエリアには選択している機能の概要が表示されます。");
    SetUpImage("C:btn_guide_Up.png");
    SetMenuOkImage("C:btn_guide_OK.png");
    SetDownImage("C:btn_guide_Down.png");
    SetMicOnOffImage("C:btn_guide_MIC_ON_OFF.png");
    menuList = std::make_unique<List>(scr);
    menuList->Init();
    menuList->SetActiveStylePath("C:activeListItem.png");
    menuList->SetLocation(0, 72);
    menuList->SetSize(532, 240);
    menuList->AddItems({
        "Inquiries Notification 常時録画",
        "Inquiries Contact イベント動画",
    });
    std::cout << __FILE__ << " Init done" << std::endl;
}

void GUIMenuInquiriesGroupWindow::Refresh()
{
}

void GUIMenuInquiriesGroupWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    menuList->onKey(key, press, ctx);
}

void GUIMenuInquiriesGroupWindow::onUPKeyShortPressed(Context &ctx)
{
    menuList->onUPKeyShortPressed(ctx);
}

void GUIMenuInquiriesGroupWindow::onMENU_OKKeyShortPressed(Context &ctx)
{
}

void GUIMenuInquiriesGroupWindow::onDOWNKeyShortPressed(Context &ctx)
{
    menuList->onDOWNKeyShortPressed(ctx);
}
void GUIMenuInquiriesGroupWindow::onMIC_ON_OFFKeyShortPressed(Context &ctx)
{
}

int GUIMenuInquiriesGroupWindow::GetActiveIndex()
{
    if (!menuList)
    {
        return -1;
    }

    return menuList->GetActiveIndex();
}

bool GUIMenuInquiriesGroupWindow::SetIndexState(bool isEnable, int iIndex)
{
    bool ret = false;
    if (menuList)
    {
        if ((iIndex >= 0) && (iIndex < menuList->GetCount()))
        {
            // do set the item disable/enable
            // menuList->SetItemDisable(index);
        }
    }
    return ret;
}