#include "GUINotificationDetailWindow.h"

GUINotificationDetailWindow::GUINotificationDetailWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUINotificationDetailWindow::~GUINotificationDetailWindow()
{
}

void GUINotificationDetailWindow::Init()
{
    GUIWindowLayoutBase::Init();

    GUIEngine::GetInstance().SetScreenGradient(scr, 0x024BA0, 0x080A2D);

    SetTitle("Notification Detail");
    SetTitleShadow();
    SetMicOnOffImage("C:btn_guide_MIC_ON_OFF.png");

    std::cout << "GUINotificationDetailWindow::Init() - Window initialized" << std::endl;

    // Create label for notification detail using available method
    auto &eng = GUIEngine::GetInstance();
    detailLabel = eng.CreateLabelAbsoluteTextLeft(
        scr,
        "Loading notification...",
        500, 200,
        GUIEngine::Font::NotoSansJP_Regular_16,
        30, 80,
        0xFFFFFF);

    std::cout << "GUINotificationDetailWindow::Init() - Label created" << std::endl;
}

void GUINotificationDetailWindow::Refresh()
{
}

void GUINotificationDetailWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Keys handled by manager
}

void GUINotificationDetailWindow::SetNotificationDetail(int index)
{
    notificationIndex = index;

    std::cout << "GUINotificationDetailWindow::SetNotificationDetail - Index: " << index << std::endl;

    // TODO: Fetch notification content from server via GUIActionHandler based on index
    // For now, using local sample data

    // Get notification content based on index
    std::string content;
    switch (index)
    {
    case 0:
        content = "Notification 1: System Update\n\n"
                  "A new system update is available.\n"
                  "Please update at your earliest\n"
                  "convenience.\n"
                  "Version: 2.5.1  Size: 150MB";
        break;
    case 1:
        content = "Notification 2: Maintenance\n\n"
                  "Scheduled maintenance on\n"
                  "Jan 20, 2026\n"
                  "Time: 2:00 AM - 6:00 AM\n"
                  "Services may be unavailable.";
        break;
    case 2:
        content = "Notification 3: New Features\n\n"
                  "New features added:\n"
                  "- Enhanced navigation\n"
                  "- Improved UI\n"
                  "- Better performance";
        break;
    case 3:
        content = "Notification 4: Warning Alert\n\n"
                  "Please ensure all safety checks\n"
                  "are completed before operation.\n"
                  "Contact support if needed.";
        break;
    default:
        content = "Notification not found";
        break;
    }

    // Delete old label and create new one with updated text
    auto &eng = GUIEngine::GetInstance();
    if (detailLabel)
    {
        eng.DeleteObject(detailLabel);
    }

    detailLabel = eng.CreateLabelAbsoluteTextLeft(
        scr,
        content.c_str(),
        500, 200,
        GUIEngine::Font::NotoSansJP_Regular_16,
        30, 80,
        0xFFFFFF);
}