#include "GUIMenuInquiriesIndexWindow.h"

GUIMenuInquiriesIndexWindow::GUIMenuInquiriesIndexWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIMenuInquiriesIndexWindow::~GUIMenuInquiriesIndexWindow()
{
}

void GUIMenuInquiriesIndexWindow::Init()
{
    GUIWindowLayoutBase::Init();

    GUIEngine::GetInstance().SetScreenGradient(scr, 0x024BA0, 0x080A2D);

    SetTitleShadow();
    SetUpImage("C:btn_guide_Up.png");
    SetMenuOkImage("C:btn_guide_OK.png");
    SetDownImage("C:btn_guide_Down.png");
    SetMicOnOffImage("C:btn_guide_MIC_ON_OFF.png");
    menuList = std::make_unique<List>(scr);
    menuList->Init();
    menuList->SetActiveStylePath("C:activeListItem.png");
    menuList->SetLocation(0, 72);
    menuList->SetSize(532, 240);
}

void GUIMenuInquiriesIndexWindow::Refresh()
{
}

void GUIMenuInquiriesIndexWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    menuList->onKey(key, press, ctx);

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case KeyPressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case KeyPressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case KeyPressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case KeyPressType::Short:
            break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}
int GUIMenuInquiriesIndexWindow::GetActiveIndex()
{
    if (!menuList)
    {
        return -1;
    }

    return menuList->GetActiveIndex();
}

// bool GUIMenuInquiriesIndexWindow::SetIndexState(bool isEnable, int iIndex)
// {
//     bool ret = false;
//     if (menuList)
//     {
//         if ((iIndex >= 0) && (iIndex < menuList->GetListCount()))
//         {
//             //do set the item disable/enable
//             //menuList->SetItemDisable(index);
//         }
//     }
//     return ret;
// }

void GUIMenuInquiriesIndexWindow::SetIndexTitle(GUIMenuTitle titleId)
{
    bool found = false;
    for (auto iter : windowTitles)
    {
        if (iter.first == titleId)
        {
            SetTitle(iter.second);
            std::cout << "GUIMenuInquiriesIndexWindow::SetIndexTitle - Title set to: " << iter.second << std::endl;
            found = true;
            break;
        }
    }
    if (!found)
    {
        std::cout << __FILE__ << " title index " << titleId << " not found" << std::endl;
    }
}
void GUIMenuInquiriesIndexWindow::SetIndexItemsList(std::vector<std::string> itemList)
{
    std::cout << "GUIMenuInquiriesIndexWindow::SetIndexItemsList - Adding " << itemList.size() << " items" << std::endl;
    for (auto iter : itemList)
    {
        menuList->AddItem(iter);
        std::cout << "  - Added item: " << iter << std::endl;
    }
    std::cout << "GUIMenuInquiriesIndexWindow: All items added successfully" << std::endl;
}
void GUIMenuInquiriesIndexWindow::SetItemThumbnail(std::string strThumbPath)
{
    // TODO
}