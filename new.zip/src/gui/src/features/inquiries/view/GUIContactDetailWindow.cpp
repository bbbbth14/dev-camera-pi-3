#include "GUIContactDetailWindow.h"

GUIContactDetailWindow::GUIContactDetailWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIContactDetailWindow::~GUIContactDetailWindow()
{
}

void GUIContactDetailWindow::Init()
{
    GUIWindowLayoutBase::Init();

    GUIEngine::GetInstance().SetScreenGradient(scr, 0x024BA0, 0x080A2D);

    SetTitle("Contact Information");
    SetTitleShadow();
    SetMicOnOffImage("C:btn_guide_MIC_ON_OFF.png");

    std::cout << "GUIContactDetailWindow::Init() - Creating contact display" << std::endl;

    auto &eng = GUIEngine::GetInstance();

    // Create labels for contact information
    contactLabel1 = eng.CreateLabelAbsoluteTextLeft(
        scr,
        "Emergency: 119",
        500, 30,
        GUIEngine::Font::NotoSansJP_Regular_24,
        30, 80,
        0xFFFFFF);

    contactLabel2 = eng.CreateLabelAbsoluteTextLeft(
        scr,
        "Police: 110",
        500, 30,
        GUIEngine::Font::NotoSansJP_Regular_24,
        30, 130,
        0xFFFFFF);

    contactLabel3 = eng.CreateLabelAbsoluteTextLeft(
        scr,
        "Support: 0120-XXX-XXX",
        500, 30,
        GUIEngine::Font::NotoSansJP_Regular_24,
        30, 180,
        0xFFFFFF);

    std::cout << "GUIContactDetailWindow::Init() - Contact labels created" << std::endl;
}

void GUIContactDetailWindow::Refresh()
{
}

void GUIContactDetailWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Keys handled by manager
}
