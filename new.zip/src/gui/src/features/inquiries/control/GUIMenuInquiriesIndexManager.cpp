#include "GUIMenuInquiriesIndexManager.h"

GUIMenuInquiriesIndexManager::GUIMenuInquiriesIndexManager()
{
    Init();
    mMenuType = GUI_WINDOW_TYPE_NOTIFICATION;
    mViewMode = VIEW_MODE_LIST;
    mSelectedIndex = 0;
}

GUIMenuInquiriesIndexManager::GUIMenuInquiriesIndexManager(GUIMenuType eMenuType)
{
    Init();
    mMenuType = eMenuType;
    mViewMode = VIEW_MODE_LIST;
    mSelectedIndex = 0;

    GUIMenuInquiriesIndexWindow *window = static_cast<GUIMenuInquiriesIndexWindow *>(GetCurrentWindow());
    window->SetIndexTitle(getWindowTitle(eMenuType));

    // Populate the list based on menu type
    if (eMenuType == GUI_WINDOW_TYPE_CONTACT)
    {
        // Show contact information (static display)
        std::vector<std::string> contactItems = {
            "Emergency: 119",
            "Police: 110",
            "Support: 0120-XXX-XXX"};
        window->SetIndexItemsList(contactItems);
    }
    else if (eMenuType == GUI_WINDOW_TYPE_NOTIFICATION)
    {
        // TODO: Fetch notification list from server via GUIActionHandler
        // For now, using sample data
        std::vector<std::string> notificationItems = {
            "Notification 1: System Update",
            "Notification 2: Maintenance",
            "Notification 3: New Features",
            "Notification 4: Warning Alert"};
        window->SetIndexItemsList(notificationItems);
    }
}

// Constructor for detail view
GUIMenuInquiriesIndexManager::GUIMenuInquiriesIndexManager(GUIMenuType eMenuType, int selectedIndex)
{
    mMenuType = eMenuType;
    mViewMode = VIEW_MODE_DETAIL;
    mSelectedIndex = selectedIndex;

    // Set the appropriate detail window based on type
    if (eMenuType == GUI_WINDOW_TYPE_CONTACT)
    {
        SetCurrentWindow(GUIContactDetailWindow::Id);
    }
    else if (eMenuType == GUI_WINDOW_TYPE_NOTIFICATION)
    {
        SetCurrentWindow(GUINotificationDetailWindow::Id);
        // TODO: Fetch notification details from server via GUIActionHandler
        // For now, using local data
        GUINotificationDetailWindow *window = static_cast<GUINotificationDetailWindow *>(GetCurrentWindow());
        window->SetNotificationDetail(selectedIndex);
    }
}

GUIMenuInquiriesIndexManager::~GUIMenuInquiriesIndexManager()
{
}

std::string GUIMenuInquiriesIndexManager::GetStateName() const
{
    return "UNKNOWN";
}

std::string GUIMenuInquiriesIndexManager::GetId() const
{
    std::string Id;
    switch (mMenuType)
    {
    case GUI_WINDOW_TYPE_NOTIFICATION:
        Id = IdConstNoti;
        break;
    case GUI_WINDOW_TYPE_CONTACT:
        Id = IdConstContact;
        break;
    // case GUI_WINDOW_TYPE_EVENT_IMAGE:
    //     Id = IdEventImg;
    //     break;
    default:
        Id = IdConstNoti;
        break;
    }
    return Id;
}
void GUIMenuInquiriesIndexManager::Init()
{
    // Init is only called for list view mode
    SetCurrentWindow(GUIMenuInquiriesIndexWindow::Id);
}

void GUIMenuInquiriesIndexManager::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Different handling based on view mode
    if (mViewMode == VIEW_MODE_DETAIL)
    {
        // Detail view - only handle back button
        if (key == Key::MIC_ON_OFF && press == KeyPressType::Short)
        {
            ctx.doBackToPreviousManager = true;
        }
        return;
    }

    // List view - handle navigation
    GUIWindowBase *current = GetCurrentWindow();

    switch (key)
    {
    case Key::UP:
        switch (press)
        {
        case KeyPressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MENU_OK:
        switch (press)
        {
        case KeyPressType::Short:
        {
            GUIMenuInquiriesIndexWindow *current = (GUIMenuInquiriesIndexWindow *)GetCurrentWindow();
            int activeIndex = current->GetActiveIndex();

            // Navigate to detail view
            if (mMenuType == GUI_WINDOW_TYPE_NOTIFICATION)
            {
                std::cout << "Selected notification at index: " << activeIndex << std::endl;
                ctx.doCreateNewManager = true;
                ctx.newManagerName = IdNotificationDetail;
            }
            else if (mMenuType == GUI_WINDOW_TYPE_CONTACT)
            {
                std::cout << "Navigating to contact detail" << std::endl;
                ctx.doCreateNewManager = true;
                ctx.newManagerName = IdContactDetail;
            }
        }
        break;
        default:
            break;
        }
        break;
    case Key::DOWN:
        switch (press)
        {
        case KeyPressType::Short:
            current->onKey(key, press, ctx);
            break;
        default:
            break;
        }
        break;
    case Key::MIC_ON_OFF:
        switch (press)
        {
        case KeyPressType::Short:
        {
            ctx.doBackToPreviousManager = true;
        }
        break;
        default:
            break;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}

/*private function*/
GUIMenuInquiriesIndexWindow::GUIMenuTitle GUIMenuInquiriesIndexManager::getWindowTitle(GUIMenuInquiriesIndexManager::GUIMenuType guiMenuType)
{
    GUIMenuInquiriesIndexWindow::GUIMenuTitle title = GUIMenuInquiriesIndexWindow::GUI_WINDOW_TITLE_CONTACT;
    for (auto it : windowTypeTitle)
    {
        if (it.first == guiMenuType)
        {
            title = it.second;
            break;
        }
    }
    return title;
}