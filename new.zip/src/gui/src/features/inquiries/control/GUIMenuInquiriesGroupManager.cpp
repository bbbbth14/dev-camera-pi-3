#include "GUIMenuInquiriesGroupManager.h"
#include "GUIMenuInquiriesIndexManager.h"

GUIMenuInquiriesGroupManager::GUIMenuInquiriesGroupManager()
{
    Init();
    // UpdateMenuStatus();
    std::cout << __FILE__ << " Init done" << std::endl;
}

GUIMenuInquiriesGroupManager::~GUIMenuInquiriesGroupManager()
{
}

std::string GUIMenuInquiriesGroupManager::GetId() const
{
    return Id;
}

std::string GUIMenuInquiriesGroupManager::GetStateName() const
{
    return "UNKNOWN";
}

void GUIMenuInquiriesGroupManager::Init()
{
    SetCurrentWindow(GUIMenuInquiriesGroupWindow::Id);
}

void GUIMenuInquiriesGroupManager::onKey(Key key, KeyPressType press, Context &ctx)
{
    GUIWindowBase *current = GetCurrentWindow();

    switch (key)
    {
    case Key::UP:
        if (press == KeyPressType::Short)
        {
            current->onKey(key, press, ctx);
        }
        break;
    case Key::MENU_OK:
        if (press == KeyPressType::Short)
        {
            GUIMenuInquiriesGroupWindow *win = (GUIMenuInquiriesGroupWindow *)current;
            int activeIndex = win->GetActiveIndex();

            switch (activeIndex)
            {
            case 0: // Notification
            {
                ctx.doCreateNewManager = true;
                ctx.newManagerName = GUIMenuInquiriesIndexManager::IdConstNoti;
            }
            break;
            case 1: // Contact
            {
                ctx.doCreateNewManager = true;
                ctx.newManagerName = GUIMenuInquiriesIndexManager::IdConstContact;
            }
            break;
            default:
                break;
            }
        }
        break;
    case Key::DOWN:
        if (press == KeyPressType::Short)
        {
            current->onKey(key, press, ctx);
        }
        break;
    case Key::MIC_ON_OFF:
        if (press == KeyPressType::Short)
        {
            ctx.doBackToPreviousManager = true;
        }
        break;
    case Key::Emergency_Call:
        break;
    default:
        break;
    }
}

void GUIMenuInquiriesGroupManager::onUPKeyShortPressed(Context &ctx)
{
    GUIWindowBase *current = GetCurrentWindow();
    current->onUPKeyShortPressed(ctx);
}

void GUIMenuInquiriesGroupManager::onMENU_OKKeyShortPressed(Context &ctx)
{
    GUIMenuInquiriesGroupWindow *current = (GUIMenuInquiriesGroupWindow *)GetCurrentWindow();
    int activeIndex = current->GetActiveIndex();

    switch (activeIndex)
    {
    case 0:
    {
        ctx.doCreateNewManager = true;
        ctx.newManagerName = GUIMenuInquiriesIndexManager::IdConstNoti;
    }
    break;
    case 1:
    {
        ctx.doCreateNewManager = true;
        ctx.newManagerName = GUIMenuInquiriesIndexManager::IdConstContact;
    }
    break;
        // case 2:
        // {
        //     ctx.doCreateNewManager = true;
        //     ctx.newManagerName = GUIMenuInquiriesIndexManager::IdEventImg;
        // }
        break;
    default:
        break;
    }
}

void GUIMenuInquiriesGroupManager::onDOWNKeyShortPressed(Context &ctx)
{
    GUIWindowBase *current = GetCurrentWindow();
    current->onDOWNKeyShortPressed(ctx);
}
void GUIMenuInquiriesGroupManager::onMIC_ON_OFFKeyShortPressed(Context &ctx)
{
    ctx.doBackToPreviousManager = true;
}

void GUIMenuInquiriesGroupManager::UpdateMenuStatus()
{
    // TODO:
    // get the list of file for
    //   record video
    //   event video
    //   static image
    // if the number of video/image is 0.
    // set the correspond menu item as deactive/disable.
    GUIMenuInquiriesGroupWindow *currentWindow = static_cast<GUIMenuInquiriesGroupWindow *>(GetCurrentWindow());
    currentWindow->SetIndexState(false, 0);
}