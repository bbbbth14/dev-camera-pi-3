#include "GUINotificationManager.h"

GUINotificationManager::GUINotificationManager()
{
}

GUINotificationManager::~GUINotificationManager()
{
}

GUINotificationManager &GUINotificationManager::GetInstance()
{
    static GUINotificationManager instance;
    return instance;
}

GUIPopupBase *GUINotificationManager::GetCurrentPopup()
{
    return popup.get();
}

void GUINotificationManager::SetCurrentPopup(std::string name)
{
    if (popup)
    {
        popup.reset();
    }

    popup = std::move(GUIPopupFactory::GetInstance().Create(name));
}

void GUINotificationManager::ShowPopupWithAutoClose(GUIEventPopup::DrivingAlert alertType)
{
    std::cout << "ShowPopupWithAutoClose: alert type " << static_cast<int>(alertType) << std::endl;

    // Create popup
    SetCurrentPopup(GUIEventPopup::Id);

    if (!popup)
    {
        std::cout << "ERROR: Failed to create popup" << std::endl;
        return;
    }

    // Configure alert type
    GUIEventPopup *eventPopup = static_cast<GUIEventPopup *>(popup.get());
    eventPopup->SetAlertType(alertType);

    // Show popup
    popup->Open();

    // Auto-close after 3 seconds
    GUIEngine::GetInstance().CreateOneShotTimer(
        [this]()
        {
            CloseCurrentPopup();
        },
        3000);
}

void GUINotificationManager::CloseCurrentPopup()
{
    std::cout << "CloseCurrentPopup" << std::endl;
    if (popup)
    {
        popup->Close();
    }
}

void GUINotificationManager::onShockDetected(Context &ctx)
{
    std::cout << "GUINotificationManager::onShockDetected()" << std::endl;
    ShowPopupWithAutoClose(GUIEventPopup::DrivingAlert::ShockDetected);
}

void GUINotificationManager::onLongDrivingAttention(Context &ctx)
{
    std::cout << "GUINotificationManager::onLongDrivingAttention()" << std::endl;
    ShowPopupWithAutoClose(GUIEventPopup::DrivingAlert::LongDrivingAttention);
}