#include "GUIBootupWindow.h"
#include "GUIEngine.h"
#include "GUIEventDispatcher.h"
#include "GUIHomeManager.h"
#include "TextBox.h"

GUIBootupWindow::GUIBootupWindow() : GUIWindowLayoutBase()
{
    Init();
}

GUIBootupWindow::~GUIBootupWindow()
{
}

void GUIBootupWindow::Init()
{
    GUIWindowLayoutBase::Init();

    auto &eng = GUIEngine::GetInstance();

    // Set black background
    eng.SetScreenColor(scr, 0x000000);

    // Hide default buttons during bootup
    if (upButton)
        eng.HideObject(upButton->obj);
    if (menuOkButton)
        eng.HideObject(menuOkButton->obj);
    if (downButton)
        eng.HideObject(downButton->obj);
    if (micOnOffButton)
        eng.HideObject(micOnOffButton->obj);

    // Main text (centered) - reused for all stages
    mainTextBox = new TextBox(scr);
    mainTextBox->Init();
    mainTextBox->SetLocation(0, 120);
    mainTextBox->SetSize(640, 80);
    mainTextBox->SetText("THE COMPANY", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
    mainTextBox->Hide();

    // Sub text (centered below main) - optional for stages that need it
    subTextBox = new TextBox(scr);
    subTextBox->Init();
    subTextBox->SetLocation(0, 200);
    subTextBox->SetSize(640, 40);
    subTextBox->SetText("Starting...", 640, 40, GUIEngine::Font::NotoSansJP_Regular_16, 0xCCCCCC);
    subTextBox->Hide();
}

// ============= EVENT HANDLERS =============

void GUIBootupWindow::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Event handling moved to GUIBootupManager
    // Window no longer handles keys directly
}
