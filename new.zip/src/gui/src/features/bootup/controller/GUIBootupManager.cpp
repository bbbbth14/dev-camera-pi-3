#include "GUIBootupManager.h"
#include "GUIEngine.h"
#include "GUIEventDispatcher.h"
#include "GUIActionHandler.h"
#include "TextBox.h"
#include <filesystem>
#include <fstream>

GUIBootupManager::GUIBootupManager() : state(State::BOOTUP)
{
    std::cout << "GUIBootupManager constructor called" << std::endl;
    Init();
    std::cout << "GUIBootupManager initialized" << std::endl;
}

GUIBootupManager::~GUIBootupManager()
{
}

std::string GUIBootupManager::GetStateName() const
{
    switch (state)
    {
    case State::BOOTUP:
        return "BOOTUP";
    default:
        return "UNKNOWN";
    }
}

std::string GUIBootupManager::GetId() const
{
    return Id;
}

void GUIBootupManager::Init()
{
    std::cout << "GUIBootupManager::Init() called" << std::endl;
    // Create directly (factory registration may not include Bootup yet).
    SetCurrentWindow(GUIBootupWindow::Id);
    std::cout << "Starting boot sequence..." << std::endl;
    StartBootSequence();
}

void GUIBootupManager::StartBootSequence()
{
    std::cout << "GUIBootupManager::StartBootSequence() called" << std::endl;

    if (bootupTimer)
    {
        std::cout << "Bootup timer already active, skipping re-start" << std::endl;
        return;
    }

    isFirstBoot = IsFirstBoot();
    std::cout << "Boot mode: " << (isFirstBoot ? "FIRST" : "SUBSEQUENT") << " boot" << std::endl;

    Stage1_ShowCompanyName();
}

void GUIBootupManager::Stage1_ShowCompanyName()
{
    std::cout << "Stage 1: Showing company name" << std::endl;
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Show company name
    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("THE COMPANY", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
        current->mainTextBox->Show();
    }

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]()
                                         { Stage2_ShowWarning(); }, 4000);
}

void GUIBootupManager::Stage2_ShowWarning()
{
    std::cout << "Stage 2: Showing warning" << std::endl;
    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Update main text to Warning
    if (current->mainTextBox)
    {
        current->mainTextBox->SetText("Warning", 640, 80, GUIEngine::Font::NotoSansJP_Regular_28, 0xFFFFFF);
        current->mainTextBox->Show();
    }

    auto &eng = GUIEngine::GetInstance();
    bootupTimer = eng.CreateOneShotTimer([this]()
                                         {
                                             if (isFirstBoot)
                                             {
                                                 // First boot: skip checks, go to setup prompt
                                                 Stage5_SetupOrHome();
                                             }
                                             else
                                             {
                                                 // Subsequent boot: check feet mode
                                                 Stage3_CheckFeetMode();
                                             } }, 4000);
}

void GUIBootupManager::Stage3_CheckFeetMode()
{
    std::cout << "Stage 3: Checking FEET mode" << std::endl;

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Don't change screen - keep previous display
    // Only update if we receive data from server

    // Set 5s timeout for server response
    serverResponseReceived = false;
    auto &eng = GUIEngine::GetInstance();
    serverTimeoutTimer = eng.CreateOneShotTimer([this]()
                                                {
                                                    if (!serverResponseReceived)
                                                    {
                                                        std::cout << "Stage 3: Server timeout (5s), proceeding to next stage" << std::endl;
                                                        serverTimeoutTimer = nullptr;
                                                        Stage4_CheckContract();
                                                    } }, 5000);

    // Simulate server request (in actual implementation, this would be async)
    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto userJsonPath = configDir / "user.json";

    std::string newMode = GUIActionHandler::ReadDataFromServer(userJsonPath.string(), "mode");
    if (newMode.empty())
    {
        std::cout << "user.json not found or mode field missing, using timeout" << std::endl;
        return; // Let timeout handle it
    }

    // Server responded
    serverResponseReceived = true;
    if (serverTimeoutTimer)
    {
        lv_timer_del(serverTimeoutTimer);
        serverTimeoutTimer = nullptr;
    }

    const auto currentModeJsonPath = configDir / "current_mode.json";
    std::string currentMode = GUIActionHandler::ReadDataFromServer(currentModeJsonPath.string(), "mode");

    if (currentMode.empty())
    {
        std::cout << "No current mode found, saving new mode: " << newMode << std::endl;
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (current->mainTextBox)
            current->mainTextBox->SetText(("Mode: " + newMode).c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    }
    else if (currentMode != newMode)
    {
        std::cout << "Mode changed from '" << currentMode << "' to '" << newMode << "', restarting..." << std::endl;
        std::ofstream out(currentModeJsonPath.string());
        out << "{\n  \"mode\": \"" << newMode << "\"\n}\n";
        out.close();

        if (current->mainTextBox)
            current->mainTextBox->SetText(("Changing to: " + newMode + "\nRestarting...").c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFF00);

        RestartBootSequence(current);
        return;
    }
    else
    {
        std::cout << "Mode unchanged: " << currentMode << std::endl;
        if (current->mainTextBox)
            current->mainTextBox->SetText(("Mode: " + currentMode + " (OK)").c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
    }

    bootupTimer = eng.CreateOneShotTimer([this]()
                                         { Stage4_CheckContract(); }, 3000);
}

void GUIBootupManager::Stage4_CheckContract()
{
    std::cout << "Stage 4: Checking contract" << std::endl;

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    // Don't change screen - keep previous display
    // Only update if we receive data from server

    // Set 5s timeout for server response
    serverResponseReceived = false;
    auto &eng = GUIEngine::GetInstance();
    serverTimeoutTimer = eng.CreateOneShotTimer([this]()
                                                {
                                                    if (!serverResponseReceived)
                                                    {
                                                        std::cout << "Stage 4: Server timeout (5s), proceeding to next stage" << std::endl;
                                                        serverTimeoutTimer = nullptr;
                                                        Stage5_SetupOrHome();
                                                    } }, 5000);

    // Simulate server request (in actual implementation, this would be async)
    const auto configDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
    const auto serverJsonPath = configDir / "server.json";

    std::string contractDate = GUIActionHandler::ReadDataFromServer(serverJsonPath.string(), "contract_date");
    if (contractDate.empty())
    {
        std::cout << "server.json not found or contract_date field missing, using timeout" << std::endl;
        return; // Let timeout handle it
    }

    // Server responded
    serverResponseReceived = true;
    if (serverTimeoutTimer)
    {
        lv_timer_del(serverTimeoutTimer);
        serverTimeoutTimer = nullptr;
    }

    // Update with contract date
    if (current->mainTextBox)
        current->mainTextBox->SetText(("Contract: " + contractDate).c_str(), 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);

    bootupTimer = eng.CreateOneShotTimer([this]()
                                         { Stage5_SetupOrHome(); }, 3000);
}

void GUIBootupManager::Stage5_SetupOrHome()
{
    std::cout << "Stage 5: Setup or Home" << std::endl;

    GUIBootupWindow *current = (GUIBootupWindow *)GetCurrentWindow();
    if (!current)
        return;

    if (isFirstBoot)
    {
        std::cout << "First boot: showing setup confirmation screen" << std::endl;
        if (current->mainTextBox)
        {
            current->mainTextBox->SetText("Press MENU/OK to continue", 640, 80, GUIEngine::Font::NotoSansJP_Regular_24, 0xFFFFFF);
            current->mainTextBox->Show();
        }
        bootupTimer = nullptr;
        // Wait for user input (handled in onKey)
    }
    else
    {
        std::cout << "Subsequent boot: going to home" << std::endl;
        bootupTimer = nullptr;
        CompleteBootup();
    }
}

void GUIBootupManager::CompleteBootup()
{
    std::cout << "CompleteBootup() called" << std::endl;

    MarkFirstBootDone();

    // Transition to home directly (no system update popup)
    std::cout << "Bootup complete - transitioning to home manager" << std::endl;
    GUIEventDispatcher::GetInstance().AddManager(GUIHomeManager::Id);
}

void GUIBootupManager::HideSystemUpdatePopup(GUIBootupWindow *current)
{
    // Not used anymore - system update popup removed
}

void GUIBootupManager::RestartBootSequence(GUIBootupWindow *current)
{
    std::cout << "=== RESTARTING BOOT SEQUENCE ===" << std::endl;
    auto &eng = GUIEngine::GetInstance();
    eng.CreateOneShotTimer(
        [this, current]()
        {
            if (current)
            {
                // Reset all stages
                current->imageShown = false;
                current->systemUpdatePopupShown = false;

                if (current->imageObj)
                {
                    auto &eng = GUIEngine::GetInstance();
                    eng.DeleteObject(current->imageObj);
                    current->imageObj = nullptr;
                }

                if (current->mainTextBox)
                    current->mainTextBox->Hide();
            }

            bootupTimer = nullptr;
            StartBootSequence();
        },
        2000);
}

bool GUIBootupManager::IsFirstBoot() const
{
    try
    {
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        const auto marker = markerDir / "first_boot_done.json";

        if (!std::filesystem::exists(marker))
        {
            std::cout << "First boot marker not found at: " << marker.string() << std::endl;
            return true;
        }

        // Check if file contains correct flag
        std::string bootDone = GUIActionHandler::ReadDataFromServer(marker.string(), "first_boot_done");
        bool isFirst = (bootDone != "true");
        std::cout << "First boot marker exists, value: " << bootDone << ", isFirst: " << isFirst << std::endl;
        return isFirst;
    }
    catch (const std::exception &e)
    {
        std::cout << "Exception in IsFirstBoot: " << e.what() << std::endl;
        return true;
    }
}

void GUIBootupManager::MarkFirstBootDone()
{
    try
    {
        const auto markerDir = std::filesystem::current_path().parent_path() / "gui" / "src" / "pf";
        std::filesystem::create_directories(markerDir);
        const auto marker = markerDir / "first_boot_done.json";

        std::cout << "Writing first-boot marker to: " << marker.string() << std::endl;

        std::ofstream out(marker.string(), std::ios::out | std::ios::trunc);
        if (out.is_open())
        {
            out << "{\n  \"first_boot_done\": \"true\"\n}\n";
            out.close();
            std::cout << "Successfully wrote first_boot_done: true" << std::endl;
        }
    }
    catch (const std::exception &e)
    {
        std::cout << "ERROR in MarkFirstBootDone: " << e.what() << std::endl;
    }
}

void GUIBootupManager::onKey(Key key, KeyPressType press, Context &ctx)
{
    // Only handle keys when waiting for user input in Stage 5 (first boot)
    if (bootupTimer != nullptr)
    {
        // Still in timed stages, ignore keys
        std::cout << "onKey: Ignoring key - timer still active" << std::endl;
        return;
    }

    if (!isFirstBoot)
    {
        // Not in first boot waiting state, ignore keys
        std::cout << "onKey: Ignoring key - not in first boot waiting state" << std::endl;
        return;
    }

    std::cout << "onKey: First boot waiting state, processing key: " << (int)key << std::endl;

    if (key == Key::MENU_OK && press == KeyPressType::Short)
    {
        std::cout << "User pressed MENU_OK - transitioning to Home" << std::endl;
        CompleteBootup();
    }
}
