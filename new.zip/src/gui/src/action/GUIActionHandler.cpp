#include "GUIActionHandler.h"
#include <fstream>

GUIActionHandler::GUIActionHandler()
{
    Init();
}

void GUIActionHandler::Init()
{
    // Initialization logic
}

GUIActionHandler &GUIActionHandler::GetInstance()
{
    static GUIActionHandler instance;
    return instance;
}

float GUIActionHandler::GetVehicleSpeed()
{
    // TODO: Implement vehicle speed retrieval
    return 0.0f;
}

bool GUIActionHandler::GetMicOnOff()
{
    // TODO: Implement mic state retrieval
    return false;
}

void GUIActionHandler::SetMicOnOff(bool micOnOff)
{
    // TODO: Implement mic state setting
}

int GUIActionHandler::GetNetwork4GSignalStrength()
{
    // TODO: Implement signal strength retrieval
    return 0;
}

std::string GUIActionHandler::ReadDataFromServer(const std::string &filePath, const std::string &fieldName)
{
    try
    {
        std::ifstream file(filePath);
        if (!file.is_open())
            return "";

        std::string line;
        while (std::getline(file, line))
        {
            size_t pos = line.find("\"" + fieldName + "\"");
            if (pos != std::string::npos)
            {
                size_t colonPos = line.find(":", pos);
                if (colonPos != std::string::npos)
                {
                    // Check for boolean true/false
                    size_t truePos = line.find("true", colonPos);
                    size_t falsePos = line.find("false", colonPos);
                    if (truePos != std::string::npos && (truePos - colonPos) < 10)
                    {
                        return "true";
                    }
                    if (falsePos != std::string::npos && (falsePos - colonPos) < 10)
                    {
                        return "false";
                    }

                    // Check for string value
                    size_t firstQuote = line.find("\"", colonPos);
                    if (firstQuote != std::string::npos)
                    {
                        size_t secondQuote = line.find("\"", firstQuote + 1);
                        if (secondQuote != std::string::npos)
                        {
                            return line.substr(firstQuote + 1, secondQuote - firstQuote - 1);
                        }
                    }
                }
            }
        }
        return "";
    }
    catch (...)
    {
        return "";
    }
}
