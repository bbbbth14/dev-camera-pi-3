#include "GUIWindowFactory.h"
#include "GUIBootupWindow.h"
#include "GUIHomeWindow.h"
#include "GUIMenuMainWindow.h"
#include "GUIMenuInquiriesGroupWindow.h"
#include "GUIMenuInquiriesIndexWindow.h"
#include "GUINotificationDetailWindow.h"
#include "GUIContactDetailWindow.h"
GUIWindowFactory::GUIWindowFactory()
{
}

GUIWindowFactory::~GUIWindowFactory()
{
}

GUIWindowFactory &GUIWindowFactory::GetInstance()
{
    static GUIWindowFactory instance;
    return instance;
}

void GUIWindowFactory::Register(const std::string &name, Creator creator)
{
    registry[name] = std::move(creator);
}

std::unique_ptr<GUIWindowBase> GUIWindowFactory::Create(const std::string &name) const
{
    auto it = registry.find(name);
    if (it != registry.end())
    {
        return (it->second)();
    }
    return nullptr;
}

struct WindowRegistrar
{
    WindowRegistrar()
    {
        GUIWindowFactory::GetInstance().Register(GUIBootupWindow::Id, []
                                                 { return std::make_unique<GUIBootupWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIHomeWindow::Id, []
                                                 { return std::make_unique<GUIHomeWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIMenuMainWindow::Id, []
                                                 { return std::make_unique<GUIMenuMainWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIMenuInquiriesGroupWindow::Id, []
                                                 { return std::make_unique<GUIMenuInquiriesGroupWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIMenuInquiriesIndexWindow::Id, []
                                                 { return std::make_unique<GUIMenuInquiriesIndexWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUINotificationDetailWindow::Id, []
                                                 { return std::make_unique<GUINotificationDetailWindow>(); });
        GUIWindowFactory::GetInstance().Register(GUIContactDetailWindow::Id, []
                                                 { return std::make_unique<GUIContactDetailWindow>(); });
    }
} windowRegistrar;
