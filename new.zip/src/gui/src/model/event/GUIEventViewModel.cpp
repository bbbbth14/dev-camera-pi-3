#include "GUIEventViewModel.h"

GUIEventViewModel &GUIEventViewModel::GetInstance()
{
    static GUIEventViewModel instance;
    return instance;
}

void GUIEventViewModel::onUPKeyShortPressed()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onKey(GUIEventBase::Key::UP, GUIEventBase::KeyPressType::Short, ctx);
}
void GUIEventViewModel::onMENU_OKKeyShortPressed()
{
    std::cout << "GUIEventViewModel::onMENU_OKKeyShortPressed() called" << std::endl;
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onKey(GUIEventBase::Key::MENU_OK, GUIEventBase::KeyPressType::Short, ctx);
    std::cout << "  Context after call - doCreateNewManager: " << ctx.doCreateNewManager
              << ", newManagerName: " << ctx.newManagerName << std::endl;
}
void GUIEventViewModel::onDOWNKeyShortPressed()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onKey(GUIEventBase::Key::DOWN, GUIEventBase::KeyPressType::Short, ctx);
}
void GUIEventViewModel::onMIC_ON_OFFKeyShortPressed()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onKey(GUIEventBase::Key::MIC_ON_OFF, GUIEventBase::KeyPressType::Short, ctx);
}
void GUIEventViewModel::onEmergency_CallKeyShortPressed()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onKey(GUIEventBase::Key::Emergency_Call, GUIEventBase::KeyPressType::Short, ctx);
}
void GUIEventViewModel::onMotionDetected()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onMotionDetected(ctx);
}
void GUIEventViewModel::onShockDetected()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onShockDetected(ctx);
}
void GUIEventViewModel::onLongDrivingAttention()
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onLongDrivingAttention(ctx);
}

bool GUIEventViewModel::GetMicOnOff()
{
    return IsMicOn;
}
void GUIEventViewModel::SetMicOnOff(bool on)
{
    IsMicOn = on;
}

int GUIEventViewModel::Get4GSignalStrength()
{
    return _4GSignalStrength;
}
void GUIEventViewModel::on4GSignalStrengthChanged(int strength)
{
    GUIEventBase::Context ctx;
    GUIEventDispatcher::GetInstance().onNetwork4GSignalStrengthChanged(strength, ctx);
}