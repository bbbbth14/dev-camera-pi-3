#include "GUIAdasDmsViewModel.h"

GUIAdasDmsViewModel &GUIAdasDmsViewModel::GetInstance()
{
    static GUIAdasDmsViewModel instance;
    return instance;
}

void GUIAdasDmsViewModel::onVehicleSpeedChanged(float vehicleSpeed)
{
    if (this->VehicleSpeed != vehicleSpeed)
    {
        this->VehicleSpeed = vehicleSpeed;
        GUIEventBase::Context ctx;
        GUIEventDispatcher::GetInstance().onVehicleSpeedChanged(this->VehicleSpeed, ctx);
    }
}
float GUIAdasDmsViewModel::GetVehicleSpeed()
{
    return this->VehicleSpeed;
}