#pragma once

#ifndef GUIMENUMAINWINDOW_H
#define GUIMENUMAINWINDOW_H

#include "GUIWindowLayoutBase.h"

class GUIMenuMainWindow : public GUIWindowLayoutBase
{
private:
    std::unique_ptr<List> menuList = nullptr;

public:
    GUIMenuMainWindow();
    ~GUIMenuMainWindow();
    inline static const std::string Id = "SCS-01-2000";
    void Init() override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;

    int GetActiveIndex();
};

#endif // GUIMENUMAINWINDOW_H