#pragma once

#ifndef GUIMENUINQUIRIESINDEXMANAGER_H
#define GUIMENUINQUIRIESINDEXMANAGER_H

#include <string>

#include "GUIWindowManagerBase.h"
#include "GUIMenuInquiriesIndexWindow.h"
#include "GUIContactDetailWindow.h"
#include "GUINotificationDetailWindow.h"

class GUIMenuInquiriesIndexManager : public GUIWindowManagerBase
{
public:
    typedef enum
    {
        GUI_WINDOW_TYPE_NOTIFICATION = 0,
        GUI_WINDOW_TYPE_CONTACT,
    } GUIMenuType;

    typedef enum
    {
        VIEW_MODE_LIST = 0, // Show list of items
        VIEW_MODE_DETAIL,   // Show detail of one item
    } ViewMode;

    GUIMenuInquiriesIndexManager();
    GUIMenuInquiriesIndexManager(GUIMenuType eMenuType);
    GUIMenuInquiriesIndexManager(GUIMenuType eMenuType, int selectedIndex); // For detail view
    ~GUIMenuInquiriesIndexManager();
    inline static const std::string IdConstNoti = "GUIMenuInquiriesNotification";
    inline static const std::string IdConstContact = "GUIMenuInquiriesContact";
    inline static const std::string IdNotificationDetail = "GUINotificationDetailManager";
    inline static const std::string IdContactDetail = "GUIContactDetailManager";
    // inline static const std::string IdEventImg = "GUIMenuInquiriesIndexManagerEventImage";
    std::string GetStateName() const override;
    std::string GetId() const override;

    void Init() override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;

private:
    GUIMenuInquiriesIndexManager::GUIMenuType mMenuType;
    ViewMode mViewMode;
    int mSelectedIndex;

    std::vector<std::pair<GUIMenuInquiriesIndexManager::GUIMenuType, GUIMenuInquiriesIndexWindow::GUIMenuTitle>> windowTypeTitle = {
        {GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_NOTIFICATION, GUIMenuInquiriesIndexWindow::GUI_WINDOW_TITLE_NOTIFICATION},
        {GUIMenuInquiriesIndexManager::GUI_WINDOW_TYPE_CONTACT, GUIMenuInquiriesIndexWindow::GUI_WINDOW_TITLE_CONTACT}};
    GUIMenuInquiriesIndexWindow::GUIMenuTitle getWindowTitle(GUIMenuInquiriesIndexManager::GUIMenuType guiMenuType);
};

#endif // GUIMENUINQUIRIESINDEXMANAGER_H