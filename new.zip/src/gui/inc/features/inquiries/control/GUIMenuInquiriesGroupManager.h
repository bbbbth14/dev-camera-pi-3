#pragma once

#ifndef GUIMENUPINQUIRIESGROUPMANAGER_H
#define GUIMENUPINQUIRIESGROUPMANAGER_H

#include <string>

#include "GUIWindowManagerBase.h"
#include "GUIMenuInquiriesGroupWindow.h"

class GUIMenuInquiriesGroupManager : public GUIWindowManagerBase
{
public:
    GUIMenuInquiriesGroupManager();
    ~GUIMenuInquiriesGroupManager();
    inline static const std::string Id = "GUIMenuInquiriesGroupManager";
    void Init() override;
    std::string GetStateName() const override;
    std::string GetId() const override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;
    void onUPKeyShortPressed(Context &ctx) override;
    void onMENU_OKKeyShortPressed(Context &ctx) override;
    void onDOWNKeyShortPressed(Context &ctx) override;
    void onMIC_ON_OFFKeyShortPressed(Context &ctx) override;

private:
    void UpdateMenuStatus();
};

#endif // GUIMENUPINQUIRIESGROUPMANAGER_H