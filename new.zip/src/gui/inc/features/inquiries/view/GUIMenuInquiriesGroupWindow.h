#pragma once

#ifndef GUIMenuInquiriesGroupWindow_H
#define GUIMenuInquiriesGroupWindow_H

#include "GUIWindowLayoutBase.h"

class GUIMenuInquiriesGroupWindow : public GUIWindowLayoutBase
{
private:
    std::unique_ptr<List> menuList = nullptr;

public:
    GUIMenuInquiriesGroupWindow();
    ~GUIMenuInquiriesGroupWindow();
    inline static const std::string Id = "SCS-01-2000-3";
    void Init() override;
    void Refresh() override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;
    void onUPKeyShortPressed(Context &ctx) override;
    void onMENU_OKKeyShortPressed(Context &ctx) override;
    void onDOWNKeyShortPressed(Context &ctx) override;
    void onMIC_ON_OFFKeyShortPressed(Context &ctx) override;
    int GetActiveIndex();
    bool SetIndexState(bool isEnable, int iIndex);
};

#endif // GUIMenuInquiriesGroupWindow_H