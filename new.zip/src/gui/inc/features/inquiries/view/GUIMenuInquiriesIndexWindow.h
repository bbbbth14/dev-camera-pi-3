#pragma once

#ifndef GUIMenuInquiriesIndexWindow_H
#define GUIMenuInquiriesIndexWindow_H

#include "GUIWindowLayoutBase.h"

class GUIMenuInquiriesIndexWindow : public GUIWindowLayoutBase
{
public:
    typedef enum
    {
        GUI_WINDOW_TITLE_NOTIFICATION = 0,
        GUI_WINDOW_TITLE_CONTACT,
    } GUIMenuTitle;

private:
    std::unique_ptr<List> menuList = nullptr;
    std::vector<std::pair<GUIMenuTitle, std::string>> windowTitles = {
        {GUI_WINDOW_TITLE_NOTIFICATION, "Noti 常時録画"},
        {GUI_WINDOW_TITLE_CONTACT, " Contact イベント動画"},
    };

public:
    GUIMenuInquiriesIndexWindow();
    ~GUIMenuInquiriesIndexWindow();
    inline static const std::string Id = "SCS-01-2000-100";
    void Init() override;
    void Refresh() override;
    void onKey(Key key, KeyPressType press, Context &ctx) override;
    int GetActiveIndex();
    // bool SetIndexState(bool isEnable, int iIndex);
    void SetIndexTitle(GUIMenuTitle titleId);
    void SetIndexItemsList(std::vector<std::string> itemList);
    void SetItemThumbnail(std::string strThumbPath);
};

#endif // GUIMenuInquiriesIndexWindow_H