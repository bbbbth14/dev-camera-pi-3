#pragma once

#ifndef GUINOTIFICATIONDETAILWINDOW_H
#define GUINOTIFICATIONDETAILWINDOW_H

#include "GUIWindowLayoutBase.h"

class GUINotificationDetailWindow : public GUIWindowLayoutBase
{
public:
    GUINotificationDetailWindow();
    ~GUINotificationDetailWindow();

    inline static const std::string Id = "SCS-01-2000-200";

    void Init() override;
    void Refresh() override;
    void onKey(Key key, KeyPressType press, Context &ctx) override;
    void SetNotificationDetail(int index);

private:
    lv_obj_t *detailLabel = nullptr;
    int notificationIndex = -1;
};

#endif // GUINOTIFICATIONDETAILWINDOW_H
