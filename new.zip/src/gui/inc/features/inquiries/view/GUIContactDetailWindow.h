#pragma once

#ifndef GUICONTACTDETAILWINDOW_H
#define GUICONTACTDETAILWINDOW_H

#include "GUIWindowLayoutBase.h"

class GUIContactDetailWindow : public GUIWindowLayoutBase
{
public:
    GUIContactDetailWindow();
    ~GUIContactDetailWindow();

    inline static const std::string Id = "SCS-01-2000-300";

    void Init() override;
    void Refresh() override;
    void onKey(Key key, KeyPressType press, Context &ctx) override;

private:
    lv_obj_t *contactLabel1 = nullptr;
    lv_obj_t *contactLabel2 = nullptr;
    lv_obj_t *contactLabel3 = nullptr;
};

#endif // GUICONTACTDETAILWINDOW_H
