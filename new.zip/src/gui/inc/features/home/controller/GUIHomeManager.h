#pragma once

#ifndef GUIHOMEMANAGER_H
#define GUIHOMEMANAGER_H

#include <string>

#include "GUIEventBase.h"
#include "GUIWindowManagerBase.h"
#include "GUIHomeWindow.h"
#include "GUIMenuManager.h"

#include "GUIEventViewModel.h"

class GUIHomeManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        HOME,
    };
    State state;

public:
    GUIHomeManager();
    ~GUIHomeManager();
    inline static const std::string Id = "SCS-01-1000";

    std::string GetStateName() const override;
    std::string GetId() const override;
    void Init() override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;
    void onNetwork4GSignalStrengthChanged(int strength, Context &ctx) override;
    void onShockDetected(Context &ctx) override;
    void onMotionDetected(Context &ctx) override;

    void ToggleMicOnOff();
};

#endif // GUIHOMEMANAGER_H