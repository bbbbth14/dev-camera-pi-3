#pragma once

#ifndef GUIBOOTUPMANAGER_H
#define GUIBOOTUPMANAGER_H

#include "GUIWindowManagerBase.h"
#include "GUIBootupWindow.h"

class GUIBootupManager : public GUIWindowManagerBase
{
public:
    enum class State
    {
        BOOTUP,
    };
    State state;

public:
    inline static const std::string Id = "GUIBootupManager";

    GUIBootupManager();
    ~GUIBootupManager();

    std::string GetStateName() const override;
    std::string GetId() const override;
    void Init() override;

    void onKey(Key key, KeyPressType press, Context &ctx) override;

    // Boot sequence logic
    void StartBootSequence();
    void CompleteBootup();

private:
    bool isFirstBoot = true;
    lv_timer_t *bootupTimer = nullptr;
    lv_timer_t *serverTimeoutTimer = nullptr;
    bool serverResponseReceived = false;

    void Stage1_ShowCompanyName();
    void Stage2_ShowWarning();
    void Stage3_CheckFeetMode();
    void Stage4_CheckContract();
    void Stage5_SetupOrHome();

    void HideSystemUpdatePopup(GUIBootupWindow *current);
    void RestartBootSequence(GUIBootupWindow *current);

    // Helper methods
    bool IsFirstBoot() const;
    void MarkFirstBootDone();
};

#endif
