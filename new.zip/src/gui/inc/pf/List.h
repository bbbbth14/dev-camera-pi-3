#pragma once

#ifndef LIST_H
#define LIST_H

#include "ComponentBase.h"

class List : public ComponentBase
{
private:
    lv_obj_t *list = nullptr;

    struct Item
    {
        std::string text;
        lv_obj_t *row = nullptr;
        lv_obj_t *label = nullptr;
    };
    std::vector<Item> items;
    int activeIndex = -1; // -1: chưa có item nào active
    std::string activeStylePath;
    lv_obj_t *activeStyle = nullptr;

public:
    List(lv_obj_t *parent);
    ~List();
    void Init();
    void SetActiveStylePath(const std::string &path);
    void CreateDefaultActiveStyle(); // Create colored rectangle for highlighting
    void AddItem(const std::string &text);
    void AddItems(std::initializer_list<std::string> texts);
    void RemoveItem(int id);
    void RemoveItems();

    int GetActiveIndex();
    int GetCount() const;
    bool SetActiveIndex(int newIndex);
    bool MoveActiveUp();
    bool MoveActiveDown();

    void onKey(Key key, KeyPressType press, Context &ctx) override;

private:
    void UpdateActiveUI(int newIndex);
};

#endif // LIST_H