#ifndef GUIEVENTDISPATCHER_H
#define GUIEVENTDISPATCHER_H

#include <queue>
#include <mutex>

#include "GUIEventBase.h"

#include "GUIWindowManagerBase.h"
#include "GUIBootupManager.h"
#include "GUIHomeManager.h"
#include "GUIMenuManager.h"

#include "GUINotificationManager.h"
#include "GUIMenuInquiriesGroupManager.h"
#include "GUIMenuInquiriesIndexManager.h"

class GUIEventDispatcher : public GUIEventBase
{
public:
    GUIEventDispatcher();
    ~GUIEventDispatcher();
    static GUIEventDispatcher &GetInstance();

    void AddManager(std::string name);
    GUIWindowManagerBase *GetCurrentManager();
    void BackToManager(int id);
    void BackToPreviousManager();

    void PushEvent(GUIEventBase::GUIEvent event);
    void PollEvent(int maxEventsToProcess = 64);

    // Override key event methods to route to current manager
    void onKey(Key key, KeyPressType press, Context &ctx) override;
    void onMotionDetected(Context &ctx) override;

private:
    std::vector<std::unique_ptr<GUIWindowManagerBase>> managers;
    std::queue<GUIEventBase::GUIEvent> eventQueue;
    std::mutex queueMutex;

    void Init();

    void ProcessEvent(GUIEventBase::GUIEvent event);
    void ProcessPendingEvent();
};

#endif // GUIEVENTDISPATCHER_H