#ifndef GUIACTIONHANDLER_H
#define GUIACTIONHANDLER_H

#include <memory>

#include "AdasDmsProxy.h"

class GUIActionHandler
{
public:
    static GUIActionHandler &GetInstance();

    float GetVehicleSpeed();

    bool GetMicOnOff();
    void SetMicOnOff(bool micOnOff);

    int GetNetwork4GSignalStrength();

private:
    std::unique_ptr<AdasDmsProxy> m_pcAdasDmsProxy = nullptr;
    GUIActionHandler();
    void Init();
};

#endif // GUIACTIONHANDLER_H