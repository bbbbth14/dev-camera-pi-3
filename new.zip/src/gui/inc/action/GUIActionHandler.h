#ifndef GUIACTIONHANDLER_H
#define GUIACTIONHANDLER_H

#include <memory>
#include <string>

class GUIActionHandler
{
public:
    static GUIActionHandler &GetInstance();

    float GetVehicleSpeed();

    bool GetMicOnOff();
    void SetMicOnOff(bool micOnOff);

    int GetNetwork4GSignalStrength();

    // Server data retrieval
    static std::string ReadDataFromServer(const std::string &filePath, const std::string &fieldName);

private:
    GUIActionHandler();
    void Init();
};

#endif // GUIACTIONHANDLER_H