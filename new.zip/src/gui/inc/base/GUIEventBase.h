#ifndef GUIEVENTBASE_H
#define GUIEVENTBASE_H

#include <string>
#include <variant>
#include <iostream>

class GUIEventBase
{
public:
    enum class GUIEventType
    {
        Key,

        VehicleSpeedChanged,
        Network4GSignalStrengthChanged,

        MotionDetected,

        ShockDetected,                // メッセージ1 衝撃を検知しました
        LongDrivingAttention,         // メッセージ2 長時間走行注意
        RapidAccelerationAttention,   // メッセージ3 急加速注意
        SuddenDecelerationAttention,  // メッセージ4 急減速注意
        LeftSharpSteeringDetection,   // メッセージ5 左急ハンドル検知
        RightSharpSteeringDetection,  // メッセージ6 右急ハンドル検知
        WobblyAttention,              // メッセージ7 ふらつき注意
        ReverseDrivingFrequentPoints, // メッセージ8 逆走多発地点接近注意
        OutOfDesignatedArea,          // メッセージ9 指定区域外に出ました
        AccidentProneLocationCaution, // メッセージ10 事故多発地点注意
        MaxSpeed30AreaCaution,        // メッセージ11 最高速度30キロ制限地域注意
        PauseCaution,                 // メッセージ12 一時停止注意
        AnimalAttention,              // メッセージ13 動物注意
        WeatherWarningCaution,        // メッセージ14 気象警報注意
        CollisionAlert,               // メッセージ15 衝突注意
        LeftLaneCaution,              // メッセージ16 左車線注意
        RightLaneCaution,             // メッセージ17 右車線注意
        SpeedExceedsAttention,        // メッセージ18 速度超過注意
        DozingOffAttention,           // メッセージ19 居眠り注意
        MobilePhoneAttention,         // メッセージ20 携帯電話注意
        DistractedAttention,          // メッセージ21 脇見注意

        // SD card
        PowerOnWithoutSdCard,
        SdCardRemoved,
        SdCardInserted,
        SdCardFraudulentOrUnformatted,
        SdCardAbnormalOrUnrecognized,
        SdCardUnsupported,
        SdCardRunningOutOfSpace,

        // Temperature (during recording)
        HighTempLv1DuringRecording,
        HighTempLv2DuringRecording,
        HighTempLv3DuringRecording,

        // Playback / Recording
        PlaybackStoppedAbnormallyDuringFilePlayback,
        StopRecordingByAnomalyDetection,
        StopRecordingByAnomalyDetection5TimesADay,

        // SIM
        SimCardAbnormalOrUnrecognized,
        SimCardRecognized,

        // Camera (2nd camera)
        SecondCameraDisconnectedRear,
        SecondCameraDisconnectedInternal,

        // Orientation / Installation
        DvrNotHorizontalRepeatedAtRegularInterval,

        // System update / generic error
        SystemUpdateFailed,
        SystemUpdateCompleted,
        OtherErrorsOccurred,

        PlaySoundDone,

        COUNT,
    };

    enum class Key
    {
        UP,
        MENU_OK,
        DOWN,
        MIC_ON_OFF,
        Emergency_Call
    };
    enum class KeyPressType
    {
        Short,
        Long
    };
    struct KeyPayload
    {
        Key key;
        KeyPressType pressType;
    };
    using GUIEventPayload = std::variant<std::monostate, KeyPayload, float, int>;

    struct GUIEvent
    {
        GUIEventType type{GUIEventType::COUNT};
        GUIEventPayload payload{};
    };

    struct Context
    {
        bool doCreateNewManager = false;
        std::string newManagerName;
        bool doBackToPreviousManager = false;
        bool keyEventHandled = false;
    };

    virtual void onEvent(GUIEvent event, Context &ctx);

    virtual void onKey(Key key, KeyPressType press, Context &ctx) {}
    virtual void onUPKeyShortPressed(Context &ctx) {}
    virtual void onMENU_OKKeyShortPressed(Context &ctx) {}
    virtual void onDOWNKeyShortPressed(Context &ctx) {}
    virtual void onMIC_ON_OFFKeyShortPressed(Context &ctx) {}
    virtual void onEmergency_CallKeyShortPressed(Context &ctx) {}

    virtual void onVehicleSpeedChanged(float value, Context &ctx) {}
    virtual void onNetwork4GSignalStrengthChanged(int value, Context &ctx) {}

    virtual void onMotionDetected(Context &ctx) {}

    virtual void onShockDetected(Context &ctx) {}
    virtual void onLongDrivingAttention(Context &ctx) {}

    virtual void onPowerOnWithoutSdCard(Context &ctx) {}
    virtual void onSdCardRemoved(Context &ctx) {}
    virtual void onSdCardInserted(Context &ctx) {}
    virtual void onPlaybackStoppedAbnormallyDuringFilePlayback(Context &ctx) {}
    virtual void onPlaySoundDone(Context &ctx) {}

private:
    void SplitKey(Key key, KeyPressType press, Context &ctx);
};

#endif // GUIEVENTBASE_H