#ifndef GUIWINDOWMANAGERBASE_H
#define GUIWINDOWMANAGERBASE_H

#include <vector>

#include "GUIEventBase.h"
#include "GUIWindowBase.h"
#include "GUIWindowFactory.h"

#include "GUIActionHandler.h"

class GUIWindowManagerBase : public GUIEventBase
{

public:
    GUIWindowManagerBase();
    ~GUIWindowManagerBase();
    virtual std::string GetStateName() const = 0;
    virtual std::string GetId() const = 0;

    GUIWindowBase *GetCurrentWindow();
    void SetCurrentWindow(std::string name);
    void RefreshCurrentWindow();
    void BackToPreviousWindow();
    void ShowCurrentWindow();

    virtual bool AllowToBackToHome() { return true; };

private:
    virtual void Init() = 0;
    std::vector<std::unique_ptr<GUIWindowBase>> windows;
};

#endif // GUIWINDOWMANAGERBASE_H