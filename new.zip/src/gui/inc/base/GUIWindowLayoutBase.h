#pragma once

#ifndef GUIWINDOWLAYOUTBASE_H
#define GUIWINDOWLAYOUTBASE_H

#include "GUIWindowBase.h"
#include "TextBox.h"
#include "Button.h"
#include <memory>

class GUIWindowLayoutBase : public GUIWindowBase
{

protected:
    std::string title = "";
    std::string message = "";
    std::string upImagePath = "";
    std::string menuOkImagePath = "";
    std::string downImagePath = "";
    std::string micOnOffImagePath = "";

    std::unique_ptr<TextBox> titleTextBox = nullptr;
    std::unique_ptr<TextBox> messageTextBox = nullptr;

    std::unique_ptr<Button> upButton = nullptr;
    std::unique_ptr<Button> menuOkButton = nullptr;
    std::unique_ptr<Button> downButton = nullptr;
    std::unique_ptr<Button> micOnOffButton = nullptr;

public:
    GUIWindowLayoutBase();
    ~GUIWindowLayoutBase();

    virtual void Init() = 0;

    // free first, then set later
    void SetTitle(const std::string &title);
    void SetTitleShadow();
    void SetMessage(const std::string &message);
    void SetUpImage(const std::string &path);
    void SetMenuOkImage(const std::string &path);
    void SetDownImage(const std::string &path);
    void SetMicOnOffImage(const std::string &path);
};

#endif // GUIWINDOWLAYOUTBASE_H