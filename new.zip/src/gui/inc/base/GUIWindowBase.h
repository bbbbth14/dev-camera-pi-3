#ifndef GUIWINDOWBASE_H
#define GUIWINDOWBASE_H

#include <string>

#include "GUIEventBase.h"
#include "ComponentBase.h"
#include "List.h"

#include "GUIActionHandler.h"

class GUIWindowBase : public GUIEventBase
{
public:
    GUIWindowBase();
    ~GUIWindowBase();

    void Show();
    virtual void Refresh() {}
    lv_obj_t *GetScreen();

protected:
    lv_obj_t *scr = nullptr;

    virtual void Init() {};

private:
};

#endif // GUIWINDOWBASE_H