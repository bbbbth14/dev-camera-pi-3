#include "Display.h"
#include "GUIEventViewModel.h"
#include "GUIAdasDmsViewModel.h"
#include "GUIEventDispatcher.h"
#include <SDL.h>
#include <sstream>
#include <iomanip>
#include <iostream>

lv_display_t *Display::create_display(std::wstring name, int width, int height)
{
    SDL_SetHint(SDL_HINT_MOUSE_FOCUS_CLICKTHROUGH, "1");

    lv_group_set_default(lv_group_create());

    lv_display_t *disp = lv_sdl_window_create(width, height);
    std::string nname(name.begin(), name.end());
    lv_sdl_window_set_title(disp, nname.c_str());

    lv_indev_t *mouse = lv_sdl_mouse_create();
    lv_indev_set_group(mouse, lv_group_get_default());
    lv_indev_set_display(mouse, disp);
    lv_display_set_default(disp);
    // /*Declare the image file.*/
    // LV_IMAGE_DECLARE(mouse_cursor_icon);
    // lv_obj_t * cursor_obj;
    // /*Create an image object for the cursor */
    // cursor_obj = lv_image_create(lv_screen_active());
    // /*Set the image source*/
    // lv_image_set_src(cursor_obj, &mouse_cursor_icon);
    // /*Connect the image  object to the driver*/
    // lv_indev_set_cursor(mouse, cursor_obj);

    lv_indev_t *mousewheel = lv_sdl_mousewheel_create();
    lv_indev_set_display(mousewheel, disp);
    lv_indev_set_group(mousewheel, lv_group_get_default());

    lv_indev_t *kb = lv_sdl_keyboard_create();
    lv_indev_set_display(kb, disp);
    lv_indev_set_group(kb, lv_group_get_default());

    return disp;
}

void btn_event_handler(lv_event_t *e)
{
    try
    {

        lv_obj_t *btn = (lv_obj_t *)lv_event_get_target(e);            // Lấy đối tượng nút
        const char *txt = lv_label_get_text(lv_obj_get_child(btn, 0)); // Lấy text của nút

        void *ud = lv_event_get_user_data(e);

        GUIEventViewModel &eventViewModel = GUIEventViewModel::GetInstance();
        GUIAdasDmsViewModel &adasDmsViewModel = GUIAdasDmsViewModel::GetInstance();

        if (lv_event_get_code(e) == LV_EVENT_CLICKED)
        {
            printf("Key %s clicked!\n", txt);

            // Xử lý theo tên nút
            if (strcmp(txt, "UP") == 0)
            {
                // Code xử lý cho UP
                eventViewModel.onUPKeyShortPressed();
            }
            else if (strcmp(txt, "MENU/OK") == 0)
            {
                // Code xử lý cho OK
                eventViewModel.onMENU_OKKeyShortPressed();
            }
            else if (strcmp(txt, "DOWN") == 0)
            {
                // Code xử lý cho DOWN
                eventViewModel.onDOWNKeyShortPressed();
            }
            else if (strcmp(txt, "MIC ON/OFF") == 0)
            {
                // Code xử lý cho RETURN
                eventViewModel.onMIC_ON_OFFKeyShortPressed();
            }
            else if (strcmp(txt, "Emergency Call") == 0)
            {
                // Code xử lý cho EMERGENCY
                eventViewModel.onEmergency_CallKeyShortPressed();
            }
            else if (strcmp(txt, "Motion Detected") == 0)
            {
                eventViewModel.onMotionDetected();
            }
            else if (strcmp(txt, "Shock Detected") == 0)
            {
                eventViewModel.onShockDetected();
            }
            else if (strcmp(txt, "Long Driving Attention") == 0)
            {
                eventViewModel.onLongDrivingAttention();
            }
            else if (strcmp(txt, "Set Vehicle Speed") == 0)
            {
                lv_obj_t *ta = (lv_obj_t *)ud;

                const char *txt = lv_textarea_get_text(ta);
                float vehicleSpeed = std::strtof(txt, nullptr);

                std::ostringstream oss;
                oss << std::fixed << std::setprecision(1) << vehicleSpeed;
                std::string speedStr = oss.str();

                // std::string speedStr = std::format("{:.1f}", vehicleSpeed);
                lv_textarea_set_text(ta, speedStr.c_str());

                adasDmsViewModel.onVehicleSpeedChanged(vehicleSpeed);
            }
            else if (strcmp(txt, "Set 4G Strength") == 0)
            {
                lv_obj_t *ta = (lv_obj_t *)ud;

                const char *txt = lv_textarea_get_text(ta);
                float value = std::strtof(txt, nullptr);

                std::ostringstream oss;
                oss << std::fixed << std::setprecision(1) << value;
                std::string speedStr = oss.str();

                // std::string speedStr = std::format("{:.1f}", vehicleSpeed);
                lv_textarea_set_text(ta, speedStr.c_str());

                eventViewModel.on4GSignalStrengthChanged(value);
            }
        }
    }

    catch (const std::exception &ex)
    {
        std::cerr << "Lỗi xảy ra: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Lỗi không xác định xảy ra!" << std::endl;
    }
}
void onVehicleSpeedChange()
{
}
lv_obj_t *Display::create_button(lv_obj_t *cont, lv_style_t *style_btn, int btn_w, int btn_h, int col, int row, const char *text)
{
    lv_obj_t *btn_right2 = lv_btn_create(cont);
    lv_obj_add_style(btn_right2, style_btn, 0);
    lv_obj_set_size(btn_right2, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_right2, LV_GRID_ALIGN_STRETCH, col, 1,
                         LV_GRID_ALIGN_STRETCH, row, 1);
    lv_obj_t *label_r2 = lv_label_create(btn_right2);
    lv_label_set_text(label_r2, text);
    lv_obj_set_width(label_r2, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_r2, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_r2, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_center(label_r2);
    lv_obj_add_event_cb(btn_right2, btn_event_handler, LV_EVENT_CLICKED, this);

    return btn_right2;
}

// Hàm tạo stack: [Button "OK"] - [TextArea] - [Button "Cancel"]
lv_obj_t *Display::create_stack_with_controls(lv_obj_t *parent, int btn_w, int btn_h, int col, int row, const char *text)
{
    if (!parent)
        return nullptr;

    // 1) Container (stack)
    lv_obj_t *stack = lv_obj_create(parent);
    lv_obj_set_size(stack, btn_w, btn_h);             // rộng 300, cao theo nội dung
    lv_obj_center(stack);                             // đặt giữa parent
    lv_obj_set_style_pad_all(stack, 8, 0);            // padding cho container
    lv_obj_set_style_pad_row(stack, 8, 0);            // khoảng cách giữa các dòng
    lv_obj_set_flex_flow(stack, LV_FLEX_FLOW_COLUMN); // sắp xếp theo cột (stack)
    lv_obj_set_flex_align(stack,
                          LV_FLEX_ALIGN_START,   // main axis (trên-dưới) -> START
                          LV_FLEX_ALIGN_START,   // cross axis (trái-phải) -> START
                          LV_FLEX_ALIGN_CENTER); // align nội dung -> CENTER

    lv_obj_set_grid_cell(stack, LV_GRID_ALIGN_STRETCH, col, 1,
                         LV_GRID_ALIGN_STRETCH, row, 1);

    // 2) Button trên (OK)
    // lv_obj_t* title = lv_obj_create(stack);
    // lv_obj_set_width(title, LV_PCT(100));                     // nút full width theo stack
    // lv_obj_set_height(title, 30);                     // nút full width theo stack
    // lv_obj_t* label = lv_label_create(title);
    // lv_label_set_text(label, "Vehicle Speed");
    // lv_obj_center(label);

    // lv_obj_t* title = lv_label_create(stack);
    // lv_obj_set_width(title, LV_PCT(100));                     // nút full width theo stack
    // lv_obj_set_height(title, 20);                     // nút full width theo stack
    ////lv_obj_t* label = lv_label_create(title);
    // lv_label_set_text(title, "Vehicle Speed");
    // lv_obj_center(title);

    // 3) Textbox (TextArea)
    lv_obj_t *ta = lv_textarea_create(stack);
    lv_obj_set_width(ta, LV_PCT(100));
    lv_obj_set_height(ta, 50); // chiều cao mong muốn
    lv_textarea_set_placeholder_text(ta, text);
    lv_textarea_set_one_line(ta, false); // cho phép nhiều dòng
    lv_textarea_set_max_length(ta, 512);

    // Option: thêm label cho TextArea (nếu muốn)
    // lv_obj_t* ta_label = lv_label_create(stack);
    // lv_label_set_text(ta_label, "Nội dung:");
    // -> Nếu muốn label ở trên TextArea, tạo label trước ta.

    // 4) Button dưới (Cancel)
    lv_obj_t *btn_ok = lv_btn_create(stack);
    lv_obj_set_width(btn_ok, LV_PCT(100));
    lv_obj_set_height(btn_ok, 50);
    lv_obj_t *label_ok = lv_label_create(btn_ok);
    lv_label_set_text(label_ok, text);
    lv_obj_set_width(label_ok, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_ok, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_ok, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_center(label_ok);

    //// 5) Gán sự kiện (ví dụ)
    // lv_obj_add_event_cb(btn_ok, [](lv_event_t* e) {
    //     lv_obj_t* stack_local = lv_event_get_current_target(e); // current button
    //     // Lấy parent để truy cập TextArea (đơn giản: tìm theo index)
    //     lv_obj_t* parent = lv_obj_get_parent(stack_local);
    //     // Giả sử TextArea là child thứ 2 (index 1 nếu không có label thêm)
    //     // Nhưng an toàn hơn: duyệt tìm class text area
    //     lv_obj_t* ta_found = nullptr;
    //     uint32_t child_cnt = lv_obj_get_child_cnt(parent);
    //     for (uint32_t i = 0; i < child_cnt; ++i) {
    //         lv_obj_t* c = lv_obj_get_child(parent, i);
    //         if (lv_obj_has_class(c, &lv_textarea_class)) {
    //             ta_found = c;
    //             break;
    //         }
    //     }
    //     if (ta_found) {
    //         const char* text = lv_textarea_get_text(ta_found);
    //         LV_LOG_USER("OK pressed. Text: %s", text);
    //         // TODO: xử lý text (validate, gửi lên service, v.v.)
    //     }
    //     }, LV_EVENT_CLICKED, nullptr);

    // lv_obj_add_event_cb(btn_cancel, [](lv_event_t* e) {
    //     LV_LOG_USER("Cancel pressed");
    //     // TODO: xử lý hủy, đóng popup, xóa stack, v.v.
    //     // lv_obj_del(lv_obj_get_parent(lv_event_get_current_target(e)));
    //     }, LV_EVENT_CLICKED, nullptr);

    lv_obj_add_event_cb(btn_ok, btn_event_handler, LV_EVENT_CLICKED, ta);

    return stack;
}

lv_obj_t *Display::create_right_screen()
{
    lv_obj_t *scr = lv_obj_create(NULL);

    // ===== Style cho nút =====
    static lv_style_t style_btn;
    lv_style_init(&style_btn);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_bg_color(&style_btn, lv_palette_main(LV_PALETTE_BLUE));
    lv_style_set_text_color(&style_btn, lv_color_white());
    lv_style_set_border_color(&style_btn, lv_palette_darken(LV_PALETTE_BLUE, 2));
    lv_style_set_border_width(&style_btn, 1);

    int btn_w = 100;
    int btn_h = 80;

    // ===== Container Grid =====
    lv_obj_t *cont = lv_obj_create(scr);
    lv_obj_set_size(cont, btn_w * 4 + 30, btn_h * 3 + 40);
    // lv_obj_center(cont);
    lv_obj_align(cont, LV_ALIGN_LEFT_MID, 10, 0);
    lv_obj_set_style_pad_all(cont, 10, 0);
    lv_obj_set_style_pad_row(cont, 10, 0);
    lv_obj_set_style_pad_column(cont, 10, 0);
    lv_obj_set_layout(cont, LV_LAYOUT_GRID);

    // Khai báo grid: 3 cột, 3 hàng
    static int32_t grid_cols[] = {LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
    static int32_t grid_rows[] = {LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_TEMPLATE_LAST};
    lv_obj_set_grid_dsc_array(cont, grid_cols, grid_rows);

    // ===== 3 nút bên trái (cột 0) =====
    lv_obj_t *btn_up = lv_btn_create(cont);
    lv_obj_add_style(btn_up, &style_btn, 0);
    lv_obj_set_size(btn_up, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_up, LV_GRID_ALIGN_STRETCH, /*col*/ 0, /*col_span*/ 1,
                         LV_GRID_ALIGN_STRETCH, /*row*/ 0, /*row_span*/ 1);
    lv_obj_t *label_up = lv_label_create(btn_up);
    lv_label_set_text(label_up, "UP");
    lv_obj_center(label_up);
    lv_obj_add_event_cb(btn_up, btn_event_handler, LV_EVENT_CLICKED, this); // user_data = this (nếu cần)

    lv_obj_t *btn_ok = lv_btn_create(cont);
    lv_obj_add_style(btn_ok, &style_btn, 0);
    lv_obj_set_size(btn_ok, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_ok, LV_GRID_ALIGN_STRETCH, 0, 1,
                         LV_GRID_ALIGN_STRETCH, 1, 1);
    lv_obj_t *label_ok = lv_label_create(btn_ok);
    lv_label_set_text(label_ok, "MENU/OK");
    lv_obj_center(label_ok);
    lv_obj_add_event_cb(btn_ok, btn_event_handler, LV_EVENT_CLICKED, this);

    lv_obj_t *btn_down = lv_btn_create(cont);
    lv_obj_add_style(btn_down, &style_btn, 0);
    lv_obj_set_size(btn_down, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_down, LV_GRID_ALIGN_STRETCH, 0, 1,
                         LV_GRID_ALIGN_STRETCH, 2, 1);
    lv_obj_t *label_down = lv_label_create(btn_down);
    lv_label_set_text(label_down, "DOWN");
    lv_obj_center(label_down);
    lv_obj_add_event_cb(btn_down, btn_event_handler, LV_EVENT_CLICKED, this);

    // ===== 3 nút bên phải (cột 1) =====
    lv_obj_t *btn_right1 = lv_btn_create(cont);
    lv_obj_add_style(btn_right1, &style_btn, 0);
    lv_obj_set_size(btn_right1, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_right1, LV_GRID_ALIGN_STRETCH, 1, 1,
                         LV_GRID_ALIGN_STRETCH, 0, 1);
    lv_obj_t *label_r1 = lv_label_create(btn_right1);
    lv_label_set_text(label_r1, "Motion Detected");
    lv_obj_set_width(label_r1, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_r1, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_r1, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_center(label_r1);
    lv_obj_add_event_cb(btn_right1, btn_event_handler, LV_EVENT_CLICKED, this);

    lv_obj_t *btn_right2 = lv_btn_create(cont);
    lv_obj_add_style(btn_right2, &style_btn, 0);
    lv_obj_set_size(btn_right2, btn_w, btn_h);
    lv_obj_set_grid_cell(btn_right2, LV_GRID_ALIGN_STRETCH, 1, 1,
                         LV_GRID_ALIGN_STRETCH, 1, 1);
    lv_obj_t *label_r2 = lv_label_create(btn_right2);
    lv_label_set_text(label_r2, "Shock Detected");
    lv_obj_set_width(label_r2, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_r2, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_r2, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_center(label_r2);
    lv_obj_add_event_cb(btn_right2, btn_event_handler, LV_EVENT_CLICKED, this);

    lv_obj_t *label_c1r2 = create_button(cont, &style_btn, btn_w, btn_h, 1, 2, "Long Driving Attention");

    lv_obj_t *label_c2r0 = create_button(cont, &style_btn, btn_w, btn_h, 2, 0, "A");
    lv_obj_t *label_c2r1 = create_button(cont, &style_btn, btn_w, btn_h, 2, 1, "B");
    lv_obj_t *label_c2r2 = create_button(cont, &style_btn, btn_w, btn_h, 2, 2, "C");

    lv_obj_t *label_c3r0 = create_button(cont, &style_btn, btn_w, btn_h, 3, 0, "A");
    lv_obj_t *label_c3r1 = create_button(cont, &style_btn, btn_w, btn_h, 3, 1, "B");
    lv_obj_t *label_c3r2 = create_button(cont, &style_btn, btn_w, btn_h, 3, 2, "C");

    // ===== Container Grid =====
    int cell_w = 120;
    int cell_h = 130;

    lv_obj_t *cont2 = lv_obj_create(scr);
    lv_obj_set_size(cont2, cell_w * 4 + 30, cell_h * 2 + 40);
    // lv_obj_center(cont);
    int cont_w = lv_obj_get_width(cont);
    int cont_x = lv_obj_get_x(cont);
    lv_obj_align(cont2, LV_ALIGN_LEFT_MID, cont_x + cont_w + 10, 0);
    lv_obj_set_style_pad_all(cont2, 10, 0);
    lv_obj_set_style_pad_row(cont2, 10, 0);
    lv_obj_set_style_pad_column(cont2, 10, 0);
    lv_obj_set_layout(cont2, LV_LAYOUT_GRID);

    // Khai báo grid: 3 cột, 3 hàng
    static int32_t grid2_cols[] = {LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
    static int32_t grid2_rows[] = {LV_GRID_CONTENT, LV_GRID_CONTENT, LV_GRID_TEMPLATE_LAST};
    lv_obj_set_grid_dsc_array(cont2, grid2_cols, grid2_rows);

    lv_obj_t *vehicleSpeed = create_stack_with_controls(cont2, cell_w, cell_h, 0, 0, "Set Vehicle Speed");
    lv_obj_t *_4gSignalStrength = create_stack_with_controls(cont2, cell_w, cell_h, 0, 1, "Set 4G Strength");

    return scr;
}

lv_obj_t *Display::create_bottom_screen()
{
    lv_obj_t *scr = lv_obj_create(NULL);

    static lv_style_t style_btn;
    lv_style_init(&style_btn);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_bg_color(&style_btn, lv_palette_main(LV_PALETTE_BLUE));
    lv_style_set_text_color(&style_btn, lv_color_white());

    static lv_style_t style_btn_red;
    lv_style_init(&style_btn_red);
    lv_style_set_radius(&style_btn_red, 10);
    lv_style_set_bg_color(&style_btn_red, lv_palette_main(LV_PALETTE_RED));
    lv_style_set_text_color(&style_btn_red, lv_color_white());

    int btn_w = 100;
    int btn_h = 72;

    lv_obj_t *btn_return = lv_btn_create(scr);
    lv_obj_add_style(btn_return, &style_btn, 0);
    lv_obj_set_size(btn_return, btn_w, btn_h);
    lv_obj_align(btn_return, LV_ALIGN_CENTER, 200, 0);
    lv_obj_t *label_return = lv_label_create(btn_return);
    lv_label_set_text(label_return, "MIC ON/OFF");
    lv_obj_set_width(label_return, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_return, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_return, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_add_event_cb(btn_return, btn_event_handler, LV_EVENT_CLICKED, NULL);

    lv_obj_t *btn_emergency = lv_btn_create(scr);
    lv_obj_add_style(btn_emergency, &style_btn, 0);
    lv_obj_set_size(btn_emergency, btn_w, btn_h);
    lv_obj_align(btn_emergency, LV_ALIGN_CENTER, -100, 0);
    lv_obj_t *label_emergency = lv_label_create(btn_emergency);
    lv_label_set_text(label_emergency, "Emergency Call");
    lv_obj_set_width(label_emergency, lv_pct(100));                        // cho label rộng bằng 100% nút
    lv_label_set_long_mode(label_emergency, LV_LABEL_LONG_WRAP);           // bật wrap
    lv_obj_set_style_text_align(label_emergency, LV_TEXT_ALIGN_CENTER, 0); // căn giữa
    lv_obj_add_event_cb(btn_emergency, btn_event_handler, LV_EVENT_CLICKED, NULL);

    return scr;
}
